<?php

use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;
use App\Http\Controllers\Frontend\HomeController;
use App\Http\Controllers\Frontend\AboutController;
use App\Http\Controllers\Frontend\BlogController;
use App\Http\Controllers\Frontend\ContactController;
use App\Http\Controllers\Frontend\CartController;
use App\Http\Controllers\Frontend\JewelryController;
use App\Http\Controllers\Frontend\SigninController;
use App\Http\Controllers\Frontend\AdminController;
use App\Http\Controllers\Frontend\WishlistController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return Inertia::render('Welcome', [
//         'canLogin' => Route::has('login'),
//         'canRegister' => Route::has('register'),
//         'laravelVersion' => Application::VERSION,
//         'phpVersion' => PHP_VERSION,
//     ]);
// });
// Route::get('/', function () {
//         return view('frontend.Index');
// });
Route::get('/', [AdminController::class, 'home']);

// Route::get('/home', [HomeController::class, 'index']);
Route::get('/signin', [SigninController::class, 'index'])->name('user.login');
Route::post('/signin', [SigninController::class, 'handleLogin'])->name('store.login');

Route::get('/register', [SigninController::class, 'register'])->name('user.register');
Route::post('/register', [SigninController::class, 'handleRegister'])->name('store.register');
Route::post('/logout', [SigninController::class, 'logout'])->name('user.logout');

    // Route::get('/home', [HomeController::class, 'index']);
    Route::get('/about', [AboutController::class, 'index']);
    Route::get('/contact', [ContactController::class, 'index']);
    Route::get('/privacy-policy', [AboutController::class, 'privacy']);
    Route::get('/refund_returns', [AboutController::class, 'refund_returns']);
    Route::get('/cart', [CartController::class, 'index']);
    Route::get('/blog', [BlogController::class, 'index']);
    Route::get('/jewelry', [JewelryController::class, 'index']);
    
    
Route::get('/admin', [AdminController::class, 'index']);

Route::get('/admin/dashboard', [AdminController::class, 'adminDashBoard']);
Route::post('/admin_login', [AdminController::class, 'login'])->name('admin.login');


// Product routes

Route::get('/admin/product', [AdminController::class, 'viewproduct'])->name('admin.product');
Route::post('/admin/product', [AdminController::class, 'addproduct'])->name('admin.product');
Route::get('/admin/showProduct', [AdminController::class, 'showProduct'])->name('admin.showProduct');
Route::get('/admin/deleteProduct/{id}',  [AdminController::class, 'deleteProduct'])->name('admin.deleteProduct');
Route::get('/admin/updateProduct/{id}',  [AdminController::class, 'updateShowProduct'])->name('admin.updateShowProduct');
Route::post('/admin/updateProduct',  [AdminController::class, 'updateProduct'])->name('admin.updateProduct');

    
// category routes

Route::get('/admin/category', [AdminController::class, 'viewCategory'])->name('admin.category');
Route::post('/admin/category', [AdminController::class, 'addCategory'])->name('admin.category');
Route::get('/admin/showcategory', [AdminController::class, 'allcategory'])->name('admin.allcategory');
Route::get('/admin/deletecategory/{id}', [AdminController::class, 'deleteCategory'])->name('admin.deleteCategory');
Route::get('/admin/updateShowCategory/{id}', [AdminController::class, 'updateShowCategory'])->name('admin.updateShowCategory');
Route::post('/admin/updateShowCategory', [AdminController::class, 'updateCategory'])->name('admin.updateCategory');

Route::get('/admin/dashboard', [AdminController::class, 'admin_dashboard'])->name('admin.dashboard');


//blog routes
Route::get('/admin/blog', [AdminController::class, 'addBlog'])->name('admin.addBlog');
Route::post('/admin/blog', [AdminController::class, 'storeBlog'])->name('admin.storeBlog');
Route::get('/admin/Showblog', [AdminController::class, 'viewBlog'])->name('admin.showBlog');


//cart
Route::post('/cart/add', [CartController::class, 'add'])->name('cart.add');
Route::get('/cart', [CartController::class, 'index'])->name('cart.index');
Route::patch('/cart/{id}', [CartController::class, 'update'])->name('cart.update');
Route::delete('/cart/{id}', [CartController::class, 'destroy'])->name('cart.delete');



//wishlist
Route::get('/wishlist', [WishlistController::class, 'index'])->name('wishlist.index');
Route::post('/wishlist/add', [WishlistController::class, 'add'])->name('wishlist.add');
Route::post('/wishlist/remove', [WishlistController::class, 'remove'])->name('wishlist.remove');
Route::delete('/wishlist/remove/{id}', [WishlistController::class, 'remove'])->name('wishlist.remove');


//fetch product based on category
Route::get('/category/{id}', [JewelryController::class, 'showByCategory'])->name('category.show');

Route::get('/product/{productId}', [JewelryController::class, 'show'])->name('product.view');



    
    


    
Route::middleware([
    'auth:sanctum',
    config('jetstream.auth_session'),
    'verified',
])->group(function () {
    Route::get('/dashboard', function () {
        return Inertia::render('Dashboard');
    })->name('dashboard');
    
});

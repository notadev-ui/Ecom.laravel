
<nav>
    <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="dashboard">Dashboard</span>
    </div>
    <div class="search-box">
        <input type="text" placeholder="Search...">
        <i class='bx bx-search'></i>
    </div>
    <div class="profile-details">
        <img src="<?php echo e(asset('/assets/dashboard/img/avatar.png')); ?>" alt="">
        <span class="admin_name">Prem Shahi</span>
        <i class='bx bx-chevron-down'></i>
    </div>
</nav><?php /**PATH /home/u877593591/domains/webreakhost.com/public_html/shopkart/resources/views/frontend/admin/navbar.blade.php ENDPATH**/ ?>
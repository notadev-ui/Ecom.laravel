
<?php $__env->startSection('title', 'category'); ?>

<?php $__env->startSection('content'); ?>


    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>
        <form action="<?php echo e(route('admin.updateCategory')); ?>" method="POST">

            <?php echo csrf_field(); ?>
            <div class="form-row">
                <div class="form-group col-md-12">
                    <input type="hidden" class="form-control" id="categoryId" name="categoryId" maxlength="5000" value="<?php echo e($category->categoryId); ?>">
                </div>
                <div class="form-group col-md-12">
                    <label for="subcategoryName">Category Name</label>
                    <input type="text" class="form-control" id="categoryName" name="categoryName" maxlength="5000" value="<?php echo e($category->categoryName); ?>">
                </div>
            </div>



            <button type="submit" class="btn btn-primary mt-5">Submit</button>
        </form>




 <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u877593591/domains/webreakhost.com/public_html/shopkart/resources/views/frontend/admin/updateCategory.blade.php ENDPATH**/ ?>
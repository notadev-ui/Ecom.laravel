

<?php $__env->startSection('main-container'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <style>
        #shopify-section-header .megamenu {
            line-height: 1;
        }

        #shopify-section-header .megamenu a {
            font-size: 0.9em;
        }

        #shopify-section-header .site-nav__dropdown-link--second-level {
            font-size: 0.9em;
        }

        #shopify-section-header .h5 a {
            color: #ec688d;
        }

        #shopify-section-header .mobile-nav .appear-delay-2 a {
            color: #ec688d;
        }

        #shopify-section-header .mobile-nav .appear-delay-3 a {
            color: #9b006f;
        }
    </style>
    </div>
    <div class="container">
    <h1>Your Cart</h1>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(empty($cart)): ?>
        <p>Your cart is empty.</p>
    <?php else: ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Image</th>
                    <th>Product Name</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                    <th>Action</th> <!-- New column for delete button -->

                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <?php
                $total = $item['price'] * $item['quantity'];
            ?>
                    <tr>
                        <td><img src="<?php echo e(asset('image/' . $item['image'])); ?>" style="height: 150px;width:200px;" alt="<?php echo e($item['name']); ?>"></td>
                        <td><?php echo e($item['name']); ?></td>
                        <td>₹<?php echo e($item['price']); ?></td>
                        <td>
               <form action="<?php echo e(route('cart.update', $item['product_id'])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <button type="submit" name="action" value="decrease">-</button>
                    <?php echo e($item['quantity']); ?>

                    <button type="submit" name="action" value="increase">+</button>
                </form>
            </td>
                            <td>₹<?php echo e($total); ?></td>
 <td>
                    <form action="<?php echo e(route('cart.delete', $item['product_id'])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit"><i class="fa fa-trash-o btn btn-danger" aria-hidden="true"></i></button>
                        <a href="<?php echo e(route('product.view', $item['product_id'])); ?>" type="submit"><i class="fa fa-eye btn btn-primary" aria-hidden="true"></i></a>
                    </form>
                </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
    
     <div class="cart-view-total">
               <h4>Cart Totals</h4>
              <table class="table">
    <tbody>
        <tr>
            <th>Subtotal   -</th>
            <td></td>
        </tr>
        <?php
            $grandTotal = 0;
        ?>
        <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $total = $item['price'] * $item['quantity'];
                $grandTotal += $total;
            ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th>Total   -</th>
            <td>₹<?php echo e($grandTotal); ?></td>
        </tr>
    </tbody>
</table>
<div class="d-flex justify-content-center mt-4 mb-4" >
                   <a href="#" class="btn "style="background:#ec688d; color:black;">Proced to Checkout</a>

</div>
             </div>
</div>
        
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u877593591/domains/webreakhost.com/public_html/shop24/resources/views/frontend/cart.blade.php ENDPATH**/ ?>
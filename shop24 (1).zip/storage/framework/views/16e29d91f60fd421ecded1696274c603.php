

<?php $__env->startSection('main-container'); ?>

<style> #shopify-section-header .megamenu {line-height: 1;} #shopify-section-header .megamenu a {font-size: 0.9em;} #shopify-section-header .site-nav__dropdown-link--second-level {font-size: 0.9em;} #shopify-section-header .h5 a {color: #ec688d;} #shopify-section-header .mobile-nav .appear-delay-2 a {color: #ec688d;} #shopify-section-header .mobile-nav .appear-delay-3 a {color: #9b006f;} </style></div><main class="main-content" id="MainContent">
    <div class="page-width page-width--tiny page-content">
        <style> 
.section-header__title h1
{
text-transform: uppercase!important;
}
.page-container h1 
{
color: #ec688d!important;
} 
</style>
<header class="section-header">
<h1 class="section-header__title" style="color:#ec688d;">Login</h1>
</header>
<?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
<div class="note note--success hide" id="ResetSuccess">
We&#39;ve sent you an email with a link to update your password.
</div>
<form method="POST" action="<?php echo e(route('store.login')); ?>">
<?php echo csrf_field(); ?>

<label for="CustomerEmail">Email</label>
<input type="email" name="email" id="CustomerEmail" class="input-full" autocorrect="off" autocapitalize="off" autofocus><div class="grid">
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <div class="grid__item one-half">
      <label for="CustomerPassword">Password</label>
    </div>
    <div class="grid__item one-half text-right">
      <small class="label-info">
        <a href="#recover" id="RecoverPassword">
          Forgot password?
        </a>
      </small>
    </div>
  </div>
  <input type="password" value="" name="password" id="CustomerPassword" class="input-full"><p>
      <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

  <button type="submit" class="btn btn--full">
    Sign In
  </button>
</p>
<p><a href="<?php echo e(route('user.register')); ?>" id="customer_register_link">Create account</a></p><input type="hidden" name="return_url" value="/account" /></form></div>


</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u877593591/domains/webreakhost.com/public_html/shop24/resources/views/frontend/signin.blade.php ENDPATH**/ ?>
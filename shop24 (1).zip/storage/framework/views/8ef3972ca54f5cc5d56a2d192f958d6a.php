</div>

</main><div id="shopify-section-footer-promotions" class="shopify-section index-section--footer">
</div><div id="shopify-section-footer" class="shopify-section"><style data-shopify>.site-footer {
border-top: 1px solid #e8e8e1;
}</style><footer class="site-footer" data-section-id="footer" data-section-type="footer-section">
<div class="page-width">

<div class="grid"><div  class="grid__item footer__item--b38b23c3-4cf3-4ca2-b2da-d3c8066e92b2" data-type="menu"><style data-shopify>@media only screen and (min-width: 769px) and (max-width: 959px) {
      .footer__item--b38b23c3-4cf3-4ca2-b2da-d3c8066e92b2 {
        width: 50%;
        padding-top: 40px;
      }
      .footer__item--b38b23c3-4cf3-4ca2-b2da-d3c8066e92b2:nth-child(2n + 1) {
        clear: left;
      }
    }
    @media only screen and (min-width: 960px) {
      .footer__item--b38b23c3-4cf3-4ca2-b2da-d3c8066e92b2 {
        width: 25%;
      }

    }</style><p class="h4 footer__title small--hide">
Menu
</p>
<button type="button" class="h4 footer__title collapsible-trigger collapsible-trigger-btn medium-up--hide" aria-controls="Footer-b38b23c3-4cf3-4ca2-b2da-d3c8066e92b2">
Menu
<span class="collapsible-trigger__icon collapsible-trigger__icon--open" role="presentation">
<svg aria-hidden="true" focusable="false" role="presentation" class="icon icon--wide icon-chevron-down" viewBox="0 0 28 16"><path d="M1.57 1.59l12.76 12.77L27.1 1.59" stroke-width="2" stroke="#000" fill="none" fill-rule="evenodd"/></svg>
</span>
</button><div

id="Footer-b38b23c3-4cf3-4ca2-b2da-d3c8066e92b2" class="collapsible-content collapsible-content--small"
>
<div class="collapsible-content__inner">
<div class="footer__collapsible">
<ul class="no-bullets site-footer__linklist"><li><a href="about-us.html">About Us</a></li><li><a href="tribe.html">Shopkart Tribe</a></li><li><a href="press.html">Press</a></li><li><a href="../blogs/Shopkart.html">Blog</a></li><li><a href="contact-us.html">Contact Us</a></li></ul>
</div>
</div>
</div></div><div  class="grid__item footer__item--1494301487049" data-type="menu"><style data-shopify>@media only screen and (min-width: 769px) and (max-width: 959px) {
      .footer__item--1494301487049 {
        width: 50%;
        padding-top: 40px;
      }
      .footer__item--1494301487049:nth-child(2n + 1) {
        clear: left;
      }
    }
    @media only screen and (min-width: 960px) {
      .footer__item--1494301487049 {
        width: 25%;
      }

    }</style><p class="h4 footer__title small--hide">
Quick Links
</p>
<button type="button" class="h4 footer__title collapsible-trigger collapsible-trigger-btn medium-up--hide" aria-controls="Footer-1494301487049">
Quick Links
<span class="collapsible-trigger__icon collapsible-trigger__icon--open" role="presentation">
<svg aria-hidden="true" focusable="false" role="presentation" class="icon icon--wide icon-chevron-down" viewBox="0 0 28 16"><path d="M1.57 1.59l12.76 12.77L27.1 1.59" stroke-width="2" stroke="#000" fill="none" fill-rule="evenodd"/></svg>
</span>
</button><div

id="Footer-1494301487049" class="collapsible-content collapsible-content--small"
>
<div class="collapsible-content__inner">
<div class="footer__collapsible">
<ul class="no-bullets site-footer__linklist"><li><a href="privacy-policy.html">Privacy Policy</a></li><li><a href="terms-conditions.html">Terms & Conditions</a></li><li><a href="shipping-information.html">Shipping Policy</a></li><li><a href="returns-exchanges.html">Returns & Exchanges</a></li><li><a href="faq.html">FAQ</a></li><li><a href="cancellation-policy.html">Cancellation Policy</a></li><li><a href="../policies/refund-policy.html">Refund Policy</a></li></ul>
</div>
</div>
</div></div><div  class="grid__item footer__item--1494292487693" data-type="newsletter"><style data-shopify>@media only screen and (min-width: 769px) and (max-width: 959px) {
      .footer__item--1494292487693 {
        width: 50%;
        padding-top: 40px;
      }
      .footer__item--1494292487693:nth-child(2n + 1) {
        clear: left;
      }
    }
    @media only screen and (min-width: 960px) {
      .footer__item--1494292487693 {
        width: 25%;
      }

    }</style><div class="footer__item-padding"><p class="h4 footer__title small--hide">Sign up and save</p>
<button type="button" class="h4 footer__title collapsible-trigger collapsible-trigger-btn medium-up--hide" aria-controls="Footer-1494292487693">
Sign up and save
<span class="collapsible-trigger__icon collapsible-trigger__icon--open" role="presentation">
<svg aria-hidden="true" focusable="false" role="presentation" class="icon icon--wide icon-chevron-down" viewBox="0 0 28 16"><path d="M1.57 1.59l12.76 12.77L27.1 1.59" stroke-width="2" stroke="#000" fill="none" fill-rule="evenodd"/></svg>
</span>
</button><div

id="Footer-1494292487693" class="collapsible-content collapsible-content--small"
>
<div class="collapsible-content__inner">
<div class="footer__collapsible"><p>Subscribe to get special offers, free giveaways, and once-in-a-lifetime deals.</p>
<form method="post" action="https://Shopkart.in/contact#newsletter-footer" id="newsletter-footer" accept-charset="UTF-8" class="contact-form"><input type="hidden" name="form_type" value="customer" /><input type="hidden" name="utf8" value="✓" /><label for="Email-1494292487693" class="hidden-label">Enter your email</label>
  <input type="hidden" name="contact[tags]" value="prospect,newsletter">
  <input type="hidden" name="contact[context]" value="footer">
  <div class="footer__newsletter">
    <input type="email" value="" placeholder="Enter your email" name="contact[email]" id="Email-1494292487693" class="footer__newsletter-input" autocorrect="off" autocapitalize="off">
    <button type="submit" class="footer__newsletter-btn" name="commit" aria-label="Subscribe">
      <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-email" viewBox="0 0 64 64"><path d="M63 52H1V12h62zM1 12l25.68 24h9.72L63 12M21.82 31.68L1.56 51.16m60.78.78L41.27 31.68"/></svg>
      <span class="footer__newsletter-btn-label">
        Subscribe
      </span>
    </button>
  </div></form><ul class="no-bullets footer__social"><li>
      <a target="_blank" rel="noopener" href="https://www.instagram.com/Shopkart_designs/" title="Shopkart on Instagram">
        <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-instagram" viewBox="0 0 32 32"><path fill="#444" d="M16 3.094c4.206 0 4.7.019 6.363.094 1.538.069 2.369.325 2.925.544.738.287 1.262.625 1.813 1.175s.894 1.075 1.175 1.813c.212.556.475 1.387.544 2.925.075 1.662.094 2.156.094 6.363s-.019 4.7-.094 6.363c-.069 1.538-.325 2.369-.544 2.925-.288.738-.625 1.262-1.175 1.813s-1.075.894-1.813 1.175c-.556.212-1.387.475-2.925.544-1.663.075-2.156.094-6.363.094s-4.7-.019-6.363-.094c-1.537-.069-2.369-.325-2.925-.544-.737-.288-1.263-.625-1.813-1.175s-.894-1.075-1.175-1.813c-.212-.556-.475-1.387-.544-2.925-.075-1.663-.094-2.156-.094-6.363s.019-4.7.094-6.363c.069-1.537.325-2.369.544-2.925.287-.737.625-1.263 1.175-1.813s1.075-.894 1.813-1.175c.556-.212 1.388-.475 2.925-.544 1.662-.081 2.156-.094 6.363-.094zm0-2.838c-4.275 0-4.813.019-6.494.094-1.675.075-2.819.344-3.819.731-1.037.4-1.913.944-2.788 1.819S1.486 4.656 1.08 5.688c-.387 1-.656 2.144-.731 3.825-.075 1.675-.094 2.213-.094 6.488s.019 4.813.094 6.494c.075 1.675.344 2.819.731 3.825.4 1.038.944 1.913 1.819 2.788s1.756 1.413 2.788 1.819c1 .387 2.144.656 3.825.731s2.213.094 6.494.094 4.813-.019 6.494-.094c1.675-.075 2.819-.344 3.825-.731 1.038-.4 1.913-.944 2.788-1.819s1.413-1.756 1.819-2.788c.387-1 .656-2.144.731-3.825s.094-2.212.094-6.494-.019-4.813-.094-6.494c-.075-1.675-.344-2.819-.731-3.825-.4-1.038-.944-1.913-1.819-2.788s-1.756-1.413-2.788-1.819c-1-.387-2.144-.656-3.825-.731C20.812.275 20.275.256 16 .256z"/><path fill="#444" d="M16 7.912a8.088 8.088 0 0 0 0 16.175c4.463 0 8.087-3.625 8.087-8.088s-3.625-8.088-8.088-8.088zm0 13.338a5.25 5.25 0 1 1 0-10.5 5.25 5.25 0 1 1 0 10.5zM26.294 7.594a1.887 1.887 0 1 1-3.774.002 1.887 1.887 0 0 1 3.774-.003z"/></svg>
        <span class="icon__fallback-text">Instagram</span>
      </a>
    </li></ul>
</div>
</div>
</div>
</div>
</div><div  class="grid__item footer__item--ba380d2f-6f82-4fc5-b698-900dfb47455b" data-type="custom"><style data-shopify>@media only screen and (min-width: 769px) and (max-width: 959px) {
      .footer__item--ba380d2f-6f82-4fc5-b698-900dfb47455b {
        width: 50%;
        padding-top: 40px;
      }
      .footer__item--ba380d2f-6f82-4fc5-b698-900dfb47455b:nth-child(2n + 1) {
        clear: left;
      }
    }
    @media only screen and (min-width: 960px) {
      .footer__item--ba380d2f-6f82-4fc5-b698-900dfb47455b {
        width: 25%;
      }

    }</style><div class="footer__item-padding"><p class="h4 footer__title small--hide">Contact Us</p>
<button type="button" class="h4 footer__title collapsible-trigger collapsible-trigger-btn medium-up--hide" aria-controls="Footer-ba380d2f-6f82-4fc5-b698-900dfb47455b">
Contact Us
<span class="collapsible-trigger__icon collapsible-trigger__icon--open" role="presentation">
<svg aria-hidden="true" focusable="false" role="presentation" class="icon icon--wide icon-chevron-down" viewBox="0 0 28 16"><path d="M1.57 1.59l12.76 12.77L27.1 1.59" stroke-width="2" stroke="#000" fill="none" fill-rule="evenodd"/></svg>
</span>
</button><div

id="Footer-ba380d2f-6f82-4fc5-b698-900dfb47455b" class="collapsible-content collapsible-content--small"
>
<div class="collapsible-content__inner">
<div class="footer__collapsible"><p>Shopkart, A-3007, Marathon Futurex, Mafatlal Mills Compound, N. M. Joshi Marg, Lower Parel, Mumbai – 400013</p><p><strong>For Order Related Queries:<br/></strong><a href="https://api.whatsapp.com/send/?phone=918850934728&amp;text=Hello%2C+I+have+a+query+about+one+of+your+products.&amp;type=phone_number&amp;app_absent=0" target="_blank" title="https://api.whatsapp.com/send/?phone=918850934728&text=Hello%2C+I+have+a+query+about+one+of+your+products.&type=phone_number&app_absent=0"><strong>+91 8850934728</strong></a></p><p>Please get in touch with the above mentioned number on WhatsApp only</p><p><strong>Mon - Sat (11 AM - 6 PM)</strong></p><p>Or write to us on support@Shopkart.in</p>
</div>
</div>
</div>
</div>
</div></div><div class="sb-footer-payment">
<ul class="inline-list payment-icons footer__section"><li class="icon--payment">
      <svg viewBox="0 0 38 24" xmlns="http://www.w3.org/2000/svg" role="img" width="38" height="24" aria-labelledby="pi-visa"><title id="pi-visa">Visa</title><path opacity=".07" d="M35 0H3C1.3 0 0 1.3 0 3v18c0 1.7 1.4 3 3 3h32c1.7 0 3-1.3 3-3V3c0-1.7-1.4-3-3-3z"></path><path fill="#fff" d="M35 1c1.1 0 2 .9 2 2v18c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2V3c0-1.1.9-2 2-2h32"></path><path d="M28.3 10.1H28c-.4 1-.7 1.5-1 3h1.9c-.3-1.5-.3-2.2-.6-3zm2.9 5.9h-1.7c-.1 0-.1 0-.2-.1l-.2-.9-.1-.2h-2.4c-.1 0-.2 0-.2.2l-.3.9c0 .1-.1.1-.1.1h-2.1l.2-.5L27 8.7c0-.5.3-.7.8-.7h1.5c.1 0 .2 0 .2.2l1.4 6.5c.1.4.2.7.2 1.1.1.1.1.1.1.2zm-13.4-.3l.4-1.8c.1 0 .2.1.2.1.7.3 1.4.5 2.1.4.2 0 .5-.1.7-.2.5-.2.5-.7.1-1.1-.2-.2-.5-.3-.8-.5-.4-.2-.8-.4-1.1-.7-1.2-1-.8-2.4-.1-3.1.6-.4.9-.8 1.7-.8 1.2 0 2.5 0 3.1.2h.1c-.1.6-.2 1.1-.4 1.7-.5-.2-1-.4-1.5-.4-.3 0-.6 0-.9.1-.2 0-.3.1-.4.2-.2.2-.2.5 0 .7l.5.4c.4.2.8.4 1.1.6.5.3 1 .8 1.1 1.4.2.9-.1 1.7-.9 2.3-.5.4-.7.6-1.4.6-1.4 0-2.5.1-3.4-.2-.1.2-.1.2-.2.1zm-3.5.3c.1-.7.1-.7.2-1 .5-2.2 1-4.5 1.4-6.7.1-.2.1-.3.3-.3H18c-.2 1.2-.4 2.1-.7 3.2-.3 1.5-.6 3-1 4.5 0 .2-.1.2-.3.2M5 8.2c0-.1.2-.2.3-.2h3.4c.5 0 .9.3 1 .8l.9 4.4c0 .1 0 .1.1.2 0-.1.1-.1.1-.1l2.1-5.1c-.1-.1 0-.2.1-.2h2.1c0 .1 0 .1-.1.2l-3.1 7.3c-.1.2-.1.3-.2.4-.1.1-.3 0-.5 0H9.7c-.1 0-.2 0-.2-.2L7.9 9.5c-.2-.2-.5-.5-.9-.6-.6-.3-1.7-.5-1.9-.5L5 8.2z" fill="#142688"></path></svg>
    </li><li class="icon--payment">
      <svg viewBox="0 0 38 24" xmlns="http://www.w3.org/2000/svg" role="img" width="38" height="24" aria-labelledby="pi-master"><title id="pi-master">Mastercard</title><path opacity=".07" d="M35 0H3C1.3 0 0 1.3 0 3v18c0 1.7 1.4 3 3 3h32c1.7 0 3-1.3 3-3V3c0-1.7-1.4-3-3-3z"></path><path fill="#fff" d="M35 1c1.1 0 2 .9 2 2v18c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2V3c0-1.1.9-2 2-2h32"></path><circle fill="#EB001B" cx="15" cy="12" r="7"></circle><circle fill="#F79E1B" cx="23" cy="12" r="7"></circle><path fill="#FF5F00" d="M22 12c0-2.4-1.2-4.5-3-5.7-1.8 1.3-3 3.4-3 5.7s1.2 4.5 3 5.7c1.8-1.2 3-3.3 3-5.7z"></path></svg>
    </li><li class="icon--payment">
      <svg xmlns="http://www.w3.org/2000/svg" role="img" viewBox="0 0 38 24" width="38" height="24" aria-labelledby="pi-american_express"><title id="pi-american_express">American Express</title><g fill="none"><path fill="#000" d="M35,0 L3,0 C1.3,0 0,1.3 0,3 L0,21 C0,22.7 1.4,24 3,24 L35,24 C36.7,24 38,22.7 38,21 L38,3 C38,1.3 36.6,0 35,0 Z" opacity=".07"></path><path fill="#006FCF" d="M35,1 C36.1,1 37,1.9 37,3 L37,21 C37,22.1 36.1,23 35,23 L3,23 C1.9,23 1,22.1 1,21 L1,3 C1,1.9 1.9,1 3,1 L35,1"></path><path fill="#FFF" d="M8.971,10.268 L9.745,12.144 L8.203,12.144 L8.971,10.268 Z M25.046,10.346 L22.069,10.346 L22.069,11.173 L24.998,11.173 L24.998,12.412 L22.075,12.412 L22.075,13.334 L25.052,13.334 L25.052,14.073 L27.129,11.828 L25.052,9.488 L25.046,10.346 L25.046,10.346 Z M10.983,8.006 L14.978,8.006 L15.865,9.941 L16.687,8 L27.057,8 L28.135,9.19 L29.25,8 L34.013,8 L30.494,11.852 L33.977,15.68 L29.143,15.68 L28.065,14.49 L26.94,15.68 L10.03,15.68 L9.536,14.49 L8.406,14.49 L7.911,15.68 L4,15.68 L7.286,8 L10.716,8 L10.983,8.006 Z M19.646,9.084 L17.407,9.084 L15.907,12.62 L14.282,9.084 L12.06,9.084 L12.06,13.894 L10,9.084 L8.007,9.084 L5.625,14.596 L7.18,14.596 L7.674,13.406 L10.27,13.406 L10.764,14.596 L13.484,14.596 L13.484,10.661 L15.235,14.602 L16.425,14.602 L18.165,10.673 L18.165,14.603 L19.623,14.603 L19.647,9.083 L19.646,9.084 Z M28.986,11.852 L31.517,9.084 L29.695,9.084 L28.094,10.81 L26.546,9.084 L20.652,9.084 L20.652,14.602 L26.462,14.602 L28.076,12.864 L29.624,14.602 L31.499,14.602 L28.987,11.852 L28.986,11.852 Z"></path></g></svg>

    </li><li class="icon--payment">
      <svg viewBox="0 0 38 24" xmlns="http://www.w3.org/2000/svg" width="38" height="24" role="img" aria-labelledby="pi-paypal"><title id="pi-paypal">PayPal</title><path opacity=".07" d="M35 0H3C1.3 0 0 1.3 0 3v18c0 1.7 1.4 3 3 3h32c1.7 0 3-1.3 3-3V3c0-1.7-1.4-3-3-3z"></path><path fill="#fff" d="M35 1c1.1 0 2 .9 2 2v18c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2V3c0-1.1.9-2 2-2h32"></path><path fill="#003087" d="M23.9 8.3c.2-1 0-1.7-.6-2.3-.6-.7-1.7-1-3.1-1h-4.1c-.3 0-.5.2-.6.5L14 15.6c0 .2.1.4.3.4H17l.4-3.4 1.8-2.2 4.7-2.1z"></path><path fill="#3086C8" d="M23.9 8.3l-.2.2c-.5 2.8-2.2 3.8-4.6 3.8H18c-.3 0-.5.2-.6.5l-.6 3.9-.2 1c0 .2.1.4.3.4H19c.3 0 .5-.2.5-.4v-.1l.4-2.4v-.1c0-.2.3-.4.5-.4h.3c2.1 0 3.7-.8 4.1-3.2.2-1 .1-1.8-.4-2.4-.1-.5-.3-.7-.5-.8z"></path><path fill="#012169" d="M23.3 8.1c-.1-.1-.2-.1-.3-.1-.1 0-.2 0-.3-.1-.3-.1-.7-.1-1.1-.1h-3c-.1 0-.2 0-.2.1-.2.1-.3.2-.3.4l-.7 4.4v.1c0-.3.3-.5.6-.5h1.3c2.5 0 4.1-1 4.6-3.8v-.2c-.1-.1-.3-.2-.5-.2h-.1z"></path></svg>
    </li><li class="icon--payment">
      <svg viewBox="0 0 38 24" xmlns="http://www.w3.org/2000/svg" role="img" width="38" height="24" aria-labelledby="pi-diners_club"><title id="pi-diners_club">Diners Club</title><path opacity=".07" d="M35 0H3C1.3 0 0 1.3 0 3v18c0 1.7 1.4 3 3 3h32c1.7 0 3-1.3 3-3V3c0-1.7-1.4-3-3-3z"></path><path fill="#fff" d="M35 1c1.1 0 2 .9 2 2v18c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2V3c0-1.1.9-2 2-2h32"></path><path d="M12 12v3.7c0 .3-.2.3-.5.2-1.9-.8-3-3.3-2.3-5.4.4-1.1 1.2-2 2.3-2.4.4-.2.5-.1.5.2V12zm2 0V8.3c0-.3 0-.3.3-.2 2.1.8 3.2 3.3 2.4 5.4-.4 1.1-1.2 2-2.3 2.4-.4.2-.4.1-.4-.2V12zm7.2-7H13c3.8 0 6.8 3.1 6.8 7s-3 7-6.8 7h8.2c3.8 0 6.8-3.1 6.8-7s-3-7-6.8-7z" fill="#3086C8"></path></svg>
    </li><li class="icon--payment">
      <svg viewBox="0 0 38 24" width="38" height="24" role="img" aria-labelledby="pi-discover" fill="none" xmlns="http://www.w3.org/2000/svg"><title id="pi-discover">Discover</title><path fill="#000" opacity=".07" d="M35 0H3C1.3 0 0 1.3 0 3v18c0 1.7 1.4 3 3 3h32c1.7 0 3-1.3 3-3V3c0-1.7-1.4-3-3-3z"></path><path d="M35 1c1.1 0 2 .9 2 2v18c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2V3c0-1.1.9-2 2-2h32z" fill="#fff"></path><path d="M3.57 7.16H2v5.5h1.57c.83 0 1.43-.2 1.96-.63.63-.52 1-1.3 1-2.11-.01-1.63-1.22-2.76-2.96-2.76zm1.26 4.14c-.34.3-.77.44-1.47.44h-.29V8.1h.29c.69 0 1.11.12 1.47.44.37.33.59.84.59 1.37 0 .53-.22 1.06-.59 1.39zm2.19-4.14h1.07v5.5H7.02v-5.5zm3.69 2.11c-.64-.24-.83-.4-.83-.69 0-.35.34-.61.8-.61.32 0 .59.13.86.45l.56-.73c-.46-.4-1.01-.61-1.62-.61-.97 0-1.72.68-1.72 1.58 0 .76.35 1.15 1.35 1.51.42.15.63.25.74.31.21.14.32.34.32.57 0 .45-.35.78-.83.78-.51 0-.92-.26-1.17-.73l-.69.67c.49.73 1.09 1.05 1.9 1.05 1.11 0 1.9-.74 1.9-1.81.02-.89-.35-1.29-1.57-1.74zm1.92.65c0 1.62 1.27 2.87 2.9 2.87.46 0 .86-.09 1.34-.32v-1.26c-.43.43-.81.6-1.29.6-1.08 0-1.85-.78-1.85-1.9 0-1.06.79-1.89 1.8-1.89.51 0 .9.18 1.34.62V7.38c-.47-.24-.86-.34-1.32-.34-1.61 0-2.92 1.28-2.92 2.88zm12.76.94l-1.47-3.7h-1.17l2.33 5.64h.58l2.37-5.64h-1.16l-1.48 3.7zm3.13 1.8h3.04v-.93h-1.97v-1.48h1.9v-.93h-1.9V8.1h1.97v-.94h-3.04v5.5zm7.29-3.87c0-1.03-.71-1.62-1.95-1.62h-1.59v5.5h1.07v-2.21h.14l1.48 2.21h1.32l-1.73-2.32c.81-.17 1.26-.72 1.26-1.56zm-2.16.91h-.31V8.03h.33c.67 0 1.03.28 1.03.82 0 .55-.36.85-1.05.85z" fill="#231F20"></path><path d="M20.16 12.86a2.931 2.931 0 100-5.862 2.931 2.931 0 000 5.862z" fill="url(#pi-paint0_linear)"></path><path opacity=".65" d="M20.16 12.86a2.931 2.931 0 100-5.862 2.931 2.931 0 000 5.862z" fill="url(#pi-paint1_linear)"></path><path d="M36.57 7.506c0-.1-.07-.15-.18-.15h-.16v.48h.12v-.19l.14.19h.14l-.16-.2c.06-.01.1-.06.1-.13zm-.2.07h-.02v-.13h.02c.06 0 .09.02.09.06 0 .05-.03.07-.09.07z" fill="#231F20"></path><path d="M36.41 7.176c-.23 0-.42.19-.42.42 0 .23.19.42.42.42.23 0 .42-.19.42-.42 0-.23-.19-.42-.42-.42zm0 .77c-.18 0-.34-.15-.34-.35 0-.19.15-.35.34-.35.18 0 .33.16.33.35 0 .19-.15.35-.33.35z" fill="#231F20"></path><path d="M37 12.984S27.09 19.873 8.976 23h26.023a2 2 0 002-1.984l.024-3.02L37 12.985z" fill="#F48120"></path><defs><linearGradient id="pi-paint0_linear" x1="21.657" y1="12.275" x2="19.632" y2="9.104" gradientUnits="userSpaceOnUse"><stop stop-color="#F89F20"></stop><stop offset=".25" stop-color="#F79A20"></stop><stop offset=".533" stop-color="#F68D20"></stop><stop offset=".62" stop-color="#F58720"></stop><stop offset=".723" stop-color="#F48120"></stop><stop offset="1" stop-color="#F37521"></stop></linearGradient><linearGradient id="pi-paint1_linear" x1="21.338" y1="12.232" x2="18.378" y2="6.446" gradientUnits="userSpaceOnUse"><stop stop-color="#F58720"></stop><stop offset=".359" stop-color="#E16F27"></stop><stop offset=".703" stop-color="#D4602C"></stop><stop offset=".982" stop-color="#D05B2E"></stop></linearGradient></defs></svg>
    </li></ul>
</div>
<p class="footer__small-text">Developed by <a href="https://www.webreakglobal.com/" target="_blank">Webreak</a></p>

</div>
</footer>


</div></div>
</div><div id="shopify-section-newsletter-popup" class="shopify-section index-section--hidden">
</div><div id="VideoModal" class="modal modal--solid">
<div class="modal__inner">
<div class="modal__centered page-width text-center">
<div class="modal__centered-content">
<div class="video-wrapper video-wrapper--modal">
  <div id="VideoHolder"></div>
</div>
</div>
</div>
</div>

<button type="button" class="modal__close js-modal-close text-link">
<svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close" viewBox="0 0 64 64"><path d="M19 17.61l27.12 27.13m0-27.12L19 44.74"/></svg>
<span class="icon__fallback-text">"Close (esc)"</span>
</button>
</div>
<div class="pswp" tabindex="-1" role="dialog" aria-hidden="true">
<div class="pswp__bg"></div>
<div class="pswp__scroll-wrap">
<div class="pswp__container">
<div class="pswp__item"></div>
<div class="pswp__item"></div>
<div class="pswp__item"></div>
</div>

<div class="pswp__ui pswp__ui--hidden">
<button class="btn btn--body btn--circle pswp__button pswp__button--arrow--left" title="Previous">
<svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-chevron-left" viewBox="0 0 284.49 498.98"><path d="M249.49 0a35 35 0 0 1 24.75 59.75L84.49 249.49l189.75 189.74a35.002 35.002 0 1 1-49.5 49.5L10.25 274.24a35 35 0 0 1 0-49.5L224.74 10.25A34.89 34.89 0 0 1 249.49 0z"/></svg>
</button>

<button class="btn btn--body btn--circle btn--large pswp__button pswp__button--close" title="Close (esc)">
<svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close" viewBox="0 0 64 64"><path d="M19 17.61l27.12 27.13m0-27.12L19 44.74"/></svg>
</button>

<button class="btn btn--body btn--circle pswp__button pswp__button--arrow--right" title="Next">
<svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-chevron-right" viewBox="0 0 284.49 498.98"><path d="M35 498.98a35 35 0 0 1-24.75-59.75l189.74-189.74L10.25 59.75a35.002 35.002 0 0 1 49.5-49.5l214.49 214.49a35 35 0 0 1 0 49.5L59.75 488.73A34.89 34.89 0 0 1 35 498.98z"/></svg>
</button>
</div>
</div>
</div>
<div id="shopify-section-searchTap" class="shopify-section"><!-- Start of SearchTap -->
<link href="../cdn/shop/t/40/assets/searchtap5545.css?v=115480213155218911141714929419" rel="stylesheet" type="text/css" media="all" />
<script src="../cdn/shop/t/40/assets/searchtap0752.js?v=156799589898409486591714929419" defer></script>   <!-- searchtap.js refers to build js file  -->

<script type="text/javascript">

let st_app_id = '3EZI4BWPTGJ1TUG9JKVLPPAG'
let st_app_read_token = 'M69EGBFGXHQW7D9R15V8LN3T';
let st_collection_id = 'LEBPBT6FSD3FPF88T83SU239';
let st_trending_id = 'USW2Z5J4H62FS63M4XIRZC4L';

</script>



<div id="st-searchModal" v-cloak>
         <div v-bind:class="{'st-loading':spinner}">
             <div v-show="!spinner && searchOpen">
             <div id="overlay" v-show="totalHits===0 && !errorFound">
             <div class="container-fluid">
                 <div class="container">
                     <h3 class="page-heading">No results found for
                         <span class="st-colored-text">""</span>
                         . Look for other items in our store
                     </h3>
                     <div class="search-pform">
                         <p><span v-show="isFilterSelected">Try <span class="no-result-filter" v-on:click="removeAllFilters()">clearing</span>
                                    some filters or</span> try searching some other keywords</p>
                     </div>
                 </div>
                 <div class="st-best-seller">
                     <div class="st-notify">Checkout some of our Best Sellers</div>
                     <div class="st-row st-cols-2 st-cols-sm-2 st-cols-md-3 st-product-wrapper">
                         <div class="st-product-wrap" v-bind:class="{'st-double-child':cards.images.length>1}" v-for="cards in bestseller" :key="cards">
                             <div class="st-product" @click="recordProductView(cards.title)">
                                 <figure class="st-product-media">
                                     <div v-show="cards.tags.includes('sale')">
                                         <div class="grid-product__tag grid-product__tag--sale">Sale</div>
                                     </div>
                                     <div v-show="cards.isActive===0">
                                         <div class="grid-product__tag grid-product__tag--sold-out">Sold Out
                                         </div>
                                     </div>
                                     <a v-bind:href="getProductURL(cards.handle)">
                                         <img loading="lazy" v-if="cards.activeImage"  v-bind:src="imageResize(cards.activeImage,getImageSize)">
                                         <img loading="lazy" v-else  v-bind:src="imageResize(cards.images[0],getImageSize)">
                                         <img loading="lazy" v-if="cards.images[1]" v-bind:src="imageResize(cards.images[1],getImageSize)">
                                     </a>
                                     <div class="st-product-action">
                                         <a v-bind:href="getProductURL(cards.handle)"  class="st-btn-product">Quick view</a>
                                     </div>
                                 </figure>
                                 <div class="st-product-details">
                                     <div class="st-product-name">
                                         <a v-bind:href="getProductURL(cards.handle)"></a>
                                     </div>
                                     <div class="st-product-price">
                                         <span v-show="cards.discount>0" class="old-price" style=""> </span>
                                         <span class="new-price" v-bind:class="{'st-simple-price':cards.discount === 0}"></span>
                                         <span v-show="cards.discount>0" class="st-save" style="">Save</span>
                                     </div>
                                     <div class="st-product-form st-product-swatch">
                                         <div class="st-product-variations">
                                             <a v-if="cards.activeOption && cards.activeOption.length > 1" v-for="color in cards.activeOption" :key="color"
                                                v-on:mouseover="changeActiveVariantBestseller(cards.id,color)"
                                                class="swatch" v-bind:style="{backgroundImage:'url('+ `https://cdn.shopify.com/s/files/1/0566/1884/4329/t/2/assets/${getColor(color)}_50x.png` +')', backgroundColor: color.split(' ').pop()}"
                                                style="border-radius: 50%;"></a>
                                         </div>
                                     </div>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
             <div class="st-after-loading" v-show="totalHits">
             <div v-show="!errorFound">
             <div id="searchModalContainer" class="st-container">
                 <div class="st-row st-main-content-wrap">
                <div class="st-col-lg-3 st-col-md-3 sidebar st-hidden-sm">
                    <div class="st-sidebar-content">
<!--                                <div class="st-filter-header">
                            <div class="st-width">
                                <h4 class="filter-title">
                                    Filter by
                                    <span class="st-pull-right">
                                    <span class="st-reset-all" v-on:click="removeAllFilters()" v-show="isFilterSelected">RESET ALL</span>
                                                    </span>
                                </h4>
                            </div>
                        </div>-->
                        <ul v-show="isFilterSelected" class="st-selected-filters">
                            <li class="st-select-li" v-for="tags in checkedList" :key="tags.field" @click="removeSingleFilter(tags.selected, tags.field)">
                                <div class="st-filter-tag-wrapper">
                                    <a v-if="tags.type==='textFacets' || tags.type==='singleStatic'" class="st-selected-tag-name" :title='"Remove tag " + tags.selected'>
                                        <span class="st-selected-tag"></span>
                                    </a>
                                    <a v-else-if="tags.type==='numericFacets'" class="st-selected-tag-name" :title='"Remove tag " + tags.selected[0]+"-"+tags.selected[0]'>
                                        <div v-if="tags.field === 'discounted_price'">
                                            <div v-show="tags.selected[1] !== 9999999"></div>
                                            <div v-show="tags.selected[1] === 9999999"> And Above</div>
                                        </div>
                                        <div v-else-if="tags.field === 'discount'">  And Above</div>
                                    </a>
                                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close" viewBox="0 0 64 64"><path d="M19 17.61l27.12 27.13m0-27.12L19 44.74"></path></svg>
                                </div>
                            </li>
                        </ul>
                        <div class="st-widget st-head-item" v-for="filter in filters" :key="filter" v-show="filter.values.length>0">
                            <h3 class="st-widget-title" v-on:click="filter.isOpen=!filter.isOpen">
                                <span class="st-pull-right">
<!--                                            <span class="filter-clear" v-show="filter.selected.length" v-on:click.stop="removeAllFilters(filter.field)">Clear</span>-->
                                    <span class="st-filter-arrows" v-if="filter.isOpen===true"><svg focusable="false" width="14px" viewBox="0 0 12 8" role="presentation" class="st-icon--arrow-up"><path stroke="currentColor" stroke-width="1" d="M10 2L6 6 2 2" fill="none" stroke-linecap="square"></path></svg></span>
                                    <span class="st-filter-arrows" v-else-if="filter.isOpen===false"><svg focusable="false" width="14px" viewBox="0 0 12 8" role="presentation" class="st-icon--arrow-bottom"><path stroke="currentColor" stroke-width="1" d="M10 2L6 6 2 2" fill="none" stroke-linecap="square"></path></svg></span>
                                </span>
                            </h3>
                            <div  v-show="filter.isOpen">
                                <ul class="st-widget-body st-filter-items" v-if="filter.type==='textFacets'">
                                    <li class="st-highlighted-filter" v-for="list in filter.selected" :key="list">
                                        <div class="outer-checkbox">
                                            <label class="st-flex">
                                                <input type="checkbox" v-bind:value="list" v-model="filter.selected" @change="applyFilter(),filterAnalytics('left', filter.title, list)">
                                                <span class="st-checkbox"></span>
                                                <span class="st-filter-label-container">
                                                <span class="filter-label"></span>

                                            </span>
                                            </label>
                                        </div>
                                    </li>
                                    <li v-for="list in getNonSelectedFilters(filter.field)" :key="list.label">
                                        <div class="outer-checkbox">
                                            <label class="st-flex">
                                                <input type="checkbox" v-bind:value="list.label" v-model="filter.selected" @change="applyFilter(),filterAnalytics('left', filter.title, list.label)">
                                                <span class="st-checkbox"></span>
                                                <span class="st-filter-label-container">
                                                <span class="filter-label"></span>
<!--                                                        <span class="st-product-number">)</span>-->
                                            </span>
                                            </label>
                                        </div>
                                    </li>
                                </ul>
                                <ul class="st-widget-body st-filter-items" v-else-if="filter.type==='numericFacets'">
                                    <li class="st-highlighted-filter" v-for="list in filter.selected" :key="list[0]">
                                        <div class="outer-checkbox">
                                            <label class="st-flex" v-if="filter.field === 'discounted_price'">
                                                <input type="checkbox" v-bind:value="[list[0],list[1]]" v-model="filter.selected" @change="applyFilter(),filterAnalytics('left', filter.title, [list[0],list[1]])">
                                                <span class="st-checkbox"></span>
                                                <span class="st-filter-label-container">
                                                <span v-if="list[1]!==9999999" class="filter-label"> -</span>
                                                <span v-else class="filter-label"> And Above</span>
<!--                                                          <span class="st-product-number">()</span>-->
                                            </span>
                                            </label>
                                            <label class="st-flex" v-else-if="filter.field === 'discount' ">
                                                <input type="checkbox" v-bind:value="[list[0],list[1]]" v-model="filter.selected" @change="applyFilter(),filterAnalytics('left', filter.title, [list[0],list[1]])">
                                                <span class="st-checkbox"></span>
                                                <span class="st-filter-label-container">
                                                <span class="filter-label">% And Above</span>
<!--                                                        <span class="st-product-number">()</span>-->
                                            </span>
                                            </label>
                                        </div>
                                    </li>
                                    <li v-for="list in getNonSelectedFilters(filter.field)" :key="list.min" v-show="getSelectedCount(filter.title,list.min)>0">
                                        <div class="outer-checkbox">
                                            <label class="st-flex" v-if="filter.field === 'discounted_price'">
                                                <input type="checkbox" v-bind:value="[list.min,list.max]" v-model="filter.selected" @change="applyFilter(),filterAnalytics('left', filter.title, [list.min,list.max])">
                                                <span class="st-checkbox"></span>
                                                <span class="st-filter-label-container">
                                                <span class="filter-label"v-if="list.max!==9999999"></span>
                                                <span v-else class="filter-label"> And Above</span>
<!--                                                        <span class="st-product-number">()</span>-->
                                            </span>
                                            </label >
                                            <label class="st-flex" v-else-if="filter.field === 'discount'">
                                                <input type="checkbox" v-bind:value="[list.min,list.max]" v-model="filter.selected" @change="applyFilter(),filterAnalytics('left', filter.title, [list.min,list.max])">
                                                <span class="st-checkbox"></span>
                                                <span class="st-filter-label-container">
                                                <span class="filter-label"> And Above</span>
<!--                                                        <span class="st-product-number">()</span>-->
                                            </span>
                                            </label>
                                        </div>
                                    </li>
                                </ul>
                                <ul class="st-widget-body st-filter-items" v-else>
                                    <li class="st-availability" v-for="list in filter.values" :key="list">
                                        <div class="outer-checkbox">
                                            <label class="st-flex">
                                                <input type="checkbox" v-bind:value="list" v-model="filter.selected" @change="applyFilter(),filterAnalytics('left', filter.title, list)">
                                                <span class="st-checkbox"></span>
                                                <span class="st-filter-label-container">
                                                                        <span class="filter-label"></span>
<!--                                                                                  <span class="st-product-number"></span>-->
                                                                    </span>
                                            </label>
                                        </div>
                                    </li>

                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="st-col-lg-9 st-col-md-9 st-main-content">
                    <!-- Filter bar start -->
                    <div class="st-filter-bar hidden-desktop">
                        <div id="sortFilter" class="sortFilterCon">
                <div class="filter_h" v-bind:class="{'st-active-filter':checkedList.length>0}" v-on:click=" showFilterMobile = true">
                    <span v-if="!isFilterSelected" class="disInBlock"><svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-filter" viewBox="0 0 64 64"><path d="M48 42h10M48 42a5 5 0 1 1-5-5 5 5 0 0 1 5 5zM7 42h31M16 22H6M16 22a5 5 0 1 1 5 5 5 5 0 0 1-5-5zM57 22H26"></path></svg> Filter </span>
                    <span v-else-if="isFilterSelected" class="disInBlock"><svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-filter" viewBox="0 0 64 64"><path d="M48 42h10M48 42a5 5 0 1 1-5-5 5 5 0 0 1 5 5zM7 42h31M16 22H6M16 22a5 5 0 1 1 5 5 5 5 0 0 1-5-5zM57 22H26"></path></svg> Filter () </span>
                </div>
                <select class="sort_h" id="st-sort-mobile" name="sort" v-model="selectedSort" v-on:change="applySort()">
                    <option v-for="item in sort" :key="item.label" v-bind:value="item.label"></option>
                </select>
            </div>
                    </div>
                    <!-- Filter bar end -->
                    <div class="st-toolbox">
                        <div class="st-toolbox-left">
                            <div class="st-show-result">
                                <span class="st-show-text">
                                    <span class="st-hidden-sm"></span>
                                    <span></span>
                                    <span class="hidden-desktop" style="padding-left: 4px;"> Product<span class="result-mob" v-show="totalHits > 1">s</span></span>
                                    <span class="st-hidden-sm"> Product<span class="result-mob" v-show="totalHits> 1">s</span> for </span>
                                    <span class="txt-red st-hidden-sm">""</span>
                                </span>
                            </div>
                        </div>
                        <div class="st-toolbox-right st-hidden-sm"><span style="font-size: 14px; margin-right: 0;"></span>
                            <div class="st-form-group">
                                <select id="st-sort" name="sort" v-model="selectedSort" v-on:change="applySort()">
                                    <option v-for="item in sort" :key="item.label" v-bind:value="item.label"></option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="st-row st-cols-2 st-cols-sm-2 st-cols-md-3 st-product-wrapper">
                        <div class="st-product-wrap" v-bind:class="{'st-double-child':cards.images.length>1}" v-for="cards in results" :key="cards">
                            <div class="st-product" @click="recordProductView(cards.title)">
                                <figure class="st-product-media">
                                    <div v-show="cards.tags.includes('sale')">
                                    <div class="grid-product__tag grid-product__tag--sale">Sale</div>
                                    </div>
                                    <div v-show="cards.isActive===0">
                                        <div class="grid-product__tag grid-product__tag--sold-out">Sold Out
                                        </div>
                                    </div>
                                    <a v-bind:href="getProductURL(cards.handle)">
                                        <img v-if="cards.activeImage"  v-bind:src="imageResize(cards.activeImage,getImageSize)">
                                        <img v-else  v-bind:src="imageResize(cards.images[0],getImageSize)">
                                        <img v-if="cards.images[1]" v-bind:src="imageResize(cards.images[1],getImageSize)">
                                    </a>
                                    <div class="st-product-action">
                                        <a v-bind:href="getProductURL(cards.handle)"  class="st-btn-product">Quick view</a>
                                    </div>
                                </figure>
                                <div class="st-product-details">
                                    <div class="st-product-name">
                                        <a v-bind:href="getProductURL(cards.handle)"></a>
                                    </div>
                                    <div class="st-product-price">
                                        <span v-show="cards.discount>0" class="old-price" style=""> </span>
                                        <span class="new-price" v-bind:class="{'st-simple-price':cards.discount === 0}"> </span>
                                        <span v-show="cards.discount>0" class="st-save" style="">Save  </span>
                                    </div>
                                    <div class="st-product-form st-product-swatch">
                                        <div class="st-product-variations">
                                            <a v-if="cards.activeOption && cards.activeOption.length > 1" v-for="color in cards.activeOption" :key="color"
                                               v-on:mouseover="changeActiveVariant(cards.id,color)"
                                               class="swatch" v-bind:style="{backgroundImage:'url('+ `https://cdn.shopify.com/s/files/1/0566/1884/4329/t/2/assets/${getColor(color)}_50x.png` +')', backgroundColor: color.split(' ').pop()}"
                                               style="border-radius: 50%;"></a>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="st-resultLoader text-center" v-show="!resultEnd && totalHits>0"></div>
                    <div id="stResultEnds" class="text-center"><a v-show="resultEnd" class="st-btn">No more products</a></div>
                </div>
            </div>
             </div>
             <div class="st-overlay-active" style="display: none;">
            <div class="st-sorting-wrapper">
                <div class="st-sorting-inner">
                    <ul class="list">
                        <li class="sortby">
                            <div class="st-sort-cross"><svg role="presentation" viewBox="0 0 16 14" class="Icon Icon--close">
                                    <path d="M15 0L1 14m14 0L1 0" stroke="currentColor" fill="none" fill-rule="evenodd"></path>
                                </svg></div>
                            Sort by
                        </li>
                        <li>
                            <div class="ripple-container"><button value="Relevance" class=""><span class="sortByValues"> Relevance</span></button></div>
                        </li>
                        <li>
                            <div class="ripple-container"><button value="Price: Low to High" class=""><span class="sortByValues"> Price: Low to High</span></button></div>
                        </li>
                        <li>
                            <div class="ripple-container"><button value="Price: High to Low" class=""><span class="sortByValues"> Price: High to Low</span></button></div>
                        </li>
                        <li>
                            <div class="ripple-container"><button value="A-Z" class=""><span class="sortByValues"> A-Z</span></button></div>
                        </li>
                        <li>
                            <div class="ripple-container"><button value="Z-A" class=""><span class="sortByValues"> Z-A</span></button></div>
                        </li>
                        <li>
                            <div class="ripple-container"><button value="Oldest to Newest" class=""><span class="sortByValues"> Oldest to Newest</span></button></div>
                        </li>
                        <li>
                            <div class="ripple-container"><button value="Newest to Oldest" class="active-sort"><span class="sortByValues"> Newest to Oldest</span></button></div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
             <!-- Mobile search start-->
                 <div class="mobilesearch hidden-desktop" v-show="showFilterMobile">
                     <div class="filterHeader" id="mobileHeader"> Filter
                         <span class="st-pull-right">
                                <span v-on:click="removeAllFilters()" v-show="isFilterSelected" class="st-reset-all-mobile">Clear All</span>
                                    <span class="st-filter-head-cross" v-on:click="showFilterMobile=false">
                                        <svg height="10px" viewBox="0 0 512.001 512.001" width="10px" x="0px" xml:space="preserve" y="0px">
                                        <path d="M284.286,256.002L506.143,34.144c7.811-7.811,7.811-20.475,0-28.285c-7.811-7.81-20.475-7.811-28.285,0L256,227.717    L34.143,5.859c-7.811-7.811-20.475-7.811-28.285,0c-7.81,7.811-7.811,20.475,0,28.285l221.857,221.857L5.858,477.859    c-7.811,7.811-7.811,20.475,0,28.285c3.905,3.905,9.024,5.857,14.143,5.857c5.119,0,10.237-1.952,14.143-5.857L256,284.287    l221.857,221.857c3.905,3.905,9.024,5.857,14.143,5.857s10.237-1.952,14.143-5.857c7.811-7.811,7.811-20.475,0-28.285    L284.286,256.002z" data-old_color="#000000" data-original="#000000" fill="#4E3830" class="active-path"></path></svg></span>
                                </span>
                     </div>
                     <div class="st-sidebar-content">
                         <ul v-show="isFilterSelected" class="st-selected-filters">
                             <li class="st-select-li" v-for="tags in checkedList" :key="tags.field" @click="removeSingleFilter(tags.selected, tags.field)">
                                 <div class="st-filter-tag-wrapper">
                                     <a v-if="tags.type==='textFacets' || tags.type==='singleStatic'" class="st-selected-tag-name" :title='"Remove tag " + tags.selected'>
                                         <span class="st-selected-tag"></span>
                                     </a>
                                     <a v-else-if="tags.type==='numericFacets'" class="st-selected-tag-name" :title='"Remove tag " + tags.selected[0]+"-"+tags.selected[0]'>
                                         <div v-if="tags.field === 'discounted_price'">
                                             <div v-show="tags.selected[1] !== 9999999</div>
                                             <div v-show="tags.selected[1] === 9999999">And Above</div>
                                         </div>
                                         <div v-else-if="tags.field === 'discount'"> And Above</div>
                                     </a>
                                     <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close" viewBox="0 0 64 64"><path d="M19 17.61l27.12 27.13m0-27.12L19 44.74"></path></svg>
                                 </div>
                             </li>
                         </ul>
                         <div class="st-widget st-head-item" v-for="filter in filters" :key="filter" v-show="filter.values.length>0">
                             <h3 class="st-widget-title" v-on:click="filter.isOpen=!filter.isOpen
                                 <span class="st-pull-right">
                                    <span class="filter-clear" v-show="filter.selected.length" v-on:click.stop="removeAllFilters(filter.field)">Clear</span>
                                    <span class="st-filter-arrows" v-if="filter.isOpen===true"><svg focusable="false" width="14px" viewBox="0 0 12 8" role="presentation" class="st-icon--arrow-up"><path stroke="currentColor" stroke-width="1" d="M10 2L6 6 2 2" fill="none" stroke-linecap="square"></path></svg></span>
                                    <span class="st-filter-arrows" v-else-if="filter.isOpen===false"><svg focusable="false" width="14px" viewBox="0 0 12 8" role="presentation" class="st-icon--arrow-bottom"><path stroke="currentColor" stroke-width="1" d="M10 2L6 6 2 2" fill="none" stroke-linecap="square"></path></svg></span>
                                </span>
                             </h3>
                             <div v-show="filter.isOpen">
                                 <ul class="st-widget-body st-filter-items" v-if="filter.type==='textFacets'">
                                     <li class="st-highlighted-filter" v-for="list in filter.selected" :key="list">
                                         <div class="outer-checkbox">
                                             <label class="st-flex">
                                                 <input type="checkbox" v-bind:value="list" v-model="filter.selected" @change="applyFilter(),filterAnalytics('left', filter.title, list)">
                                                 <span class="st-checkbox"></span>
                                                 <div class="st-filter-label-container">
                                                     <div class="filter-label"></div>
<!--                                                             <span class="st-product-number">()</span>-->
                                                 </div>
                                             </label>
                                         </div>
                                     </li>
                                     <li v-for="list in getNonSelectedFilters(filter.field)" :key="list.label">
                                         <div class="outer-checkbox">
                                             <label class="st-flex">
                                                 <input type="checkbox" v-bind:value="list.label" v-model="filter.selected" @change="applyFilter(),filterAnalytics('left', filter.title, list.label)">
                                                 <span class="st-checkbox"></span>
                                                 <div class="st-filter-label-container">
                                                     <div class="filter-label"></div>
<!--                                                             <span class="st-product-number">()</span>-->
                                                 </div>
                                             </label>
                                         </div>
                                     </li>
                                 </ul>
                                 <ul class="st-widget-body st-filter-items" v-else-if="filter.type==='numericFacets'">
                                     <li class="st-highlighted-filter" v-for="list in filter.selected" :key="list[0]">
                                         <div class="outer-checkbox">
                                             <label class="st-flex" v-if="filter.field === 'discounted_price'">
                                                 <input type="checkbox" type="checkbox" v-bind:value="[list[0],list[1]]" v-model="filter.selected" @change="applyFilter(),filterAnalytics('left', filter.title, [list[0],list[1]])">
                                                 <span class="st-checkbox"></span>
                                                 <div class="st-filter-label-container">
                                                     <div v-if="list[1]!==9999999" class="filter-label">
                                                      
                                                         -
                                                     
                                                     </div>
                                                     <div v-else class="filter-label"> And Above</div>
<!--                                                             <span class="st-product-number">()</span>-->
                                                 </div>
                                             </label>
                                             <label  class="st-flex" v-else-if="filter.field === 'discount'">
                                                 <input type="checkbox" v-bind:value="[list[0],list[1]]" v-model="filter.selected" @change="applyFilter(),filterAnalytics('left', filter.title, [list[0],list[1]])">
                                                 <span class="st-checkbox"></span>
                                                 <div class="st-filter-label-container">
                                                     <div class="filter-label">% And Above</div>
<!--                                                             <span class="st-product-number">/span>-->
                                                 </div>
                                             </label>
                                         </div>
                                     </li>
                                     <li v-for="list in getNonSelectedFilters(filter.field)" :key="list.min" v-show="getSelectedCount(filter.title,list.min)>0">
                                         <div class="outer-checkbox">
                                             <label class="st-flex" v-if="filter.field === 'discounted_price'" class="st-flex">
                                                 <input type="checkbox" v-bind:value="[list.min,list.max]" v-model="filter.selected" @change="applyFilter(),filterAnalytics('left', filter.title, [list.min,list.max])">
                                                 <span class="st-checkbox"></span>
                                                 <div class="st-filter-label-container">
                                                     <div v-if="list.max!==9999999" class="filter-label"></div>
                                                     <div v-else class="filter-label">And Above</div>
<!--                                                             <span class="st-product-number">()</span>-->
                                                 </div>
                                             </label>
                                             <label class="st-flex" v-else-if="filter.field === 'discount' " class="st-flex">
                                                 <input type="checkbox" v-bind:value="[list.min,list.max]" v-model="filter.selected" @change="applyFilter(),filterAnalytics('left', filter.title, [list.min,list.max])">
                                                 <span class="st-checkbox"></span>
                                                 <div class="st-filter-label-container">
                                                     <div class="filter-label needsclick">And Above</div>
<!--                                                             <span class="st-product-number">()</span>-->
                                                 </div>
                                             </label>
                                         </div>
                                     </li>
                                 </ul>
                                 <ul class="st-widget-body st-filter-items" v-else>
                                     <li class="st-availability" v-for="list in filter.values" :key="list">
                                         <div class="outer-checkbox">
                                             <label class="st-flex">
                                                 <input type="checkbox" v-bind:value="list" v-model="filter.selected" @change="applyFilter(),filterAnalytics('left', filter.title, list)">
                                                 <span class="st-checkbox"></span>
                                                 <div class="st-filter-label-container">
                                                     <span class="filter-label"></span>
<!--                                                             <span class="st-product-number"></span>-->
                                                 </div>
                                             </label>
                                         </div>
                                     </li>
                                 </ul>
                             </div>
                         </div>
                     </div>
                     <div v-on:click="showFilterMobile=false" class="apply-all"><a class="apply-btn">Apply Filter</a></div>

                 </div>
                 <div v-show="backToTopBtn" class="scroll-top" v-on:click="goToTop()"><i class='bx bx-chevron-up'></i></div>
             <!-- Mobile search end-->
         </div>
         </div>
         </div>
             <div id="overlay1" v-show="errorFound && !spinner">
             <div class="container">
                 <h2>Oops!!! Something Went Wrong</h2>
                 <p>Please, try <a class="highlight-text" onclick="location.reload()">Reloading</a>
                     page or go back to <a class="highlight-text" :href="baseURL">Home</a> page</p>
             </div>

         </div>
         </div>
     </div>



<!-- End of SearchTap -->
</div>


<link rel="dns-prefetch" href="https://swymstore-v3pro-01.swymrelay.com/" crossorigin>
<link rel="dns-prefetch" href="../../swymv3pro-01.azureedge.net/code/swym-shopify.js">
<link rel="preconnect" href="../../swymv3pro-01.azureedge.net/code/swym-shopify.js">
<script id="swym-snippet">
window.swymLandingURL = document.URL;
window.swymCart = {"note":null,"attributes":{},"original_total_price":0,"total_price":0,"total_discount":0,"total_weight":0.0,"item_count":0,"items":[],"requires_shipping":false,"currency":"INR","items_subtotal_price":0,"cart_level_discount_applications":[],"checkout_charge_amount":0};
window.swymPageLoad = function(){
window.SwymProductVariants = window.SwymProductVariants || {};
window.SwymHasCartItems = 0 > 0;
window.SwymPageData = {}, window.SwymProductInfo = {};
var unknown = {et: 0};
window.SwymPageData = unknown;

window.SwymPageData.uri = window.swymLandingURL;
};

if(window.selectCallback){
(function(){
// Variant select override
var originalSelectCallback = window.selectCallback;
window.selectCallback = function(variant){
originalSelectCallback.apply(this, arguments);
try{
  if(window.triggerSwymVariantEvent){
    window.triggerSwymVariantEvent(variant.id);
  }
}catch(err){
  console.warn("Swym selectCallback", err);
}
};
})();
}
window.swymCustomerId = null;
window.swymCustomerExtraCheck = null;

var swappName = ("Wishlist" || "Wishlist");
var swymJSObject = {
pid: "+cpCcwFAZRxLLU5f56GSftYbsfgqKnDaDQqjqhlTkiA=" || "+cpCcwFAZRxLLU5f56GSftYbsfgqKnDaDQqjqhlTkiA=",
interface: "/apps/swym" + swappName + "/interfaces/interfaceStore.php?appname=" + swappName
};
window.swymJSShopifyLoad = function(){
if(window.swymPageLoad) swymPageLoad();
if(!window._swat) {
(function (s, w, r, e, l, a, y) {
r['SwymRetailerConfig'] = s;
r[s] = r[s] || function (k, v) {
  r[s][k] = v;
};
})('_swrc', '', window);
_swrc('RetailerId', swymJSObject.pid);
_swrc('Callback', function(){initSwymShopify();});
}else if(window._swat.postLoader){
_swrc = window._swat.postLoader;
_swrc('RetailerId', swymJSObject.pid);
_swrc('Callback', function(){initSwymShopify();});
}else{
initSwymShopify();
}
}
if(!window._SwymPreventAutoLoad) {
swymJSShopifyLoad();
}
window.swymGetCartCookies = function(){
var RequiredCookies = ["cart", "swym-session-id", "swym-swymRegid", "swym-email"];
var reqdCookies = {};
RequiredCookies.forEach(function(k){
reqdCookies[k] = _swat.storage.getRaw(k);
});
var cart_token = window.swymCart.token;
var data = {
action:'cart',
token:cart_token,
cookies:reqdCookies
};
return data;
}

window.swymGetCustomerData = function(){

return {status:1};

}
</script>

<style id="safari-flasher-pre"></style>
<script>
if (navigator.userAgent.indexOf('Safari') != -1 && navigator.userAgent.indexOf('Chrome') == -1) {
document.getElementById("safari-flasher-pre").innerHTML = ''
+ '#swym-plugin,#swym-hosted-plugin{display: none;}'
+ '.swym-button.swym-add-to-wishlist{display: none;}'
+ '.swym-button.swym-add-to-watchlist{display: none;}'
+ '#swym-plugin  #swym-notepad, #swym-hosted-plugin  #swym-notepad{opacity: 0; visibility: hidden;}'
+ '#swym-plugin  #swym-notepad, #swym-plugin  #swym-overlay, #swym-plugin  #swym-notification,'
+ '#swym-hosted-plugin  #swym-notepad, #swym-hosted-plugin  #swym-overlay, #swym-hosted-plugin  #swym-notification'
+ '{-webkit-transition: none; transition: none;}'
+ '';
window.SwymCallbacks = window.SwymCallbacks || [];
window.SwymCallbacks.push(function(tracker){
tracker.evtLayer.addEventListener(tracker.JSEvents.configLoaded, function(){
// flash-preventer
var x = function(){
  SwymUtils.onDOMReady(function() {
    var d = document.createElement("div");
    d.innerHTML = "<style id='safari-flasher-post'>"
      + "#swym-plugin:not(.swym-ready),#swym-hosted-plugin:not(.swym-ready){display: none;}"
      + ".swym-button.swym-add-to-wishlist:not(.swym-loaded){display: none;}"
      + ".swym-button.swym-add-to-watchlist:not(.swym-loaded){display: none;}"
      + "#swym-plugin.swym-ready  #swym-notepad, #swym-plugin.swym-ready  #swym-overlay, #swym-plugin.swym-ready  #swym-notification,"
      + "#swym-hosted-plugin.swym-ready  #swym-notepad, #swym-hosted-plugin.swym-ready  #swym-overlay, #swym-hosted-plugin.swym-ready  #swym-notification"
      + "{-webkit-transition: opacity 0.3s, visibility 0.3ms, -webkit-transform 0.3ms !important;-moz-transition: opacity 0.3s, visibility 0.3ms, -moz-transform 0.3ms !important;-ms-transition: opacity 0.3s, visibility 0.3ms, -ms-transform 0.3ms !important;-o-transition: opacity 0.3s, visibility 0.3ms, -o-transform 0.3ms !important;transition: opacity 0.3s, visibility 0.3ms, transform 0.3ms !important;}"
      + "</style>";
    document.head.appendChild(d);
  });
};
setTimeout(x, 10);
});
});
}

// Get the money format for the store from shopify
window.SwymOverrideMoneyFormat = "Rs.;
</script>
<style id="swym-product-view-defaults">
/* Hide when not loaded */
.swym-button.swym-add-to-wishlist-view-product:not(.swym-loaded){
display: none;
}
</style>

<!-- Magic Checkout Code Starts -->

<script>
//    window.widgetIDForMagicCheckout = “shopify-section-header”;
//    window.widgetClassForMagicCheckout = “shopify-section”;
//    window.configForMagicCheckout = {
//     display: {
//         sequence: [“cod”]
//     }
//   };
//  window.nameForMagicCheckout = “”;
window.onDismissMagiCheckout = () => {
location.reload();
}

// window.onCompleteMagiCheckout = (id, price) => {
// }
window.RazorpayMagicBtnConfig = {
dual: false,
showIcon: true,
showSubtext: true,
bgColor: '#ec688d',
title: '', // custom button text
};

window.addEventListener('load',checkBoxCheck);
        function checkBoxCheck(event){
          if(document.getElementById('giftCheck2')){
            document.getElementById('giftCheck2').checked=false;
          }

          if(document.getElementById('giftCheck')){
            document.getElementById('giftCheck').checked=false;
          }

        }
</script>

<input id="rzpKey" type="hidden" name="rzpKey" value="rzp_live_oEnnxwS5n9hfT1">

<script
type="lightJs"
src="../../cdn.razorpay.com/static/shopify/analytics.js"
gtag-conversion-id="AW-316422305"
gtag-conversion-label="oZXrCN2FjeoCEKHx8JYB"
></script>
<script
type="lightJs"
src="../../cdn.razorpay.com/static/shopify/magic-rzp.js"
data-email=""
data-phonenumber=""
></script>

<div id="rzp-spinner-backdrop">
<div id="rzp-spinner">
<div id="loading-indicator">.</div>
</div>
</div>

<style>
#rzp-spinner-backdrop {
position: fixed;
top: 0;
left: 0;
z-index: 9999;
width: 100%;
height: 100%;
background: rgba(0, 0, 0);
visibility: hidden;
opacity: 0;
}
#rzp-spinner-backdrop.show {
visibility: visible;
opacity: 0.4;
}
#rzp-spinner {
visibility: hidden;
opacity: 0;
/* positioning and centering */
position: fixed;
left: 0;
top: 0;
bottom: 0;
right: 0;
margin: auto;
z-index: 10000;
display: flex !important;
align-items: center;
justify-content: center;
}
#rzp-spinner.show {
visibility: visible;
opacity: 1;
}
@keyframes rotate {
0% {
transform: rotate(0);
}
100% {
transform: rotate(360deg);
}
}
#loading-indicator {
border-radius: 50%;
width: 80px;
height: 80px;
border: 4px solid;
border-color: rgb(59, 124, 245) transparent rgb(59, 124, 245) rgb(59, 124, 245) !important;
animation: 1s linear 0s infinite normal none running rotate;
margin-top: 2px;
box-sizing: content-box;
}
</style>

<!-- Magic Checkout Code Ends -->

<!-- "snippets/mlveda-currencies-switcher.liquid" was not rendered, the associated app was uninstalled --><!-- "snippets/mlveda-currencies.liquid" was not rendered, the associated app was uninstalled --><!-- "snippets/mlveda-flag.liquid" was not rendered, the associated app was uninstalled --><!-- "snippets/mlveda-currencies-style.liquid" was not rendered, the associated app was uninstalled -->
<!-- google dynamic remarketing tag for theme.liquid storeya.com -->


<script type="text/javascript">
  window.onload = function() {
if (window.jQuery) {
$(document).ajaxSuccess(function(event, xhr, settings) {
 if (settings.url == "/cart/add.js" || settings.url == "../cart/update.js"){
if(typeof gtag !== "undefined"){
    $.getJSON("../cart.js", function(data) {
  if (!data.items || !data.items.length) return;
  var items = [];
  for (var i = 0; i < data.items.length; i++) {
    var item = data.items[i];
    var tagitem ={id:item.product_id,location_id:item.variant_id,google_business_vertical:'custom'};
    items.push(tagitem);
  }
  var total = parseFloat(data.total_price);
  gtag('event','add_to_cart', {send_to:'AW-11169699495',value:total,currency:data.currency,items:items});
  });}}});
}
}
</script>
<!-- google dynamic remarketing tag for theme.liquid storeya.com End -->
<!-- Google Analytics load on scroll -->
<script>
function analyticsOnScroll() {
  var head = document.getElementsByTagName('head')[0]
  var script = document.createElement('script')
  script.type = 'text/javascript';
  script.src = 'https://www.googletagmanager.com/gtag/js?id=AW-11169699495'
  head.appendChild(script);
  document.removeEventListener('scroll', analyticsOnScroll);
};
document.addEventListener('scroll', analyticsOnScroll);
</script>

<!-- Google tag (gtag.js) -->
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());
gtag('config', 'AW-11169699495');
</script>
<script type="lightJs">
(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'../../www.googletagmanager.com/gtm5445.html?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-PD5BR3H');
</script>
<!-- End Google Tag Manager -->
<style> .section-header__title h1 {text-transform: uppercase;} .page-container h1 {color: #ec688d;} </style>
<div id="shopify-block-10482958812443994587" class="shopify-block shopify-app-block"><script id="bikScript" type="text/javascript">
(async function () {
const response = await fetch(
    `https://bikapi.bikayi.app/dm/storeFrontScriptsApiFunctions-getAllScriptSrc/?storeUrl=${Shopify.shop}&storeType=WHATSAPP`,
    {
      method: "GET",
      mode: "cors",
      cache: "no-cache",
      credentials: "same-origin",
      headers: {
        "Content-Type": "application/json",
      },
      redirect: "follow",
      referrerPolicy: "no-referrer",
    }
);
const sources = await response.json();
sources.data.forEach((src) => {
const scriptTag = document.createElement("script");
scriptTag.setAttribute("src", src);
document.body.appendChild(scriptTag);
});
window.bikWidgetContext = {
currentProduct: {
id: "",
name: "",
variant: {
  id: "",
  name: ""
}
}
}
})();
</script>
<a href="https://bik.ai/" style="z-index: -1; position: fixed; top: -100%; bottom: -100%;"></a>


<script src="<?php echo e(url('frontend/js/searchtab.js')); ?>"></script>
<script src="<?php echo e(url('frontend/js/thememin.js')); ?>"></script>
<script src="<?php echo e(url('frontend/js/vendor-script.js')); ?>"></script>



</div></body>


</html>
<?php /**PATH C:\wamp64\www\ShopKart24\resources\views/frontend/layouts/footer.blade.php ENDPATH**/ ?>
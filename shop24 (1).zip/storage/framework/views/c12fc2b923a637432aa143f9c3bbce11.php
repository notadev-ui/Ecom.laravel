

<?php $__env->startSection('main-container'); ?>

<div id="shopify-section-page-sections-template" class="shopify-section"><div class="page-width page-width--narrow page-content page-content--with-blocks">
   <header class="section-header">
           <h1 class="section-header__title">About Us</h1>
         </header></div>
   <div class="page-blocks"><div ><div class="index-section ">
     <div class="page-width page-width--narrow text-center"><div class="rte"><div class="enlarge-text"><p>Attrangi Designs Pvt. Ltd. - is an embodiment of India's rich culture & art as well as contemporary elegance & sophistication. It was born out of Saloni & Vidushi’s innate love for jewellery, passion for fashion and flair for designing. The jewellery is a play of pretty aesthetics & dramatic styles where each piece is handcrafted using the best stones and quality job work. With an increasing need for stylish jewellery for destination weddings, Attrangi brings in beautifully curated pieces at affordable prices.</p>
   </div></div></div>
   </div>
   </div><div ><div class="index-section ">
     <div class="page-width page-width--narrow text-center"><p class="h2">
           THE ATTRANGI WOMEN
         </p></div>
   </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ShopKart24\resources\views/frontend/about.blade.php ENDPATH**/ ?>
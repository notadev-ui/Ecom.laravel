

<?php $__env->startSection('main-container'); ?>
  <h1>Wishlist</h1>
   <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if($wishlistItems->isEmpty()): ?>
        <p>Your wishlist is empty.</p>
    <?php else: ?>
        <div class="row">
      <?php $__currentLoopData = $wishlistItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-3 m-4">
        <div class="card">
            <img src="<?php echo e(asset('image/' . $item->product->image)); ?>" class="card-img-top" alt="<?php echo e($item->product->productName); ?>">
            <div class="card-body">
                <h5 class="card-title"><?php echo e($item->product->productName); ?></h5>
                <p class="card-text">Price: $<?php echo e($item->product->productPrice); ?></p>
                <form action="<?php echo e(route('cart.add')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="product_id" value="<?php echo e($item->product->productId); ?>">
                    <button type="submit" class="btn" style="width: -webkit-fill-available; background: black; color:white;">Add To Cart</button>
                </form>
                <form action="<?php echo e(route('wishlist.remove', ['id' => $item->product->productId])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="_method" value="DELETE">
        <button type="submit" class="btn mt-2" style="width: -webkit-fill-available; background: white; color: black;" data-product-id="<?php echo e($item->product->productId); ?>">Remove</button>
    </form>
    
     <script>
        document.addEventListener("DOMContentLoaded", function() {
            updateButtonColor("<?php echo e($item->product->productId); ?>", true);
        });
    </script>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



        </div>
    <?php endif; ?>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u877593591/domains/webreakhost.com/public_html/shop24/resources/views/frontend/wishlist.blade.php ENDPATH**/ ?>
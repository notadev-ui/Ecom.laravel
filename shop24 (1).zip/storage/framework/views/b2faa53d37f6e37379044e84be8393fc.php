

<?php $__env->startSection('main-container'); ?>

<main class="main-content" id="MainContent">
    <div id="shopify-section-collection-header" class="shopify-section"><div class="page-width page-content page-content--top">
<header class="section-header section-header--flush">
<h1 class="section-header__title">
    Exclusive Sale
  </h1>
</header>
</div>
<div id="CollectionHeaderSection" data-section-id="collection-header" data-section-type="collection-header">
</div>
<style> #shopify-section-collection-header h1 {color: #000;} #shopify-section-collection-header h1 {text-transform: uppercase;} </style></div>

<div id="CollectionAjaxResult" class="collection-content">
<div id="CollectionAjaxContent">
<div class="page-width">
<div class="grid">
  <div class="grid__item medium-up--one-fifth grid__item--sidebar">
    <div id="shopify-section-collection-sidebar" class="shopify-section"><div id="CollectionSidebar" data-section-id="collection-sidebar" data-section-type="collection-sidebar" data-combine-tags="true" data-style="sidebar"><div id="FilterDrawer" class="drawer drawer--left">
<div class="drawer__contents">
<div class="drawer__fixed-header">
<div class="drawer__header appear-animation appear-delay-1">
  <div class="h2 drawer__title">
    Filter
  </div>
  <div class="drawer__close">
    <button type="button" class="drawer__close-button js-drawer-close">
      <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close" viewBox="0 0 64 64"><path d="M19 17.61l27.12 27.13m0-27.12L19 44.74"></path></svg>
      <span class="icon__fallback-text">Close menu</span>
    </button>
  </div>
</div>
</div><div class="drawer__scrollable appear-animation appear-delay-2"><ul class="no-bullets tag-list tag-list--active-tags"></ul><div class="collection-sidebar__group--5b49c08d-c5b6-4760-951b-022918e91800">

<div class="collection-sidebar__group"><button type="button" class="collapsible-trigger collapsible-trigger-btn collapsible--auto-height tag-list__header" aria-controls="SidebarDrawer-1" aria-expanded="false">
Jewellery Category
<span class="collapsible-trigger__icon collapsible-trigger__icon--open" role="presentation">
<svg aria-hidden="true" focusable="false" role="presentation" class="icon icon--wide icon-chevron-down" viewBox="0 0 28 16"><path d="M1.57 1.59l12.76 12.77L27.1 1.59" stroke-width="2" stroke="#000" fill="none" fill-rule="evenodd"></path></svg>
</span>
</button>
<div id="SidebarDrawer-1" class="collapsible-content collapsible-content--sidebar">
        <div class="collapsible-content__inner">
          
          <ul class="no-bullets tag-list tag-list--checkboxes">
<li class="tag">
                      <a href="sale-1/rings.html" title="Narrow selection to products matching tag Rings">Rings</a>
                    </li>
<li class="tag">
                      <a href="sale-1/nose-rings.html" title="Narrow selection to products matching tag Nose Rings">Nose Rings</a>
                    </li>
<li class="tag">
                      <a href="sale-1/necklace.html" title="Narrow selection to products matching tag Necklace">Necklace</a>
                    </li>

<li class="tag">
                      <a href="sale-1/headgears.html" title="Narrow selection to products matching tag Headgears">Headgears</a>
                    </li>
<li class="tag">
                      <a href="sale-1/mangalsutra.html" title="Narrow selection to products matching tag Mangalsutra">Mangalsutra</a>
                    </li>
<li class="tag">
                      <a href="sale-1/bracelet.html" title="Narrow selection to products matching tag Bracelet">Bracelet</a>
                    </li>


<li class="tag">
                      <a href="sale-1/jewellery-set.html" title="Narrow selection to products matching tag Jewellery Set">Jewellery Set</a>
                    </li>
<li class="tag">
                      <a href="sale-1/earrings.html" title="Narrow selection to products matching tag Earrings">Earrings</a>
                    </li></ul></div>
      </div>
    </div></div><div class="collection-sidebar__group--e5dc5dc6-bdb0-4303-93b9-ba463b079b04">

<div class="collection-sidebar__group"><button type="button" class="collapsible-trigger collapsible-trigger-btn collapsible--auto-height tag-list__header" aria-controls="SidebarDrawer-2" aria-expanded="false">
Jewellery Type
<span class="collapsible-trigger__icon collapsible-trigger__icon--open" role="presentation">
<svg aria-hidden="true" focusable="false" role="presentation" class="icon icon--wide icon-chevron-down" viewBox="0 0 28 16"><path d="M1.57 1.59l12.76 12.77L27.1 1.59" stroke-width="2" stroke="#000" fill="none" fill-rule="evenodd"></path></svg>
</span>
</button>
<div id="SidebarDrawer-2" class="collapsible-content collapsible-content--sidebar">
        <div class="collapsible-content__inner">
          
          <ul class="no-bullets tag-list tag-list--checkboxes">
<li class="tag">
                      <a href="sale-1/diamond.html" title="Narrow selection to products matching tag Diamond">Diamond</a>
                    </li>
<li class="tag">
                      <a href="sale-1/indian.html" title="Narrow selection to products matching tag Indian">Indian</a>
                    </li>
<li class="tag">
                      <a href="sale-1/contemporary.html" title="Narrow selection to products matching tag Contemporary">Contemporary</a>
                    </li></ul></div>
      </div>
    </div></div><div class="collection-sidebar__group--e65c08f1-3877-40e9-aa3b-87da73ea91c3">

<div class="collection-sidebar__group"><button type="button" class="collapsible-trigger collapsible-trigger-btn collapsible--auto-height tag-list__header" aria-controls="SidebarDrawer-3" aria-expanded="false">
Jewellery Style
<span class="collapsible-trigger__icon collapsible-trigger__icon--open" role="presentation">
<svg aria-hidden="true" focusable="false" role="presentation" class="icon icon--wide icon-chevron-down" viewBox="0 0 28 16"><path d="M1.57 1.59l12.76 12.77L27.1 1.59" stroke-width="2" stroke="#000" fill="none" fill-rule="evenodd"></path></svg>
</span>
</button>
<div id="SidebarDrawer-3" class="collapsible-content collapsible-content--sidebar">
        <div class="collapsible-content__inner">
          
          <ul class="no-bullets tag-list tag-list--checkboxes">
<li class="tag">
                      <a href="sale-1/choker-sets.html" title="Narrow selection to products matching tag Choker Sets">Choker Sets</a>
                    </li>
<li class="tag">
                      <a href="sale-1/bridal-sets.html" title="Narrow selection to products matching tag Bridal Sets">Bridal Sets</a>
                    </li>
<li class="tag">
                      <a href="sale-1/necklace-sets.html" title="Narrow selection to products matching tag Necklace Sets">Necklace Sets</a>
                    </li>
<li class="tag">
                      <a href="sale-1/long-sets.html" title="Narrow selection to products matching tag Long Sets">Long Sets</a>
                    </li></ul></div>
      </div>
    </div></div><div class="collection-sidebar__group--3e1934a1-d155-4fa6-87f0-066cdf9871ef">

<div class="collection-sidebar__group"><button type="button" class="collapsible-trigger collapsible-trigger-btn collapsible--auto-height tag-list__header" aria-controls="SidebarDrawer-4" aria-expanded="false">
Collection
<span class="collapsible-trigger__icon collapsible-trigger__icon--open" role="presentation">
<svg aria-hidden="true" focusable="false" role="presentation" class="icon icon--wide icon-chevron-down" viewBox="0 0 28 16"><path d="M1.57 1.59l12.76 12.77L27.1 1.59" stroke-width="2" stroke="#000" fill="none" fill-rule="evenodd"></path></svg>
</span>
</button>
<div id="SidebarDrawer-4" class="collapsible-content collapsible-content--sidebar">
        <div class="collapsible-content__inner">
          
          <ul class="no-bullets tag-list tag-list--checkboxes">
<li class="tag">
                      <a href="sale-1/almaaz.html" title="Narrow selection to products matching tag Almaaz">Almaaz</a>
                    </li>
<li class="tag">
                      <a href="sale-1/jadau.html" title="Narrow selection to products matching tag Jadau">Jadau</a>
                    </li>
<li class="tag">
                      <a href="sale-1/metallic-dust.html" title="Narrow selection to products matching tag Metallic Dust">Metallic Dust</a>
                    </li>
<li class="tag">
                      <a href="sale-1/rajwada.html" title="Narrow selection to products matching tag Rajwada">Rajwada</a>
                    </li>
<li class="tag">
                      <a href="sale-1/victorian-polish-antique-gold.html" title="Narrow selection to products matching tag Victorian Polish / Antique Gold">Victorian Polish / Antique Gold</a>
                    </li>
<li class="tag">
                      <a href="sale-1/lala-land.html" title="Narrow selection to products matching tag Lala Land">Lala Land</a>
                    </li>

<li class="tag">
                      <a href="sale-1/banjaran.html" title="Narrow selection to products matching tag Banjaran">Banjaran</a>
                    </li></ul></div>
      </div>
    </div></div><div class="collection-sidebar__group--3c8d2405-8bd8-46b3-ac24-7ec84f6bcc28">

<div class="collection-sidebar__group"><button type="button" class="collapsible-trigger collapsible-trigger-btn collapsible--auto-height tag-list__header" aria-controls="SidebarDrawer-5" aria-expanded="false">
Earring Style
<span class="collapsible-trigger__icon collapsible-trigger__icon--open" role="presentation">
<svg aria-hidden="true" focusable="false" role="presentation" class="icon icon--wide icon-chevron-down" viewBox="0 0 28 16"><path d="M1.57 1.59l12.76 12.77L27.1 1.59" stroke-width="2" stroke="#000" fill="none" fill-rule="evenodd"></path></svg>
</span>
</button>
<div id="SidebarDrawer-5" class="collapsible-content collapsible-content--sidebar">
        <div class="collapsible-content__inner">
          
          <ul class="no-bullets tag-list tag-list--checkboxes">
<li class="tag">
                      <a href="sale-1/chandelier.html" title="Narrow selection to products matching tag Chandelier">Chandelier</a>
                    </li>
<li class="tag">
                      <a href="sale-1/solitaire.html" title="Narrow selection to products matching tag Solitaire">Solitaire</a>
                    </li>
<li class="tag">
                      <a href="sale-1/studs.html" title="Narrow selection to products matching tag Studs">Studs</a>
                    </li>
<li class="tag">
                      <a href="sale-1/long-indian-earrings.html" title="Narrow selection to products matching tag Long Indian Earrings">Long Indian Earrings</a>
                    </li>
<li class="tag">
                      <a href="sale-1/chandbali.html" title="Narrow selection to products matching tag Chandbali">Chandbali</a>
                    </li>
<li class="tag">
                      <a href="sale-1/jhumkas.html" title="Narrow selection to products matching tag Jhumkas">Jhumkas</a>
                    </li></ul></div>
      </div>
    </div></div><div class="collection-sidebar__group--7ae16531-8de6-4c9b-aba8-7012685394cd">


<div class="collection-sidebar__group"><button type="button" class="collapsible-trigger collapsible-trigger-btn collapsible--auto-height tag-list__header" aria-controls="SidebarDrawer-6" aria-expanded="false">
Color
<span class="collapsible-trigger__icon collapsible-trigger__icon--open" role="presentation">
<svg aria-hidden="true" focusable="false" role="presentation" class="icon icon--wide icon-chevron-down" viewBox="0 0 28 16"><path d="M1.57 1.59l12.76 12.77L27.1 1.59" stroke-width="2" stroke="#000" fill="none" fill-rule="evenodd"></path></svg>
</span>
</button>
<div id="SidebarDrawer-6" class="collapsible-content collapsible-content--sidebar">
      <div class="collapsible-content__inner">
        
<ul class="no-bullets tag-list tag-list--swatches">
<li class="tag">
                    <a href="sale-1/red.html" title="Narrow selection to products matching tag Red"><span class="color-swatch color-swatch--filter color-swatch--red" style="background-image: url(../cdn/shop/t/40/assets/red_50x.html); background-color: red;">
                    Red
                  </span></a>
                  </li>
<li class="tag">
                    <a href="sale-1/green.html" title="Narrow selection to products matching tag Green"><span class="color-swatch color-swatch--filter color-swatch--green" style="background-image: url(../cdn/shop/t/40/assets/green_50x.html); background-color: green;">
                    Green
                  </span></a>
                  </li>
<li class="tag">
                    <a href="sale-1/yellow.html" title="Narrow selection to products matching tag Yellow"><span class="color-swatch color-swatch--filter color-swatch--yellow" style="background-image: url(../cdn/shop/t/40/assets/yellow_50x.html); background-color: yellow;">
                    Yellow
                  </span></a>
                  </li>
<li class="tag">
                    <a href="sale-1/purple.html" title="Narrow selection to products matching tag Purple"><span class="color-swatch color-swatch--filter color-swatch--purple" style="background-image: url(../cdn/shop/t/40/assets/purple_50x.html); background-color: purple;">
                    Purple
                  </span></a>
                  </li>
<li class="tag">
                    <a href="sale-1/mint-green.html" title="Narrow selection to products matching tag Mint Green"><span class="color-swatch color-swatch--filter color-swatch--mint-green" style="background-image: url(../cdn/shop/t/40/assets/mint-green_50x.png); background-color: green;">
                    Mint Green
                  </span></a>
                  </li>
<li class="tag">
                    <a href="sale-1/blue.html" title="Narrow selection to products matching tag Blue"><span class="color-swatch color-swatch--filter color-swatch--blue" style="background-image: url(../cdn/shop/t/40/assets/blue_50x.html); background-color: blue;">
                    Blue
                  </span></a>
                  </li>
<li class="tag">
                    <a href="sale-1/pink.html" title="Narrow selection to products matching tag Pink"><span class="color-swatch color-swatch--filter color-swatch--pink" style="background-image: url(../cdn/shop/t/40/assets/pink_50x.html); background-color: pink;">
                    Pink
                  </span></a>
                  </li>
<li class="tag">
                    <a href="sale-1/black.html" title="Narrow selection to products matching tag Black"><span class="color-swatch color-swatch--filter color-swatch--black" style="background-image: url(../cdn/shop/t/40/assets/black_50x.html); background-color: black;">
                    Black
                  </span></a>
                  </li>


<li class="tag">
                    <a href="sale-1/navratna.html" title="Narrow selection to products matching tag Navratna"><span class="color-swatch color-swatch--filter color-swatch--navratna" style="background-image: url(../cdn/shop/t/40/assets/navratna_50x.html); background-color: navratna;">
                    Navratna
                  </span></a>
                  </li>
<li class="tag">
                    <a href="sale-1/white.html" title="Narrow selection to products matching tag white"><span class="color-swatch color-swatch--filter color-swatch--white" style="background-image: url(../cdn/shop/t/40/assets/white_50x.html); background-color: white;">
                    white
                  </span></a>
                  </li>
<li class="tag">
                    <a href="sale-1/grey.html" title="Narrow selection to products matching tag grey"><span class="color-swatch color-swatch--filter color-swatch--grey" style="background-image: url(../cdn/shop/t/40/assets/grey_50x.html); background-color: grey;">
                    grey
                  </span></a>
                  </li></ul></div>
    </div>
  </div></div><div class="collection-sidebar__group--adb40fe4-4f07-420f-ac37-68af1f103bc7">

<div class="collection-sidebar__group"><button type="button" class="collapsible-trigger collapsible-trigger-btn collapsible--auto-height tag-list__header" aria-controls="SidebarDrawer-7" aria-expanded="false">
Ring Size
<span class="collapsible-trigger__icon collapsible-trigger__icon--open" role="presentation">
<svg aria-hidden="true" focusable="false" role="presentation" class="icon icon--wide icon-chevron-down" viewBox="0 0 28 16"><path d="M1.57 1.59l12.76 12.77L27.1 1.59" stroke-width="2" stroke="#000" fill="none" fill-rule="evenodd"></path></svg>
</span>
</button>
<div id="SidebarDrawer-7" class="collapsible-content collapsible-content--sidebar">
        <div class="collapsible-content__inner">
          
          <ul class="no-bullets tag-list tag-list--checkboxes">

<li class="tag">
                      <a href="sale-1/size-5.html" title="Narrow selection to products matching tag Size 5">Size 5</a>
                    </li>
<li class="tag">
                      <a href="sale-1/size-6.html" title="Narrow selection to products matching tag Size 6">Size 6</a>
                    </li>
<li class="tag">
                      <a href="sale-1/size-7.html" title="Narrow selection to products matching tag Size 7">Size 7</a>
                    </li>
<li class="tag">
                      <a href="sale-1/size-8.html" title="Narrow selection to products matching tag Size 8">Size 8</a>
                    </li>
<li class="tag">
                      <a href="sale-1/size-9.html" title="Narrow selection to products matching tag Size 9">Size 9</a>
                    </li>
<li class="tag">
                      <a href="sale-1/adjustable.html" title="Narrow selection to products matching tag Adjustable">Adjustable</a>
                    </li></ul></div>
      </div>
    </div></div><div class="collection-sidebar__group--d8793594-0695-49b0-b009-5dc643e061ca">

<div class="collection-sidebar__group"><button type="button" class="collapsible-trigger collapsible-trigger-btn collapsible--auto-height tag-list__header" aria-controls="SidebarDrawer-8" aria-expanded="false">
Ring Style
<span class="collapsible-trigger__icon collapsible-trigger__icon--open" role="presentation">
<svg aria-hidden="true" focusable="false" role="presentation" class="icon icon--wide icon-chevron-down" viewBox="0 0 28 16"><path d="M1.57 1.59l12.76 12.77L27.1 1.59" stroke-width="2" stroke="#000" fill="none" fill-rule="evenodd"></path></svg>
</span>
</button>
<div id="SidebarDrawer-8" class="collapsible-content collapsible-content--sidebar">
        <div class="collapsible-content__inner">
          
          <ul class="no-bullets tag-list tag-list--checkboxes">
<li class="tag">
                      <a href="sale-1/band-rings.html" title="Narrow selection to products matching tag Band Rings">Band Rings</a>
                    </li>
<li class="tag">
                      <a href="sale-1/solitaire-rings.html" title="Narrow selection to products matching tag Solitaire Rings">Solitaire Rings</a>
                    </li>
<li class="tag">
                      <a href="sale-1/cocktail-rings.html" title="Narrow selection to products matching tag Cocktail Rings">Cocktail Rings</a>
                    </li></ul></div>
      </div>
    </div></div></div>
</div>
</div>
<div class="collection-sidebar small--hide"><ul class="no-bullets tag-list tag-list--active-tags"></ul><div class="collection-sidebar__group--5b49c08d-c5b6-4760-951b-022918e91800">

<div class="collection-sidebar__group"><button type="button" class="collapsible-trigger collapsible-trigger-btn collapsible--auto-height tag-list__header" aria-controls="CollectionSidebar-1" aria-expanded="false">
Jewellery Category
<span class="collapsible-trigger__icon collapsible-trigger__icon--open" role="presentation">
<svg aria-hidden="true" focusable="false" role="presentation" class="icon icon--wide icon-chevron-down" viewBox="0 0 28 16"><path d="M1.57 1.59l12.76 12.77L27.1 1.59" stroke-width="2" stroke="#000" fill="none" fill-rule="evenodd"></path></svg>
</span>
</button>
<div id="CollectionSidebar-1" class="collapsible-content collapsible-content--sidebar">
        <div class="collapsible-content__inner">
          
          <ul class="no-bullets tag-list tag-list--checkboxes">
<li class="tag">
                      <a href="sale-1/rings.html" title="Narrow selection to products matching tag Rings">Rings</a>
                    </li>
<li class="tag">
                      <a href="sale-1/nose-rings.html" title="Narrow selection to products matching tag Nose Rings">Nose Rings</a>
                    </li>
<li class="tag">
                      <a href="sale-1/necklace.html" title="Narrow selection to products matching tag Necklace">Necklace</a>
                    </li>

<li class="tag">
                      <a href="sale-1/headgears.html" title="Narrow selection to products matching tag Headgears">Headgears</a>
                    </li>
<li class="tag">
                      <a href="sale-1/mangalsutra.html" title="Narrow selection to products matching tag Mangalsutra">Mangalsutra</a>
                    </li>
<li class="tag">
                      <a href="sale-1/bracelet.html" title="Narrow selection to products matching tag Bracelet">Bracelet</a>
                    </li>


<li class="tag">
                      <a href="sale-1/jewellery-set.html" title="Narrow selection to products matching tag Jewellery Set">Jewellery Set</a>
                    </li>
<li class="tag">
                      <a href="sale-1/earrings.html" title="Narrow selection to products matching tag Earrings">Earrings</a>
                    </li></ul></div>
      </div>
    </div></div><div class="collection-sidebar__group--e5dc5dc6-bdb0-4303-93b9-ba463b079b04">

<div class="collection-sidebar__group"><button type="button" class="collapsible-trigger collapsible-trigger-btn collapsible--auto-height tag-list__header" aria-controls="CollectionSidebar-2" aria-expanded="false">
Jewellery Type
<span class="collapsible-trigger__icon collapsible-trigger__icon--open" role="presentation">
<svg aria-hidden="true" focusable="false" role="presentation" class="icon icon--wide icon-chevron-down" viewBox="0 0 28 16"><path d="M1.57 1.59l12.76 12.77L27.1 1.59" stroke-width="2" stroke="#000" fill="none" fill-rule="evenodd"></path></svg>
</span>
</button>
<div id="CollectionSidebar-2" class="collapsible-content collapsible-content--sidebar">
        <div class="collapsible-content__inner">
          
          <ul class="no-bullets tag-list tag-list--checkboxes">
<li class="tag">
                      <a href="sale-1/diamond.html" title="Narrow selection to products matching tag Diamond">Diamond</a>
                    </li>
<li class="tag">
                      <a href="sale-1/indian.html" title="Narrow selection to products matching tag Indian">Indian</a>
                    </li>
<li class="tag">
                      <a href="sale-1/contemporary.html" title="Narrow selection to products matching tag Contemporary">Contemporary</a>
                    </li></ul></div>
      </div>
    </div></div><div class="collection-sidebar__group--e65c08f1-3877-40e9-aa3b-87da73ea91c3">

<div class="collection-sidebar__group"><button type="button" class="collapsible-trigger collapsible-trigger-btn collapsible--auto-height tag-list__header" aria-controls="CollectionSidebar-3" aria-expanded="false">
Jewellery Style
<span class="collapsible-trigger__icon collapsible-trigger__icon--open" role="presentation">
<svg aria-hidden="true" focusable="false" role="presentation" class="icon icon--wide icon-chevron-down" viewBox="0 0 28 16"><path d="M1.57 1.59l12.76 12.77L27.1 1.59" stroke-width="2" stroke="#000" fill="none" fill-rule="evenodd"></path></svg>
</span>
</button>
<div id="CollectionSidebar-3" class="collapsible-content collapsible-content--sidebar">
        <div class="collapsible-content__inner">
          
          <ul class="no-bullets tag-list tag-list--checkboxes">
<li class="tag">
                      <a href="sale-1/choker-sets.html" title="Narrow selection to products matching tag Choker Sets">Choker Sets</a>
                    </li>
<li class="tag">
                      <a href="sale-1/bridal-sets.html" title="Narrow selection to products matching tag Bridal Sets">Bridal Sets</a>
                    </li>
<li class="tag">
                      <a href="sale-1/necklace-sets.html" title="Narrow selection to products matching tag Necklace Sets">Necklace Sets</a>
                    </li>
<li class="tag">
                      <a href="sale-1/long-sets.html" title="Narrow selection to products matching tag Long Sets">Long Sets</a>
                    </li></ul></div>
      </div>
    </div></div><div class="collection-sidebar__group--3e1934a1-d155-4fa6-87f0-066cdf9871ef">

<div class="collection-sidebar__group"><button type="button" class="collapsible-trigger collapsible-trigger-btn collapsible--auto-height tag-list__header" aria-controls="CollectionSidebar-4" aria-expanded="false">
Collection
<span class="collapsible-trigger__icon collapsible-trigger__icon--open" role="presentation">
<svg aria-hidden="true" focusable="false" role="presentation" class="icon icon--wide icon-chevron-down" viewBox="0 0 28 16"><path d="M1.57 1.59l12.76 12.77L27.1 1.59" stroke-width="2" stroke="#000" fill="none" fill-rule="evenodd"></path></svg>
</span>
</button>
<div id="CollectionSidebar-4" class="collapsible-content collapsible-content--sidebar">
        <div class="collapsible-content__inner">
          
          <ul class="no-bullets tag-list tag-list--checkboxes">
<li class="tag">
                      <a href="sale-1/almaaz.html" title="Narrow selection to products matching tag Almaaz">Almaaz</a>
                    </li>
<li class="tag">
                      <a href="sale-1/jadau.html" title="Narrow selection to products matching tag Jadau">Jadau</a>
                    </li>
<li class="tag">
                      <a href="sale-1/metallic-dust.html" title="Narrow selection to products matching tag Metallic Dust">Metallic Dust</a>
                    </li>
<li class="tag">
                      <a href="sale-1/rajwada.html" title="Narrow selection to products matching tag Rajwada">Rajwada</a>
                    </li>
<li class="tag">
                      <a href="sale-1/victorian-polish-antique-gold.html" title="Narrow selection to products matching tag Victorian Polish / Antique Gold">Victorian Polish / Antique Gold</a>
                    </li>
<li class="tag">
                      <a href="sale-1/lala-land.html" title="Narrow selection to products matching tag Lala Land">Lala Land</a>
                    </li>

<li class="tag">
                      <a href="sale-1/banjaran.html" title="Narrow selection to products matching tag Banjaran">Banjaran</a>
                    </li></ul></div>
      </div>
    </div></div><div class="collection-sidebar__group--3c8d2405-8bd8-46b3-ac24-7ec84f6bcc28">

<div class="collection-sidebar__group"><button type="button" class="collapsible-trigger collapsible-trigger-btn collapsible--auto-height tag-list__header" aria-controls="CollectionSidebar-5" aria-expanded="false">
Earring Style
<span class="collapsible-trigger__icon collapsible-trigger__icon--open" role="presentation">
<svg aria-hidden="true" focusable="false" role="presentation" class="icon icon--wide icon-chevron-down" viewBox="0 0 28 16"><path d="M1.57 1.59l12.76 12.77L27.1 1.59" stroke-width="2" stroke="#000" fill="none" fill-rule="evenodd"></path></svg>
</span>
</button>
<div id="CollectionSidebar-5" class="collapsible-content collapsible-content--sidebar">
        <div class="collapsible-content__inner">
          
          <ul class="no-bullets tag-list tag-list--checkboxes">
<li class="tag">
                      <a href="sale-1/chandelier.html" title="Narrow selection to products matching tag Chandelier">Chandelier</a>
                    </li>
<li class="tag">
                      <a href="sale-1/solitaire.html" title="Narrow selection to products matching tag Solitaire">Solitaire</a>
                    </li>
<li class="tag">
                      <a href="sale-1/studs.html" title="Narrow selection to products matching tag Studs">Studs</a>
                    </li>
<li class="tag">
                      <a href="sale-1/long-indian-earrings.html" title="Narrow selection to products matching tag Long Indian Earrings">Long Indian Earrings</a>
                    </li>
<li class="tag">
                      <a href="sale-1/chandbali.html" title="Narrow selection to products matching tag Chandbali">Chandbali</a>
                    </li>
<li class="tag">
                      <a href="sale-1/jhumkas.html" title="Narrow selection to products matching tag Jhumkas">Jhumkas</a>
                    </li></ul></div>
      </div>
    </div></div><div class="collection-sidebar__group--7ae16531-8de6-4c9b-aba8-7012685394cd">


<div class="collection-sidebar__group"><button type="button" class="collapsible-trigger collapsible-trigger-btn collapsible--auto-height tag-list__header" aria-controls="CollectionSidebar-6" aria-expanded="false">
Color
<span class="collapsible-trigger__icon collapsible-trigger__icon--open" role="presentation">
<svg aria-hidden="true" focusable="false" role="presentation" class="icon icon--wide icon-chevron-down" viewBox="0 0 28 16"><path d="M1.57 1.59l12.76 12.77L27.1 1.59" stroke-width="2" stroke="#000" fill="none" fill-rule="evenodd"></path></svg>
</span>
</button>
<div id="CollectionSidebar-6" class="collapsible-content collapsible-content--sidebar">
      <div class="collapsible-content__inner">
        
<ul class="no-bullets tag-list tag-list--swatches">
<li class="tag">
                    <a href="sale-1/red.html" title="Narrow selection to products matching tag Red"><span class="color-swatch color-swatch--filter color-swatch--red" style="background-image: url(../cdn/shop/t/40/assets/red_50x.html); background-color: red;">
                    Red
                  </span></a>
                  </li>
<li class="tag">
                    <a href="sale-1/green.html" title="Narrow selection to products matching tag Green"><span class="color-swatch color-swatch--filter color-swatch--green" style="background-image: url(../cdn/shop/t/40/assets/green_50x.html); background-color: green;">
                    Green
                  </span></a>
                  </li>
<li class="tag">
                    <a href="sale-1/yellow.html" title="Narrow selection to products matching tag Yellow"><span class="color-swatch color-swatch--filter color-swatch--yellow" style="background-image: url(../cdn/shop/t/40/assets/yellow_50x.html); background-color: yellow;">
                    Yellow
                  </span></a>
                  </li>
<li class="tag">
                    <a href="sale-1/purple.html" title="Narrow selection to products matching tag Purple"><span class="color-swatch color-swatch--filter color-swatch--purple" style="background-image: url(../cdn/shop/t/40/assets/purple_50x.html); background-color: purple;">
                    Purple
                  </span></a>
                  </li>
<li class="tag">
                    <a href="sale-1/mint-green.html" title="Narrow selection to products matching tag Mint Green"><span class="color-swatch color-swatch--filter color-swatch--mint-green" style="background-image: url(../cdn/shop/t/40/assets/mint-green_50x.png); background-color: green;">
                    Mint Green
                  </span></a>
                  </li>
<li class="tag">
                    <a href="sale-1/blue.html" title="Narrow selection to products matching tag Blue"><span class="color-swatch color-swatch--filter color-swatch--blue" style="background-image: url(../cdn/shop/t/40/assets/blue_50x.html); background-color: blue;">
                    Blue
                  </span></a>
                  </li>
<li class="tag">
                    <a href="sale-1/pink.html" title="Narrow selection to products matching tag Pink"><span class="color-swatch color-swatch--filter color-swatch--pink" style="background-image: url(../cdn/shop/t/40/assets/pink_50x.html); background-color: pink;">
                    Pink
                  </span></a>
                  </li>
<li class="tag">
                    <a href="sale-1/black.html" title="Narrow selection to products matching tag Black"><span class="color-swatch color-swatch--filter color-swatch--black" style="background-image: url(../cdn/shop/t/40/assets/black_50x.html); background-color: black;">
                    Black
                  </span></a>
                  </li>


<li class="tag">
                    <a href="sale-1/navratna.html" title="Narrow selection to products matching tag Navratna"><span class="color-swatch color-swatch--filter color-swatch--navratna" style="background-image: url(../cdn/shop/t/40/assets/navratna_50x.html); background-color: navratna;">
                    Navratna
                  </span></a>
                  </li>
<li class="tag">
                    <a href="sale-1/white.html" title="Narrow selection to products matching tag white"><span class="color-swatch color-swatch--filter color-swatch--white" style="background-image: url(../cdn/shop/t/40/assets/white_50x.html); background-color: white;">
                    white
                  </span></a>
                  </li>
<li class="tag">
                    <a href="sale-1/grey.html" title="Narrow selection to products matching tag grey"><span class="color-swatch color-swatch--filter color-swatch--grey" style="background-image: url(../cdn/shop/t/40/assets/grey_50x.html); background-color: grey;">
                    grey
                  </span></a>
                  </li></ul></div>
    </div>
  </div></div><div class="collection-sidebar__group--adb40fe4-4f07-420f-ac37-68af1f103bc7">

<div class="collection-sidebar__group"><button type="button" class="collapsible-trigger collapsible-trigger-btn collapsible--auto-height tag-list__header" aria-controls="CollectionSidebar-7" aria-expanded="false">
Ring Size
<span class="collapsible-trigger__icon collapsible-trigger__icon--open" role="presentation">
<svg aria-hidden="true" focusable="false" role="presentation" class="icon icon--wide icon-chevron-down" viewBox="0 0 28 16"><path d="M1.57 1.59l12.76 12.77L27.1 1.59" stroke-width="2" stroke="#000" fill="none" fill-rule="evenodd"></path></svg>
</span>
</button>
<div id="CollectionSidebar-7" class="collapsible-content collapsible-content--sidebar">
        <div class="collapsible-content__inner">
          
          <ul class="no-bullets tag-list tag-list--checkboxes">

<li class="tag">
                      <a href="sale-1/size-5.html" title="Narrow selection to products matching tag Size 5">Size 5</a>
                    </li>
<li class="tag">
                      <a href="sale-1/size-6.html" title="Narrow selection to products matching tag Size 6">Size 6</a>
                    </li>
<li class="tag">
                      <a href="sale-1/size-7.html" title="Narrow selection to products matching tag Size 7">Size 7</a>
                    </li>
<li class="tag">
                      <a href="sale-1/size-8.html" title="Narrow selection to products matching tag Size 8">Size 8</a>
                    </li>
<li class="tag">
                      <a href="sale-1/size-9.html" title="Narrow selection to products matching tag Size 9">Size 9</a>
                    </li>
<li class="tag">
                      <a href="sale-1/adjustable.html" title="Narrow selection to products matching tag Adjustable">Adjustable</a>
                    </li></ul></div>
      </div>
    </div></div><div class="collection-sidebar__group--d8793594-0695-49b0-b009-5dc643e061ca">

<div class="collection-sidebar__group"><button type="button" class="collapsible-trigger collapsible-trigger-btn collapsible--auto-height tag-list__header" aria-controls="CollectionSidebar-8" aria-expanded="false">
Ring Style
<span class="collapsible-trigger__icon collapsible-trigger__icon--open" role="presentation">
<svg aria-hidden="true" focusable="false" role="presentation" class="icon icon--wide icon-chevron-down" viewBox="0 0 28 16"><path d="M1.57 1.59l12.76 12.77L27.1 1.59" stroke-width="2" stroke="#000" fill="none" fill-rule="evenodd"></path></svg>
</span>
</button>
<div id="CollectionSidebar-8" class="collapsible-content collapsible-content--sidebar">
        <div class="collapsible-content__inner">
          
          <ul class="no-bullets tag-list tag-list--checkboxes">
<li class="tag">
                      <a href="sale-1/band-rings.html" title="Narrow selection to products matching tag Band Rings">Band Rings</a>
                    </li>
<li class="tag">
                      <a href="sale-1/solitaire-rings.html" title="Narrow selection to products matching tag Solitaire Rings">Solitaire Rings</a>
                    </li>
<li class="tag">
                      <a href="sale-1/cocktail-rings.html" title="Narrow selection to products matching tag Cocktail Rings">Cocktail Rings</a>
                    </li></ul></div>
      </div>
    </div></div></div></div>
<style data-shopify="">@media screen and (min-width: 769px) {
.collection-filter__item--drawer {
  display: none;
}
.collection-filter__item--count {
  text-align: left;
}
html[dir="rtl"] .collection-filter__item--count {
  text-align: right;
}
}</style>
</div>
  </div>
  <div class="grid__item medium-up--four-fifths grid__item--content">
    <div id="shopify-section-collection-promotions" class="shopify-section"><div data-section-id="collection-promotions" data-section-type="promo-grid"></div>


</div>
    <div class="collection-grid__wrapper">
      <div id="shopify-section-collection-template" class="shopify-section"><div id="CollectionSection" data-section-id="collection-template" data-section-type="collection-template"><div class="collection-filter"><div class="collection-filter__item collection-filter__item--drawer">
<button type="button" class="js-drawer-open-collection-filters btn btn--tertiary" aria-controls="FilterDrawer" aria-expanded="false">
  <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-filter" viewBox="0 0 64 64"><path d="M48 42h10M48 42a5 5 0 1 1-5-5 5 5 0 0 1 5 5zM7 42h31M16 22H6M16 22a5 5 0 1 1 5 5 5 5 0 0 1-5-5zM57 22H26"></path></svg>
  Filter
</button>
</div>

<div class="collection-filter__item collection-filter__item--count small--hide">333 products
</div>

<div class="collection-filter__item collection-filter__item--sort">
<div class="collection-filter__sort-container"><label for="SortBy" class="hidden-label">Sort</label>
  <select name="SortBy" id="SortBy" data-default-sortby="manual">
    <option value="title-ascending" selected="selected">Sort</option><option value="manual" selected="selected">Featured</option><option value="best-selling">Best selling</option><option value="title-ascending">Alphabetically, A-Z</option><option value="title-descending">Alphabetically, Z-A</option><option value="price-ascending">Price, low to high</option><option value="price-descending">Price, high to low</option><option value="created-ascending">Date, old to new</option><option value="created-descending">Date, new to old</option></select>
</div>
</div>
</div><p class="medium-up--hide text-center" data-scroll-to="">333 products</p><div class="grid grid--uniform"><div class="grid__item grid-product small--one-half medium-up--one-third grid-product__has-quick-shop aos-init aos-animate" data-aos="row-of-3" data-product-handle="yellow-pear-shaped-stud" data-product-id="8377954664660">
<div class="grid-product__content"><a href="sale-1/products/yellow-pear-shaped-stud.html" class="grid-product__link">
<div class="grid-product__image-mask"><div class="quick-product__btn js-modal-open-quick-modal-8377954664660 small--hide" aria-expanded="false">
      <span class="quick-product__label">Quick view</span>
    </div><div class="grid__image-ratio grid__image-ratio--portrait">
      <img loading="lazy" class="lazyautosizes lazyloaded" data-widths="[360, 540, 720, 900, 1080]" data-aspectratio="0.575" data-sizes="auto" alt="" data-srcset="//attrangi.in/cdn/shop/files/WhatsAppImage2024-05-11at3.35.31PM_1_360x.jpg?v=1715422013 360w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-11at3.35.31PM_1_540x.jpg?v=1715422013 540w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-11at3.35.31PM_1_720x.jpg?v=1715422013 720w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-11at3.35.31PM_1_900x.jpg?v=1715422013 900w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-11at3.35.31PM_1_1080x.jpg?v=1715422013 1080w" sizes="322px" srcset="//attrangi.in/cdn/shop/files/WhatsAppImage2024-05-11at3.35.31PM_1_360x.jpg?v=1715422013 360w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-11at3.35.31PM_1_540x.jpg?v=1715422013 540w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-11at3.35.31PM_1_720x.jpg?v=1715422013 720w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-11at3.35.31PM_1_900x.jpg?v=1715422013 900w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-11at3.35.31PM_1_1080x.jpg?v=1715422013 1080w">
    </div></div>

<div class="grid-product__meta">
  <div class="grid-product__title grid-product__title--body">Yellow Pear Shaped Stud</div><div class="grid-product__price">Rs. 2,150
</div></div>
</a>
</div></div>
<div class="grid__item grid-product small--one-half medium-up--one-third grid-product__has-quick-shop aos-init aos-animate" data-aos="row-of-3" data-product-handle="daphne-diamond-necklace-with-pastel-beads-lala-land-collection" data-product-id="8374448029908">
<div class="grid-product__content"><div class="grid-product__tag grid-product__tag--sale">
    Sale
  </div><a href="sale-1/products/daphne-diamond-necklace-with-pastel-beads-lala-land-collection.html" class="grid-product__link">
<div class="grid-product__image-mask"><div class="quick-product__btn js-modal-open-quick-modal-8374448029908 small--hide" aria-expanded="false">
      <span class="quick-product__label">Quick view</span>
    </div><div class="grid__image-ratio grid__image-ratio--portrait">
      <img loading="lazy" class="lazyautosizes lazyloaded" data-widths="[360, 540, 720, 900, 1080]" data-aspectratio="1.185761957730812" data-sizes="auto" alt="" data-srcset="//attrangi.in/cdn/shop/files/WhatsAppImage2024-05-09at6.20.29PM_360x.jpg?v=1715324380 360w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-09at6.20.29PM_540x.jpg?v=1715324380 540w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-09at6.20.29PM_720x.jpg?v=1715324380 720w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-09at6.20.29PM_900x.jpg?v=1715324380 900w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-09at6.20.29PM_1080x.jpg?v=1715324380 1080w" sizes="322px" srcset="//attrangi.in/cdn/shop/files/WhatsAppImage2024-05-09at6.20.29PM_360x.jpg?v=1715324380 360w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-09at6.20.29PM_540x.jpg?v=1715324380 540w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-09at6.20.29PM_720x.jpg?v=1715324380 720w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-09at6.20.29PM_900x.jpg?v=1715324380 900w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-09at6.20.29PM_1080x.jpg?v=1715324380 1080w">
    </div></div>

<div class="grid-product__meta">
  <div class="grid-product__title grid-product__title--body">Daphne Diamond Necklace with Pastel Beads | LaLa Land Collection</div><div class="grid-product__price"><span class="visually-hidden">Regular price</span>
      <span class="grid-product__price--original">Rs. 4,950</span>
      <span class="visually-hidden">Sale price</span>Rs. 4,250
<span class="grid-product__price--savings">
          Save Rs. 700
        </span></div></div>
</a>
</div></div>
<div class="grid__item grid-product small--one-half medium-up--one-third grid-product__has-quick-shop aos-init aos-animate" data-aos="row-of-3" data-product-handle="small-hallie-crisscross-triangular-shaped-party-wear-earrings" data-product-id="8369248010452">
<div class="grid-product__content"><div class="grid-product__tag grid-product__tag--sale">
    Sale
  </div><a href="sale-1/products/small-hallie-crisscross-triangular-shaped-party-wear-earrings.html" class="grid-product__link">
<div class="grid-product__image-mask"><div class="quick-product__btn js-modal-open-quick-modal-8369248010452 small--hide" aria-expanded="false">
      <span class="quick-product__label">Quick view</span>
    </div><div class="grid__image-ratio grid__image-ratio--portrait">
      <img loading="lazy" class="lazyautosizes lazyloaded" data-widths="[360, 540, 720, 900, 1080]" data-aspectratio="0.63515625" data-sizes="auto" alt="" data-srcset="//attrangi.in/cdn/shop/files/WhatsAppImage2024-05-08at3.40.57PM_360x.jpg?v=1715165297 360w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-08at3.40.57PM_540x.jpg?v=1715165297 540w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-08at3.40.57PM_720x.jpg?v=1715165297 720w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-08at3.40.57PM_900x.jpg?v=1715165297 900w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-08at3.40.57PM_1080x.jpg?v=1715165297 1080w" sizes="322px" srcset="//attrangi.in/cdn/shop/files/WhatsAppImage2024-05-08at3.40.57PM_360x.jpg?v=1715165297 360w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-08at3.40.57PM_540x.jpg?v=1715165297 540w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-08at3.40.57PM_720x.jpg?v=1715165297 720w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-08at3.40.57PM_900x.jpg?v=1715165297 900w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-08at3.40.57PM_1080x.jpg?v=1715165297 1080w">
    </div></div>

<div class="grid-product__meta">
  <div class="grid-product__title grid-product__title--body">Small Hallie Crisscross Triangular Shaped Party Wear Earrings</div><div class="grid-product__price"><span class="visually-hidden">Regular price</span>
      <span class="grid-product__price--original">Rs. 750</span>
      <span class="visually-hidden">Sale price</span>Rs. 550
<span class="grid-product__price--savings">
          Save Rs. 200
        </span></div></div>
</a>
</div></div>
<div class="grid__item grid-product small--one-half medium-up--one-third grid-product__has-quick-shop aos-init aos-animate" data-aos="row-of-3" data-product-handle="90-cents-solitaire-pendant-in-pear-shaped" data-product-id="8365799178452">
<div class="grid-product__content"><div class="grid-product__tag grid-product__tag--sale">
    Sale
  </div><a href="sale-1/products/90-cents-solitaire-pendant-in-pear-shaped.html" class="grid-product__link">
<div class="grid-product__image-mask"><div class="quick-product__btn quick-product__btn--not-ready js-modal-open-quick-modal-8365799178452 small--hide">
      <span class="quick-product__label">Quick view</span>
    </div><div class="grid__image-ratio grid__image-ratio--portrait">
      <img loading="lazy" class="lazyautosizes lazyloaded" data-widths="[360, 540, 720, 900, 1080]" data-aspectratio="0.75" data-sizes="auto" alt="" data-srcset="//attrangi.in/cdn/shop/files/WhatsAppImage2024-05-06at4.38.44PM_360x.jpg?v=1714994070 360w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-06at4.38.44PM_540x.jpg?v=1714994070 540w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-06at4.38.44PM_720x.jpg?v=1714994070 720w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-06at4.38.44PM_900x.jpg?v=1714994070 900w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-06at4.38.44PM_1080x.jpg?v=1714994070 1080w" sizes="322px" srcset="//attrangi.in/cdn/shop/files/WhatsAppImage2024-05-06at4.38.44PM_360x.jpg?v=1714994070 360w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-06at4.38.44PM_540x.jpg?v=1714994070 540w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-06at4.38.44PM_720x.jpg?v=1714994070 720w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-06at4.38.44PM_900x.jpg?v=1714994070 900w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-06at4.38.44PM_1080x.jpg?v=1714994070 1080w">
    </div></div>

<div class="grid-product__meta">
  <div class="grid-product__title grid-product__title--body">90 Cents Solitaire Pendant in Pear Shaped</div><div class="grid-product__price"><span class="visually-hidden">Regular price</span>
      <span class="grid-product__price--original">Rs. 1,350</span>
      <span class="visually-hidden">Sale price</span>Rs. 950
<span class="grid-product__price--savings">
          Save Rs. 400
        </span></div></div>
</a>
</div></div>
<div class="grid__item grid-product small--one-half medium-up--one-third grid-product__has-quick-shop aos-init aos-animate" data-aos="row-of-3" data-product-handle="grisha-polki-choker-set-with-firoza-drops" data-product-id="8344400756948">
<div class="grid-product__content"><div class="grid-product__tag grid-product__tag--sale">
    Sale
  </div><a href="sale-1/products/grisha-polki-choker-set-with-firoza-drops.html" class="grid-product__link">
<div class="grid-product__image-mask"><div class="quick-product__btn quick-product__btn--not-ready js-modal-open-quick-modal-8344400756948 small--hide">
      <span class="quick-product__label">Quick view</span>
    </div><div class="grid__image-ratio grid__image-ratio--portrait">
      <img loading="lazy" class="lazyautosizes lazyloaded" data-widths="[360, 540, 720, 900, 1080]" data-aspectratio="1.0307396733909702" data-sizes="auto" alt="Grisha Polki Choker Set with Firoza Drops - Attrangi" data-srcset="//attrangi.in/cdn/shop/files/grisha-polki-choker-set-with-firoza-drops-attrangi-1_360x.jpg?v=1714932912 360w, //attrangi.in/cdn/shop/files/grisha-polki-choker-set-with-firoza-drops-attrangi-1_540x.jpg?v=1714932912 540w, //attrangi.in/cdn/shop/files/grisha-polki-choker-set-with-firoza-drops-attrangi-1_720x.jpg?v=1714932912 720w, //attrangi.in/cdn/shop/files/grisha-polki-choker-set-with-firoza-drops-attrangi-1_900x.jpg?v=1714932912 900w, //attrangi.in/cdn/shop/files/grisha-polki-choker-set-with-firoza-drops-attrangi-1_1080x.jpg?v=1714932912 1080w" sizes="322px" srcset="//attrangi.in/cdn/shop/files/grisha-polki-choker-set-with-firoza-drops-attrangi-1_360x.jpg?v=1714932912 360w, //attrangi.in/cdn/shop/files/grisha-polki-choker-set-with-firoza-drops-attrangi-1_540x.jpg?v=1714932912 540w, //attrangi.in/cdn/shop/files/grisha-polki-choker-set-with-firoza-drops-attrangi-1_720x.jpg?v=1714932912 720w, //attrangi.in/cdn/shop/files/grisha-polki-choker-set-with-firoza-drops-attrangi-1_900x.jpg?v=1714932912 900w, //attrangi.in/cdn/shop/files/grisha-polki-choker-set-with-firoza-drops-attrangi-1_1080x.jpg?v=1714932912 1080w">
    </div><div class="grid-product__secondary-image small--hide"><img loading="lazy" class="lazyautosizes lazyloaded" data-widths="[360, 540, 720, 1000]" data-aspectratio="1.0384615384615385" data-sizes="auto" alt="Grisha Polki Choker Set with Firoza Drops - Attrangi" data-srcset="//attrangi.in/cdn/shop/files/grisha-polki-choker-set-with-firoza-drops-attrangi-2_360x.jpg?v=1714932913 360w, //attrangi.in/cdn/shop/files/grisha-polki-choker-set-with-firoza-drops-attrangi-2_540x.jpg?v=1714932913 540w, //attrangi.in/cdn/shop/files/grisha-polki-choker-set-with-firoza-drops-attrangi-2_720x.jpg?v=1714932913 720w, //attrangi.in/cdn/shop/files/grisha-polki-choker-set-with-firoza-drops-attrangi-2_1000x.jpg?v=1714932913 1000w" sizes="324px" srcset="//attrangi.in/cdn/shop/files/grisha-polki-choker-set-with-firoza-drops-attrangi-2_360x.jpg?v=1714932913 360w, //attrangi.in/cdn/shop/files/grisha-polki-choker-set-with-firoza-drops-attrangi-2_540x.jpg?v=1714932913 540w, //attrangi.in/cdn/shop/files/grisha-polki-choker-set-with-firoza-drops-attrangi-2_720x.jpg?v=1714932913 720w, //attrangi.in/cdn/shop/files/grisha-polki-choker-set-with-firoza-drops-attrangi-2_1000x.jpg?v=1714932913 1000w">
    </div></div>

<div class="grid-product__meta">
  <div class="grid-product__title grid-product__title--body">Grisha Polki Choker Set with Firoza Drops</div><div class="grid-product__price"><span class="visually-hidden">Regular price</span>
      <span class="grid-product__price--original">Rs. 10,450</span>
      <span class="visually-hidden">Sale price</span>Rs. 9,650
<span class="grid-product__price--savings">
          Save Rs. 800
        </span></div></div>
</a>
</div></div>
<div class="grid__item grid-product small--one-half medium-up--one-third grid-product__has-quick-shop aos-init aos-animate" data-aos="row-of-3" data-product-handle="blue-dangler-in-rose-gold" data-product-id="8344233115860">
<div class="grid-product__content"><div class="grid-product__tag grid-product__tag--sale">
    Sale
  </div><a href="sale-1/products/blue-dangler-in-rose-gold.html" class="grid-product__link">
<div class="grid-product__image-mask"><div class="quick-product__btn quick-product__btn--not-ready js-modal-open-quick-modal-8344233115860 small--hide">
      <span class="quick-product__label">Quick view</span>
    </div><div class="grid__image-ratio grid__image-ratio--portrait">
      <img loading="lazy" class="lazyautosizes lazyloaded" data-widths="[360, 540, 720, 900, 1080]" data-aspectratio="0.67375" data-sizes="auto" alt="Blue Dangler in Rose Gold - Attrangi" data-srcset="//attrangi.in/cdn/shop/files/blue-dangler-in-rose-gold-attrangi_360x.jpg?v=1714932575 360w, //attrangi.in/cdn/shop/files/blue-dangler-in-rose-gold-attrangi_540x.jpg?v=1714932575 540w, //attrangi.in/cdn/shop/files/blue-dangler-in-rose-gold-attrangi_720x.jpg?v=1714932575 720w, //attrangi.in/cdn/shop/files/blue-dangler-in-rose-gold-attrangi_900x.jpg?v=1714932575 900w, //attrangi.in/cdn/shop/files/blue-dangler-in-rose-gold-attrangi_1080x.jpg?v=1714932575 1080w" sizes="322px" srcset="//attrangi.in/cdn/shop/files/blue-dangler-in-rose-gold-attrangi_360x.jpg?v=1714932575 360w, //attrangi.in/cdn/shop/files/blue-dangler-in-rose-gold-attrangi_540x.jpg?v=1714932575 540w, //attrangi.in/cdn/shop/files/blue-dangler-in-rose-gold-attrangi_720x.jpg?v=1714932575 720w, //attrangi.in/cdn/shop/files/blue-dangler-in-rose-gold-attrangi_900x.jpg?v=1714932575 900w, //attrangi.in/cdn/shop/files/blue-dangler-in-rose-gold-attrangi_1080x.jpg?v=1714932575 1080w">
    </div></div>

<div class="grid-product__meta">
  <div class="grid-product__title grid-product__title--body">Blue Dangler in Rose Gold</div><div class="grid-product__price"><span class="visually-hidden">Regular price</span>
      <span class="grid-product__price--original">Rs. 2,450</span>
      <span class="visually-hidden">Sale price</span>Rs. 1,950
<span class="grid-product__price--savings">
          Save Rs. 500
        </span></div></div>
</a>
</div></div>
<div class="grid__item grid-product small--one-half medium-up--one-third grid-product__has-quick-shop aos-init aos-animate" data-aos="row-of-3" data-product-handle="emerald-dangler" data-product-id="8344229347540">
<div class="grid-product__content"><div class="grid-product__tag grid-product__tag--sale">
    Sale
  </div><a href="sale-1/products/emerald-dangler.html" class="grid-product__link">
<div class="grid-product__image-mask"><div class="quick-product__btn quick-product__btn--not-ready js-modal-open-quick-modal-8344229347540 small--hide">
      <span class="quick-product__label">Quick view</span>
    </div><div class="grid__image-ratio grid__image-ratio--portrait">
      <img loading="lazy" class="lazyautosizes lazyloaded" data-widths="[360, 540, 720, 900, 1080]" data-aspectratio="0.7642276422764228" data-sizes="auto" alt="Emerald Dangler - Attrangi" data-srcset="//attrangi.in/cdn/shop/files/emerald-dangler-attrangi_360x.jpg?v=1714932799 360w, //attrangi.in/cdn/shop/files/emerald-dangler-attrangi_540x.jpg?v=1714932799 540w, //attrangi.in/cdn/shop/files/emerald-dangler-attrangi_720x.jpg?v=1714932799 720w, //attrangi.in/cdn/shop/files/emerald-dangler-attrangi_900x.jpg?v=1714932799 900w, //attrangi.in/cdn/shop/files/emerald-dangler-attrangi_1080x.jpg?v=1714932799 1080w" sizes="322px" srcset="//attrangi.in/cdn/shop/files/emerald-dangler-attrangi_360x.jpg?v=1714932799 360w, //attrangi.in/cdn/shop/files/emerald-dangler-attrangi_540x.jpg?v=1714932799 540w, //attrangi.in/cdn/shop/files/emerald-dangler-attrangi_720x.jpg?v=1714932799 720w, //attrangi.in/cdn/shop/files/emerald-dangler-attrangi_900x.jpg?v=1714932799 900w, //attrangi.in/cdn/shop/files/emerald-dangler-attrangi_1080x.jpg?v=1714932799 1080w">
    </div></div>

<div class="grid-product__meta">
  <div class="grid-product__title grid-product__title--body">Emerald Dangler</div><div class="grid-product__price"><span class="visually-hidden">Regular price</span>
      <span class="grid-product__price--original">Rs. 2,950</span>
      <span class="visually-hidden">Sale price</span>Rs. 2,250
<span class="grid-product__price--savings">
          Save Rs. 700
        </span></div></div>
</a>
</div></div>
<div class="grid__item grid-product small--one-half medium-up--one-third grid-product__has-quick-shop aos-init aos-animate" data-aos="row-of-3" data-product-handle="reeta-polki-indian-choker-with-pearls" data-product-id="8344156930260">
<div class="grid-product__content"><div class="grid-product__tag grid-product__tag--sale">
    Sale
  </div><a href="sale-1/products/reeta-polki-indian-choker-with-pearls.html" class="grid-product__link">
<div class="grid-product__image-mask"><div class="quick-product__btn quick-product__btn--not-ready js-modal-open-quick-modal-8344156930260 small--hide">
      <span class="quick-product__label">Quick view</span>
    </div><div class="grid__image-ratio grid__image-ratio--portrait">
      <img loading="lazy" class="lazyautosizes lazyloaded" data-widths="[360, 540, 720, 900, 1080]" data-aspectratio="0.9800460475825019" data-sizes="auto" alt="Reeta Polki Indian Choker with Pearls - Attrangi" data-srcset="//attrangi.in/cdn/shop/files/reeta-polki-indian-choker-with-pearls-attrangi-1_360x.jpg?v=1714933461 360w, //attrangi.in/cdn/shop/files/reeta-polki-indian-choker-with-pearls-attrangi-1_540x.jpg?v=1714933461 540w, //attrangi.in/cdn/shop/files/reeta-polki-indian-choker-with-pearls-attrangi-1_720x.jpg?v=1714933461 720w, //attrangi.in/cdn/shop/files/reeta-polki-indian-choker-with-pearls-attrangi-1_900x.jpg?v=1714933461 900w, //attrangi.in/cdn/shop/files/reeta-polki-indian-choker-with-pearls-attrangi-1_1080x.jpg?v=1714933461 1080w" sizes="322px" srcset="//attrangi.in/cdn/shop/files/reeta-polki-indian-choker-with-pearls-attrangi-1_360x.jpg?v=1714933461 360w, //attrangi.in/cdn/shop/files/reeta-polki-indian-choker-with-pearls-attrangi-1_540x.jpg?v=1714933461 540w, //attrangi.in/cdn/shop/files/reeta-polki-indian-choker-with-pearls-attrangi-1_720x.jpg?v=1714933461 720w, //attrangi.in/cdn/shop/files/reeta-polki-indian-choker-with-pearls-attrangi-1_900x.jpg?v=1714933461 900w, //attrangi.in/cdn/shop/files/reeta-polki-indian-choker-with-pearls-attrangi-1_1080x.jpg?v=1714933461 1080w">
    </div><div class="grid-product__secondary-image small--hide"><img loading="lazy" class="lazyautosizes lazyloaded" data-widths="[360, 540, 720, 1000]" data-aspectratio="0.75" data-sizes="auto" alt="Reeta Polki Indian Choker with Pearls - Attrangi" data-srcset="//attrangi.in/cdn/shop/files/reeta-polki-indian-choker-with-pearls-attrangi-2_360x.jpg?v=1714933462 360w, //attrangi.in/cdn/shop/files/reeta-polki-indian-choker-with-pearls-attrangi-2_540x.jpg?v=1714933462 540w, //attrangi.in/cdn/shop/files/reeta-polki-indian-choker-with-pearls-attrangi-2_720x.jpg?v=1714933462 720w, //attrangi.in/cdn/shop/files/reeta-polki-indian-choker-with-pearls-attrangi-2_1000x.jpg?v=1714933462 1000w" sizes="324px" srcset="//attrangi.in/cdn/shop/files/reeta-polki-indian-choker-with-pearls-attrangi-2_360x.jpg?v=1714933462 360w, //attrangi.in/cdn/shop/files/reeta-polki-indian-choker-with-pearls-attrangi-2_540x.jpg?v=1714933462 540w, //attrangi.in/cdn/shop/files/reeta-polki-indian-choker-with-pearls-attrangi-2_720x.jpg?v=1714933462 720w, //attrangi.in/cdn/shop/files/reeta-polki-indian-choker-with-pearls-attrangi-2_1000x.jpg?v=1714933462 1000w">
    </div></div>

<div class="grid-product__meta">
  <div class="grid-product__title grid-product__title--body">Reeta Polki Indian Choker with Pearls</div><div class="grid-product__price"><span class="visually-hidden">Regular price</span>
      <span class="grid-product__price--original">Rs. 4,350</span>
      <span class="visually-hidden">Sale price</span>Rs. 3,650
<span class="grid-product__price--savings">
          Save Rs. 700
        </span></div></div>
</a>
</div></div>
<div class="grid__item grid-product small--one-half medium-up--one-third grid-product__has-quick-shop aos-init aos-animate" data-aos="row-of-3" data-product-handle="ruby-delight-diamond-set" data-product-id="8344151785684">
<div class="grid-product__content"><div class="grid-product__tag grid-product__tag--sale">
    Sale
  </div><a href="sale-1/products/ruby-delight-diamond-set.html" class="grid-product__link">
<div class="grid-product__image-mask"><div class="quick-product__btn quick-product__btn--not-ready js-modal-open-quick-modal-8344151785684 small--hide">
      <span class="quick-product__label">Quick view</span>
    </div><div class="grid__image-ratio grid__image-ratio--portrait">
      <img loading="lazy" class="lazyautosizes lazyloaded" data-widths="[360, 540, 720, 900, 1080]" data-aspectratio="0.92875" data-sizes="auto" alt="Ruby Delight Diamond Set - Attrangi" data-srcset="//attrangi.in/cdn/shop/files/ruby-delight-diamond-set-attrangi-1_360x.jpg?v=1714933494 360w, //attrangi.in/cdn/shop/files/ruby-delight-diamond-set-attrangi-1_540x.jpg?v=1714933494 540w, //attrangi.in/cdn/shop/files/ruby-delight-diamond-set-attrangi-1_720x.jpg?v=1714933494 720w, //attrangi.in/cdn/shop/files/ruby-delight-diamond-set-attrangi-1_900x.jpg?v=1714933494 900w, //attrangi.in/cdn/shop/files/ruby-delight-diamond-set-attrangi-1_1080x.jpg?v=1714933494 1080w" sizes="322px" srcset="//attrangi.in/cdn/shop/files/ruby-delight-diamond-set-attrangi-1_360x.jpg?v=1714933494 360w, //attrangi.in/cdn/shop/files/ruby-delight-diamond-set-attrangi-1_540x.jpg?v=1714933494 540w, //attrangi.in/cdn/shop/files/ruby-delight-diamond-set-attrangi-1_720x.jpg?v=1714933494 720w, //attrangi.in/cdn/shop/files/ruby-delight-diamond-set-attrangi-1_900x.jpg?v=1714933494 900w, //attrangi.in/cdn/shop/files/ruby-delight-diamond-set-attrangi-1_1080x.jpg?v=1714933494 1080w">
    </div><div class="grid-product__secondary-image small--hide"><img loading="lazy" class="lazyautosizes lazyloaded" data-widths="[360, 540, 720, 1000]" data-aspectratio="0.6725" data-sizes="auto" alt="Ruby Delight Diamond Set - Attrangi" data-srcset="//attrangi.in/cdn/shop/files/ruby-delight-diamond-set-attrangi-2_360x.jpg?v=1714933495 360w, //attrangi.in/cdn/shop/files/ruby-delight-diamond-set-attrangi-2_540x.jpg?v=1714933495 540w, //attrangi.in/cdn/shop/files/ruby-delight-diamond-set-attrangi-2_720x.jpg?v=1714933495 720w, //attrangi.in/cdn/shop/files/ruby-delight-diamond-set-attrangi-2_1000x.jpg?v=1714933495 1000w" sizes="324px" srcset="//attrangi.in/cdn/shop/files/ruby-delight-diamond-set-attrangi-2_360x.jpg?v=1714933495 360w, //attrangi.in/cdn/shop/files/ruby-delight-diamond-set-attrangi-2_540x.jpg?v=1714933495 540w, //attrangi.in/cdn/shop/files/ruby-delight-diamond-set-attrangi-2_720x.jpg?v=1714933495 720w, //attrangi.in/cdn/shop/files/ruby-delight-diamond-set-attrangi-2_1000x.jpg?v=1714933495 1000w">
    </div></div>

<div class="grid-product__meta">
  <div class="grid-product__title grid-product__title--body">Ruby Delight Diamond Set</div><div class="grid-product__price"><span class="visually-hidden">Regular price</span>
      <span class="grid-product__price--original">Rs. 3,850</span>
      <span class="visually-hidden">Sale price</span>Rs. 3,250
<span class="grid-product__price--savings">
          Save Rs. 600
        </span></div></div>
</a>
</div></div>
<div class="grid__item grid-product small--one-half medium-up--one-third grid-product__has-quick-shop aos-init aos-animate" data-aos="row-of-3" data-product-handle="mid-sized-emerald-earrings" data-product-id="8333205569748">
<div class="grid-product__content"><div class="grid-product__tag grid-product__tag--sale">
    Sale
  </div><a href="sale-1/products/mid-sized-emerald-earrings.html" class="grid-product__link">
<div class="grid-product__image-mask"><div class="quick-product__btn quick-product__btn--not-ready js-modal-open-quick-modal-8333205569748 small--hide">
      <span class="quick-product__label">Quick view</span>
    </div><div class="grid__image-ratio grid__image-ratio--portrait">
      <img loading="lazy" class="lazyautosizes lazyloaded" data-widths="[360, 540, 720, 900, 1080]" data-aspectratio="0.7204928664072633" data-sizes="auto" alt="Mid Sized Emerald Earrings - Attrangi" data-srcset="//attrangi.in/cdn/shop/files/mid-sized-emerald-earrings-attrangi_360x.jpg?v=1714933197 360w, //attrangi.in/cdn/shop/files/mid-sized-emerald-earrings-attrangi_540x.jpg?v=1714933197 540w, //attrangi.in/cdn/shop/files/mid-sized-emerald-earrings-attrangi_720x.jpg?v=1714933197 720w, //attrangi.in/cdn/shop/files/mid-sized-emerald-earrings-attrangi_900x.jpg?v=1714933197 900w, //attrangi.in/cdn/shop/files/mid-sized-emerald-earrings-attrangi_1080x.jpg?v=1714933197 1080w" sizes="322px" srcset="//attrangi.in/cdn/shop/files/mid-sized-emerald-earrings-attrangi_360x.jpg?v=1714933197 360w, //attrangi.in/cdn/shop/files/mid-sized-emerald-earrings-attrangi_540x.jpg?v=1714933197 540w, //attrangi.in/cdn/shop/files/mid-sized-emerald-earrings-attrangi_720x.jpg?v=1714933197 720w, //attrangi.in/cdn/shop/files/mid-sized-emerald-earrings-attrangi_900x.jpg?v=1714933197 900w, //attrangi.in/cdn/shop/files/mid-sized-emerald-earrings-attrangi_1080x.jpg?v=1714933197 1080w">
    </div></div>

<div class="grid-product__meta">
  <div class="grid-product__title grid-product__title--body">Mid Sized Emerald Earrings</div><div class="grid-product__price"><span class="visually-hidden">Regular price</span>
      <span class="grid-product__price--original">Rs. 2,150</span>
      <span class="visually-hidden">Sale price</span>Rs. 1,650
<span class="grid-product__price--savings">
          Save Rs. 500
        </span></div></div>
</a>
</div></div>
<div class="grid__item grid-product small--one-half medium-up--one-third grid-product__has-quick-shop aos-init aos-animate" data-aos="row-of-3" data-product-handle="pearl-hanging-drop" data-product-id="8332739838164">
<div class="grid-product__content"><div class="grid-product__tag grid-product__tag--sale">
    Sale
  </div><a href="sale-1/products/pearl-hanging-drop.html" class="grid-product__link">
<div class="grid-product__image-mask"><div class="quick-product__btn quick-product__btn--not-ready js-modal-open-quick-modal-8332739838164 small--hide">
      <span class="quick-product__label">Quick view</span>
    </div><div class="grid__image-ratio grid__image-ratio--portrait">
      <img loading="lazy" class="lazyautosizes lazyloaded" data-widths="[360, 540, 720, 900, 1080]" data-aspectratio="0.624375" data-sizes="auto" alt="Pearl Hanging Drop - Attrangi" data-srcset="//attrangi.in/cdn/shop/files/pearl-hanging-drop-attrangi_360x.jpg?v=1714933375 360w, //attrangi.in/cdn/shop/files/pearl-hanging-drop-attrangi_540x.jpg?v=1714933375 540w, //attrangi.in/cdn/shop/files/pearl-hanging-drop-attrangi_720x.jpg?v=1714933375 720w, //attrangi.in/cdn/shop/files/pearl-hanging-drop-attrangi_900x.jpg?v=1714933375 900w, //attrangi.in/cdn/shop/files/pearl-hanging-drop-attrangi_1080x.jpg?v=1714933375 1080w" sizes="322px" srcset="//attrangi.in/cdn/shop/files/pearl-hanging-drop-attrangi_360x.jpg?v=1714933375 360w, //attrangi.in/cdn/shop/files/pearl-hanging-drop-attrangi_540x.jpg?v=1714933375 540w, //attrangi.in/cdn/shop/files/pearl-hanging-drop-attrangi_720x.jpg?v=1714933375 720w, //attrangi.in/cdn/shop/files/pearl-hanging-drop-attrangi_900x.jpg?v=1714933375 900w, //attrangi.in/cdn/shop/files/pearl-hanging-drop-attrangi_1080x.jpg?v=1714933375 1080w">
    </div></div>

<div class="grid-product__meta">
  <div class="grid-product__title grid-product__title--body">Pearl Hanging Drop</div><div class="grid-product__price"><span class="visually-hidden">Regular price</span>
      <span class="grid-product__price--original">Rs. 1,650</span>
      <span class="visually-hidden">Sale price</span>Rs. 1,250
<span class="grid-product__price--savings">
          Save Rs. 400
        </span></div></div>
</a>
</div></div>
<div class="grid__item grid-product small--one-half medium-up--one-third grid-product__has-quick-shop aos-init aos-animate" data-aos="row-of-3" data-product-handle="ruby-delight-choker-set" data-product-id="8332622528724">
<div class="grid-product__content"><div class="grid-product__tag grid-product__tag--sale">
    Sale
  </div><a href="sale-1/products/ruby-delight-choker-set.html" class="grid-product__link">
<div class="grid-product__image-mask"><div class="quick-product__btn quick-product__btn--not-ready js-modal-open-quick-modal-8332622528724 small--hide">
      <span class="quick-product__label">Quick view</span>
    </div><div class="grid__image-ratio grid__image-ratio--portrait">
      <img loading="lazy" class="lazyautosizes lazyloaded" data-widths="[360, 540, 720, 900, 1080]" data-aspectratio="0.66625" data-sizes="auto" alt="" data-srcset="//attrangi.in/cdn/shop/files/WhatsAppImage2024-05-04at6.59.22PM_360x.jpg?v=1714992486 360w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-04at6.59.22PM_540x.jpg?v=1714992486 540w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-04at6.59.22PM_720x.jpg?v=1714992486 720w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-04at6.59.22PM_900x.jpg?v=1714992486 900w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-04at6.59.22PM_1080x.jpg?v=1714992486 1080w" sizes="322px" srcset="//attrangi.in/cdn/shop/files/WhatsAppImage2024-05-04at6.59.22PM_360x.jpg?v=1714992486 360w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-04at6.59.22PM_540x.jpg?v=1714992486 540w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-04at6.59.22PM_720x.jpg?v=1714992486 720w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-04at6.59.22PM_900x.jpg?v=1714992486 900w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-04at6.59.22PM_1080x.jpg?v=1714992486 1080w">
    </div><div class="grid-product__secondary-image small--hide"><img loading="lazy" class="lazyautosizes lazyloaded" data-widths="[360, 540, 720, 1000]" data-aspectratio="0.66625" data-sizes="auto" alt="" data-srcset="//attrangi.in/cdn/shop/files/WhatsAppImage2024-05-04at6.59.13PM_360x.jpg?v=1714992487 360w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-04at6.59.13PM_540x.jpg?v=1714992487 540w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-04at6.59.13PM_720x.jpg?v=1714992487 720w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-04at6.59.13PM_1000x.jpg?v=1714992487 1000w" sizes="324px" srcset="//attrangi.in/cdn/shop/files/WhatsAppImage2024-05-04at6.59.13PM_360x.jpg?v=1714992487 360w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-04at6.59.13PM_540x.jpg?v=1714992487 540w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-04at6.59.13PM_720x.jpg?v=1714992487 720w, //attrangi.in/cdn/shop/files/WhatsAppImage2024-05-04at6.59.13PM_1000x.jpg?v=1714992487 1000w">
    </div></div>

<div class="grid-product__meta">
  <div class="grid-product__title grid-product__title--body">Ruby Delight Choker Set</div><div class="grid-product__price"><span class="visually-hidden">Regular price</span>
      <span class="grid-product__price--original">Rs. 3,850</span>
      <span class="visually-hidden">Sale price</span>Rs. 3,450
<span class="grid-product__price--savings">
          Save Rs. 400
        </span></div></div>
</a>
</div></div>
<div class="grid__item grid-product small--one-half medium-up--one-third grid-product__has-quick-shop aos-init aos-animate" data-aos="row-of-3" data-product-handle="1-carat-double-line-engagement-ring" data-product-id="8314686079188">
<div class="grid-product__content"><div class="grid-product__tag grid-product__tag--sale">
    Sale
  </div><a href="sale-1/products/1-carat-double-line-engagement-ring.html" class="grid-product__link">
<div class="grid-product__image-mask"><div class="quick-product__btn quick-product__btn--not-ready js-modal-open-quick-modal-8314686079188 small--hide">
      <span class="quick-product__label">Quick view</span>
    </div><div class="grid__image-ratio grid__image-ratio--portrait">
      <img loading="lazy" class="lazyautosizes lazyloaded" data-widths="[360, 540, 720, 900, 1080]" data-aspectratio="0.75" data-sizes="auto" alt="1 Carat Double Line Engagement Ring - Attrangi" data-srcset="//attrangi.in/cdn/shop/files/1-carat-double-line-engagement-ring-attrangi_360x.jpg?v=1714932386 360w, //attrangi.in/cdn/shop/files/1-carat-double-line-engagement-ring-attrangi_540x.jpg?v=1714932386 540w, //attrangi.in/cdn/shop/files/1-carat-double-line-engagement-ring-attrangi_720x.jpg?v=1714932386 720w, //attrangi.in/cdn/shop/files/1-carat-double-line-engagement-ring-attrangi_900x.jpg?v=1714932386 900w, //attrangi.in/cdn/shop/files/1-carat-double-line-engagement-ring-attrangi_1080x.jpg?v=1714932386 1080w" sizes="322px" srcset="//attrangi.in/cdn/shop/files/1-carat-double-line-engagement-ring-attrangi_360x.jpg?v=1714932386 360w, //attrangi.in/cdn/shop/files/1-carat-double-line-engagement-ring-attrangi_540x.jpg?v=1714932386 540w, //attrangi.in/cdn/shop/files/1-carat-double-line-engagement-ring-attrangi_720x.jpg?v=1714932386 720w, //attrangi.in/cdn/shop/files/1-carat-double-line-engagement-ring-attrangi_900x.jpg?v=1714932386 900w, //attrangi.in/cdn/shop/files/1-carat-double-line-engagement-ring-attrangi_1080x.jpg?v=1714932386 1080w">
    </div></div>

<div class="grid-product__meta">
  <div class="grid-product__title grid-product__title--body">1 Carat Double Line Engagement Ring</div><div class="grid-product__price"><span class="visually-hidden">Regular price</span>
      <span class="grid-product__price--original">Rs. 1,650</span>
      <span class="visually-hidden">Sale price</span>Rs. 1,350
<span class="grid-product__price--savings">
          Save Rs. 300
        </span></div></div>
</a>
</div></div>
<div class="grid__item grid-product small--one-half medium-up--one-third grid-product__has-quick-shop aos-init aos-animate" data-aos="row-of-3" data-product-handle="pear-pendant-with-halo" data-product-id="8313255428308">
<div class="grid-product__content"><div class="grid-product__tag grid-product__tag--sale">
    Sale
  </div><a href="sale-1/products/pear-pendant-with-halo.html" class="grid-product__link">
<div class="grid-product__image-mask"><div class="quick-product__btn quick-product__btn--not-ready js-modal-open-quick-modal-8313255428308 small--hide">
      <span class="quick-product__label">Quick view</span>
    </div><div class="grid__image-ratio grid__image-ratio--portrait">
      <img loading="lazy" class="lazyautosizes lazyloaded" data-widths="[360, 540, 720, 900, 1080]" data-aspectratio="0.75" data-sizes="auto" alt="Pear Pendant with Halo - Attrangi" data-srcset="//attrangi.in/cdn/shop/files/pear-pendant-with-halo-attrangi_360x.jpg?v=1714933372 360w, //attrangi.in/cdn/shop/files/pear-pendant-with-halo-attrangi_540x.jpg?v=1714933372 540w, //attrangi.in/cdn/shop/files/pear-pendant-with-halo-attrangi_720x.jpg?v=1714933372 720w, //attrangi.in/cdn/shop/files/pear-pendant-with-halo-attrangi_900x.jpg?v=1714933372 900w, //attrangi.in/cdn/shop/files/pear-pendant-with-halo-attrangi_1080x.jpg?v=1714933372 1080w" sizes="322px" srcset="//attrangi.in/cdn/shop/files/pear-pendant-with-halo-attrangi_360x.jpg?v=1714933372 360w, //attrangi.in/cdn/shop/files/pear-pendant-with-halo-attrangi_540x.jpg?v=1714933372 540w, //attrangi.in/cdn/shop/files/pear-pendant-with-halo-attrangi_720x.jpg?v=1714933372 720w, //attrangi.in/cdn/shop/files/pear-pendant-with-halo-attrangi_900x.jpg?v=1714933372 900w, //attrangi.in/cdn/shop/files/pear-pendant-with-halo-attrangi_1080x.jpg?v=1714933372 1080w">
    </div></div>

<div class="grid-product__meta">
  <div class="grid-product__title grid-product__title--body">Pear Pendant with Halo</div><div class="grid-product__price"><span class="visually-hidden">Regular price</span>
      <span class="grid-product__price--original">Rs. 1,450</span>
      <span class="visually-hidden">Sale price</span>Rs. 1,250
<span class="grid-product__price--savings">
          Save Rs. 200
        </span></div></div>
</a>
</div></div>
<div class="grid__item grid-product small--one-half medium-up--one-third grid-product__has-quick-shop aos-init aos-animate" data-aos="row-of-3" data-product-handle="bobby-long-diamond-statement-earrings" data-product-id="8307025871060">
<div class="grid-product__content"><div class="grid-product__tag grid-product__tag--sale">
    Sale
  </div><a href="sale-1/products/bobby-long-diamond-statement-earrings.html" class="grid-product__link">
<div class="grid-product__image-mask"><div class="quick-product__btn quick-product__btn--not-ready js-modal-open-quick-modal-8307025871060 small--hide">
      <span class="quick-product__label">Quick view</span>
    </div><div class="grid__image-ratio grid__image-ratio--portrait">
      <img loading="lazy" class="lazyautosizes lazyloaded" data-widths="[360, 540, 720, 900, 1080]" data-aspectratio="0.75" data-sizes="auto" alt="Bobby Long Diamond Statement Earrings - Attrangi" data-srcset="//attrangi.in/cdn/shop/files/bobby-long-diamond-statement-earrings-attrangi_360x.jpg?v=1714932575 360w, //attrangi.in/cdn/shop/files/bobby-long-diamond-statement-earrings-attrangi_540x.jpg?v=1714932575 540w, //attrangi.in/cdn/shop/files/bobby-long-diamond-statement-earrings-attrangi_720x.jpg?v=1714932575 720w, //attrangi.in/cdn/shop/files/bobby-long-diamond-statement-earrings-attrangi_900x.jpg?v=1714932575 900w, //attrangi.in/cdn/shop/files/bobby-long-diamond-statement-earrings-attrangi_1080x.jpg?v=1714932575 1080w" sizes="322px" srcset="//attrangi.in/cdn/shop/files/bobby-long-diamond-statement-earrings-attrangi_360x.jpg?v=1714932575 360w, //attrangi.in/cdn/shop/files/bobby-long-diamond-statement-earrings-attrangi_540x.jpg?v=1714932575 540w, //attrangi.in/cdn/shop/files/bobby-long-diamond-statement-earrings-attrangi_720x.jpg?v=1714932575 720w, //attrangi.in/cdn/shop/files/bobby-long-diamond-statement-earrings-attrangi_900x.jpg?v=1714932575 900w, //attrangi.in/cdn/shop/files/bobby-long-diamond-statement-earrings-attrangi_1080x.jpg?v=1714932575 1080w">
    </div></div>

<div class="grid-product__meta">
  <div class="grid-product__title grid-product__title--body">Bobby Long Diamond Statement Earrings</div><div class="grid-product__price"><span class="visually-hidden">Regular price</span>
      <span class="grid-product__price--original">Rs. 3,950</span>
      <span class="visually-hidden">Sale price</span>Rs. 3,650
<span class="grid-product__price--savings">
          Save Rs. 300
        </span></div></div>
</a>
</div></div>
<div class="grid__item grid-product small--one-half medium-up--one-third grid-product__has-quick-shop aos-init aos-animate" data-aos="row-of-3" data-product-handle="fallon-honeybee-hive-party-wear-long-earrings" data-product-id="8234415227092">
<div class="grid-product__content"><div class="grid-product__tag grid-product__tag--sale">
    Sale
  </div><a href="sale-1/products/fallon-honeybee-hive-party-wear-long-earrings.html" class="grid-product__link">
<div class="grid-product__image-mask"><div class="quick-product__btn js-modal-open-quick-modal-8234415227092 small--hide" aria-expanded="false">
      <span class="quick-product__label">Quick view</span>
    </div><div class="grid__image-ratio grid__image-ratio--portrait">
      <img loading="lazy" class="lazyautosizes lazyloaded" data-widths="[360, 540, 720, 900, 1080]" data-aspectratio="0.66625" data-sizes="auto" alt="Fallon Honeybee Hive Party Wear Long Earrings - Attrangi" data-srcset="//attrangi.in/cdn/shop/files/fallon-honeybee-hive-party-wear-long-earrings-attrangi-1_360x.jpg?v=1714932831 360w, //attrangi.in/cdn/shop/files/fallon-honeybee-hive-party-wear-long-earrings-attrangi-1_540x.jpg?v=1714932831 540w, //attrangi.in/cdn/shop/files/fallon-honeybee-hive-party-wear-long-earrings-attrangi-1_720x.jpg?v=1714932831 720w, //attrangi.in/cdn/shop/files/fallon-honeybee-hive-party-wear-long-earrings-attrangi-1_900x.jpg?v=1714932831 900w, //attrangi.in/cdn/shop/files/fallon-honeybee-hive-party-wear-long-earrings-attrangi-1_1080x.jpg?v=1714932831 1080w" sizes="322px" srcset="//attrangi.in/cdn/shop/files/fallon-honeybee-hive-party-wear-long-earrings-attrangi-1_360x.jpg?v=1714932831 360w, //attrangi.in/cdn/shop/files/fallon-honeybee-hive-party-wear-long-earrings-attrangi-1_540x.jpg?v=1714932831 540w, //attrangi.in/cdn/shop/files/fallon-honeybee-hive-party-wear-long-earrings-attrangi-1_720x.jpg?v=1714932831 720w, //attrangi.in/cdn/shop/files/fallon-honeybee-hive-party-wear-long-earrings-attrangi-1_900x.jpg?v=1714932831 900w, //attrangi.in/cdn/shop/files/fallon-honeybee-hive-party-wear-long-earrings-attrangi-1_1080x.jpg?v=1714932831 1080w">
    </div><div class="grid-product__secondary-image small--hide"><img loading="lazy" class="lazyautosizes lazyloaded" data-widths="[360, 540, 720, 1000]" data-aspectratio="0.66625" data-sizes="auto" alt="Fallon Honeybee Hive Party Wear Long Earrings - Attrangi" data-srcset="//attrangi.in/cdn/shop/files/fallon-honeybee-hive-party-wear-long-earrings-attrangi-2_360x.jpg?v=1714932832 360w, //attrangi.in/cdn/shop/files/fallon-honeybee-hive-party-wear-long-earrings-attrangi-2_540x.jpg?v=1714932832 540w, //attrangi.in/cdn/shop/files/fallon-honeybee-hive-party-wear-long-earrings-attrangi-2_720x.jpg?v=1714932832 720w, //attrangi.in/cdn/shop/files/fallon-honeybee-hive-party-wear-long-earrings-attrangi-2_1000x.jpg?v=1714932832 1000w" sizes="324px" srcset="//attrangi.in/cdn/shop/files/fallon-honeybee-hive-party-wear-long-earrings-attrangi-2_360x.jpg?v=1714932832 360w, //attrangi.in/cdn/shop/files/fallon-honeybee-hive-party-wear-long-earrings-attrangi-2_540x.jpg?v=1714932832 540w, //attrangi.in/cdn/shop/files/fallon-honeybee-hive-party-wear-long-earrings-attrangi-2_720x.jpg?v=1714932832 720w, //attrangi.in/cdn/shop/files/fallon-honeybee-hive-party-wear-long-earrings-attrangi-2_1000x.jpg?v=1714932832 1000w">
    </div>
<div class="grid-product__color-image grid-product__color-image--44707100393684 small--hide">
              </div>
<div class="grid-product__color-image grid-product__color-image--44707100426452 small--hide">
              </div></div>

<div class="grid-product__meta">
  <div class="grid-product__title grid-product__title--body">Fallon Honeybee Hive Party Wear Long Earrings</div><div class="grid-product__price"><span class="visually-hidden">Regular price</span>
      <span class="grid-product__price--original">Rs. 1,950</span>
      <span class="visually-hidden">Sale price</span>Rs. 1,650
<span class="grid-product__price--savings">
          Save Rs. 300
        </span></div></div>
</a>
</div><div class="grid-product__colors grid-product__colors--8234415227092">
<a href="sale-1/products/fallon-honeybee-hive-party-wear-long-earringsdfaf.html?variant=44707100393684" class="color-swatch color-swatch--small color-swatch--green color-swatch--with-image" data-variant-id="44707100393684" data-variant-image="//attrangi.in/cdn/shop/files/fallon-honeybee-hive-party-wear-long-earrings-attrangi-1_400x.jpg?v=1714932831" style="background-image: url(../cdn/shop/t/40/assets/green_50x.html); background-color: green;">
          <span class="visually-hidden">Green</span>
        </a>
<a href="sale-1/products/fallon-honeybee-hive-party-wear-long-earrings46e8.html?variant=44707100426452" class="color-swatch color-swatch--small color-swatch--blue color-swatch--with-image" data-variant-id="44707100426452" data-variant-image="//attrangi.in/cdn/shop/files/fallon-honeybee-hive-party-wear-long-earrings-attrangi-2_400x.jpg?v=1714932832" style="background-image: url(../cdn/shop/t/40/assets/blue_50x.html); background-color: blue;">
          <span class="visually-hidden">Blue</span>
        </a></div></div>
<div class="grid__item grid-product small--one-half medium-up--one-third grid-product__has-quick-shop aos-init aos-animate" data-aos="row-of-3" data-product-handle="oh-lara-diamond-earrings-long-coloured-stone-earrings" data-product-id="8229715837140">
<div class="grid-product__content"><div class="grid-product__tag grid-product__tag--sale">
    Sale
  </div><a href="sale-1/products/oh-lara-diamond-earrings-long-coloured-stone-earrings.html" class="grid-product__link">
<div class="grid-product__image-mask"><div class="quick-product__btn quick-product__btn--not-ready js-modal-open-quick-modal-8229715837140 small--hide">
      <span class="quick-product__label">Quick view</span>
    </div><div class="grid__image-ratio grid__image-ratio--portrait">
      <img loading="lazy" class="lazyautosizes lazyloaded" data-widths="[360, 540, 720, 900, 1080]" data-aspectratio="0.66625" data-sizes="auto" alt="Oh Lara Diamond Earrings | Long Coloured Stone Earrings - Attrangi" data-srcset="//attrangi.in/cdn/shop/files/oh-lara-diamond-earrings-or-long-coloured-stone-earrings-attrangi_360x.jpg?v=1714933325 360w, //attrangi.in/cdn/shop/files/oh-lara-diamond-earrings-or-long-coloured-stone-earrings-attrangi_540x.jpg?v=1714933325 540w, //attrangi.in/cdn/shop/files/oh-lara-diamond-earrings-or-long-coloured-stone-earrings-attrangi_720x.jpg?v=1714933325 720w, //attrangi.in/cdn/shop/files/oh-lara-diamond-earrings-or-long-coloured-stone-earrings-attrangi_900x.jpg?v=1714933325 900w, //attrangi.in/cdn/shop/files/oh-lara-diamond-earrings-or-long-coloured-stone-earrings-attrangi_1080x.jpg?v=1714933325 1080w" sizes="322px" srcset="//attrangi.in/cdn/shop/files/oh-lara-diamond-earrings-or-long-coloured-stone-earrings-attrangi_360x.jpg?v=1714933325 360w, //attrangi.in/cdn/shop/files/oh-lara-diamond-earrings-or-long-coloured-stone-earrings-attrangi_540x.jpg?v=1714933325 540w, //attrangi.in/cdn/shop/files/oh-lara-diamond-earrings-or-long-coloured-stone-earrings-attrangi_720x.jpg?v=1714933325 720w, //attrangi.in/cdn/shop/files/oh-lara-diamond-earrings-or-long-coloured-stone-earrings-attrangi_900x.jpg?v=1714933325 900w, //attrangi.in/cdn/shop/files/oh-lara-diamond-earrings-or-long-coloured-stone-earrings-attrangi_1080x.jpg?v=1714933325 1080w">
    </div></div>

<div class="grid-product__meta">
  <div class="grid-product__title grid-product__title--body">Oh Lara Diamond Earrings | Long Coloured Stone Earrings</div><div class="grid-product__price"><span class="visually-hidden">Regular price</span>
      <span class="grid-product__price--original">Rs. 2,950</span>
      <span class="visually-hidden">Sale price</span>Rs. 2,500
<span class="grid-product__price--savings">
          Save Rs. 450
        </span></div></div>
</a>
</div></div>
<div class="grid__item grid-product small--one-half medium-up--one-third grid-product__has-quick-shop aos-init aos-animate" data-aos="row-of-3" data-product-handle="chaitali-necklace-with-mid-sized-jhumkis-sone-pe-suhaga-collection" data-product-id="8168531034324">
<div class="grid-product__content"><div class="grid-product__tag grid-product__tag--sale">
    Sale
  </div><a href="sale-1/products/chaitali-necklace-with-mid-sized-jhumkis-sone-pe-suhaga-collection.html" class="grid-product__link">
<div class="grid-product__image-mask"><div class="quick-product__btn quick-product__btn--not-ready js-modal-open-quick-modal-8168531034324 small--hide">
      <span class="quick-product__label">Quick view</span>
    </div><div class="grid__image-ratio grid__image-ratio--portrait">
      <img loading="lazy" class="lazyautosizes lazyloaded" data-widths="[360, 540, 720, 900, 1080]" data-aspectratio="0.61875" data-sizes="auto" alt="Chaitali Necklace with Mid- Sized Jhumkis | Sone Pe Suhaga Collection - Attrangi" data-srcset="//attrangi.in/cdn/shop/files/chaitali-necklace-with-mid-sized-jhumkis-or-sone-pe-suhaga-collection-attrangi-1_360x.jpg?v=1714932592 360w, //attrangi.in/cdn/shop/files/chaitali-necklace-with-mid-sized-jhumkis-or-sone-pe-suhaga-collection-attrangi-1_540x.jpg?v=1714932592 540w, //attrangi.in/cdn/shop/files/chaitali-necklace-with-mid-sized-jhumkis-or-sone-pe-suhaga-collection-attrangi-1_720x.jpg?v=1714932592 720w, //attrangi.in/cdn/shop/files/chaitali-necklace-with-mid-sized-jhumkis-or-sone-pe-suhaga-collection-attrangi-1_900x.jpg?v=1714932592 900w, //attrangi.in/cdn/shop/files/chaitali-necklace-with-mid-sized-jhumkis-or-sone-pe-suhaga-collection-attrangi-1_1080x.jpg?v=1714932592 1080w" sizes="322px" srcset="//attrangi.in/cdn/shop/files/chaitali-necklace-with-mid-sized-jhumkis-or-sone-pe-suhaga-collection-attrangi-1_360x.jpg?v=1714932592 360w, //attrangi.in/cdn/shop/files/chaitali-necklace-with-mid-sized-jhumkis-or-sone-pe-suhaga-collection-attrangi-1_540x.jpg?v=1714932592 540w, //attrangi.in/cdn/shop/files/chaitali-necklace-with-mid-sized-jhumkis-or-sone-pe-suhaga-collection-attrangi-1_720x.jpg?v=1714932592 720w, //attrangi.in/cdn/shop/files/chaitali-necklace-with-mid-sized-jhumkis-or-sone-pe-suhaga-collection-attrangi-1_900x.jpg?v=1714932592 900w, //attrangi.in/cdn/shop/files/chaitali-necklace-with-mid-sized-jhumkis-or-sone-pe-suhaga-collection-attrangi-1_1080x.jpg?v=1714932592 1080w">
    </div><div class="grid-product__secondary-image small--hide"><img loading="lazy" class="lazyautosizes lazyloaded" data-widths="[360, 540, 720, 1000]" data-aspectratio="0.55625" data-sizes="auto" alt="Chaitali Necklace with Mid- Sized Jhumkis | Sone Pe Suhaga Collection - Attrangi" data-srcset="//attrangi.in/cdn/shop/files/chaitali-necklace-with-mid-sized-jhumkis-or-sone-pe-suhaga-collection-attrangi-2_360x.jpg?v=1714932594 360w, //attrangi.in/cdn/shop/files/chaitali-necklace-with-mid-sized-jhumkis-or-sone-pe-suhaga-collection-attrangi-2_540x.jpg?v=1714932594 540w, //attrangi.in/cdn/shop/files/chaitali-necklace-with-mid-sized-jhumkis-or-sone-pe-suhaga-collection-attrangi-2_720x.jpg?v=1714932594 720w, //attrangi.in/cdn/shop/files/chaitali-necklace-with-mid-sized-jhumkis-or-sone-pe-suhaga-collection-attrangi-2_1000x.jpg?v=1714932594 1000w" sizes="324px" srcset="//attrangi.in/cdn/shop/files/chaitali-necklace-with-mid-sized-jhumkis-or-sone-pe-suhaga-collection-attrangi-2_360x.jpg?v=1714932594 360w, //attrangi.in/cdn/shop/files/chaitali-necklace-with-mid-sized-jhumkis-or-sone-pe-suhaga-collection-attrangi-2_540x.jpg?v=1714932594 540w, //attrangi.in/cdn/shop/files/chaitali-necklace-with-mid-sized-jhumkis-or-sone-pe-suhaga-collection-attrangi-2_720x.jpg?v=1714932594 720w, //attrangi.in/cdn/shop/files/chaitali-necklace-with-mid-sized-jhumkis-or-sone-pe-suhaga-collection-attrangi-2_1000x.jpg?v=1714932594 1000w">
    </div></div>

<div class="grid-product__meta">
  <div class="grid-product__title grid-product__title--body">Chaitali Necklace with Mid- Sized Jhumkis | Sone Pe Suhaga Collection</div><div class="grid-product__price"><span class="visually-hidden">Regular price</span>
      <span class="grid-product__price--original">Rs. 5,850</span>
      <span class="visually-hidden">Sale price</span>Rs. 4,250
<span class="grid-product__price--savings">
          Save Rs. 1,600
        </span></div></div>
</a>
</div></div>
<div class="grid__item grid-product small--one-half medium-up--one-third grid-product__has-quick-shop aos-init aos-animate" data-aos="row-of-3" data-product-handle="kusum-long-necklace-sone-pe-suhaga-collection" data-product-id="8168525529300">
<div class="grid-product__content"><div class="grid-product__tag grid-product__tag--sale">
    Sale
  </div><a href="sale-1/products/kusum-long-necklace-sone-pe-suhaga-collection.html" class="grid-product__link">
<div class="grid-product__image-mask"><div class="quick-product__btn quick-product__btn--not-ready js-modal-open-quick-modal-8168525529300 small--hide">
      <span class="quick-product__label">Quick view</span>
    </div><div class="grid__image-ratio grid__image-ratio--portrait">
      <img loading="lazy" class="lazyautosizes lazyloaded" data-widths="[360, 540, 720, 900, 1080]" data-aspectratio="0.66625" data-sizes="auto" alt="Kusum Long Necklace | Sone Pe Suhaga Collection - Attrangi" data-srcset="//attrangi.in/cdn/shop/files/kusum-long-necklace-or-sone-pe-suhaga-collection-attrangi_360x.jpg?v=1714933099 360w, //attrangi.in/cdn/shop/files/kusum-long-necklace-or-sone-pe-suhaga-collection-attrangi_540x.jpg?v=1714933099 540w, //attrangi.in/cdn/shop/files/kusum-long-necklace-or-sone-pe-suhaga-collection-attrangi_720x.jpg?v=1714933099 720w, //attrangi.in/cdn/shop/files/kusum-long-necklace-or-sone-pe-suhaga-collection-attrangi_900x.jpg?v=1714933099 900w, //attrangi.in/cdn/shop/files/kusum-long-necklace-or-sone-pe-suhaga-collection-attrangi_1080x.jpg?v=1714933099 1080w" sizes="322px" srcset="//attrangi.in/cdn/shop/files/kusum-long-necklace-or-sone-pe-suhaga-collection-attrangi_360x.jpg?v=1714933099 360w, //attrangi.in/cdn/shop/files/kusum-long-necklace-or-sone-pe-suhaga-collection-attrangi_540x.jpg?v=1714933099 540w, //attrangi.in/cdn/shop/files/kusum-long-necklace-or-sone-pe-suhaga-collection-attrangi_720x.jpg?v=1714933099 720w, //attrangi.in/cdn/shop/files/kusum-long-necklace-or-sone-pe-suhaga-collection-attrangi_900x.jpg?v=1714933099 900w, //attrangi.in/cdn/shop/files/kusum-long-necklace-or-sone-pe-suhaga-collection-attrangi_1080x.jpg?v=1714933099 1080w">
    </div></div>

<div class="grid-product__meta">
  <div class="grid-product__title grid-product__title--body">Kusum Long Necklace | Sone Pe Suhaga Collection</div><div class="grid-product__price"><span class="visually-hidden">Regular price</span>
      <span class="grid-product__price--original">Rs. 8,650</span>
      <span class="visually-hidden">Sale price</span>Rs. 7,000
<span class="grid-product__price--savings">
          Save Rs. 1,650
        </span></div></div>
</a>
</div></div>
<div class="grid__item grid-product small--one-half medium-up--one-third grid-product__has-quick-shop aos-init aos-animate" data-aos="row-of-3" data-product-handle="rasrava-gold-double-layered-jhumka-sone-pe-suhaga-collection" data-product-id="8156505637076">
<div class="grid-product__content"><div class="grid-product__tag grid-product__tag--sale">
    Sale
  </div><a href="sale-1/products/rasrava-gold-double-layered-jhumka-sone-pe-suhaga-collection.html" class="grid-product__link">
<div class="grid-product__image-mask"><div class="quick-product__btn quick-product__btn--not-ready js-modal-open-quick-modal-8156505637076 small--hide">
      <span class="quick-product__label">Quick view</span>
    </div><div class="grid__image-ratio grid__image-ratio--portrait">
      <img loading="lazy" class="lazyautosizes lazyloaded" data-widths="[360, 540, 720, 900, 1080]" data-aspectratio="0.7484375" data-sizes="auto" alt="RasRava Gold Double Layered Jhumka | Sone Pe Suhaga Collection - Attrangi" data-srcset="//attrangi.in/cdn/shop/files/rasrava-gold-double-layered-jhumka-or-sone-pe-suhaga-collection-attrangi_360x.jpg?v=1714933451 360w, //attrangi.in/cdn/shop/files/rasrava-gold-double-layered-jhumka-or-sone-pe-suhaga-collection-attrangi_540x.jpg?v=1714933451 540w, //attrangi.in/cdn/shop/files/rasrava-gold-double-layered-jhumka-or-sone-pe-suhaga-collection-attrangi_720x.jpg?v=1714933451 720w, //attrangi.in/cdn/shop/files/rasrava-gold-double-layered-jhumka-or-sone-pe-suhaga-collection-attrangi_900x.jpg?v=1714933451 900w, //attrangi.in/cdn/shop/files/rasrava-gold-double-layered-jhumka-or-sone-pe-suhaga-collection-attrangi_1080x.jpg?v=1714933451 1080w" sizes="322px" srcset="//attrangi.in/cdn/shop/files/rasrava-gold-double-layered-jhumka-or-sone-pe-suhaga-collection-attrangi_360x.jpg?v=1714933451 360w, //attrangi.in/cdn/shop/files/rasrava-gold-double-layered-jhumka-or-sone-pe-suhaga-collection-attrangi_540x.jpg?v=1714933451 540w, //attrangi.in/cdn/shop/files/rasrava-gold-double-layered-jhumka-or-sone-pe-suhaga-collection-attrangi_720x.jpg?v=1714933451 720w, //attrangi.in/cdn/shop/files/rasrava-gold-double-layered-jhumka-or-sone-pe-suhaga-collection-attrangi_900x.jpg?v=1714933451 900w, //attrangi.in/cdn/shop/files/rasrava-gold-double-layered-jhumka-or-sone-pe-suhaga-collection-attrangi_1080x.jpg?v=1714933451 1080w">
    </div></div>

<div class="grid-product__meta">
  <div class="grid-product__title grid-product__title--body">RasRava Gold Double Layered Jhumka | Sone Pe Suhaga Collection</div><div class="grid-product__price"><span class="visually-hidden">Regular price</span>
      <span class="grid-product__price--original">Rs. 1,950</span>
      <span class="visually-hidden">Sale price</span>Rs. 1,650
<span class="grid-product__price--savings">
          Save Rs. 300
        </span></div></div>
</a>
</div></div>
<div class="grid__item grid-product small--one-half medium-up--one-third grid-product__has-quick-shop aos-init aos-animate" data-aos="row-of-3" data-product-handle="elevated-diamond-ring" data-product-id="7081022455977">
<div class="grid-product__content"><div class="grid-product__tag grid-product__tag--sale">
    Sale
  </div><a href="sale-1/products/elevated-diamond-ring.html" class="grid-product__link">
<div class="grid-product__image-mask"><div class="quick-product__btn quick-product__btn--not-ready js-modal-open-quick-modal-7081022455977 small--hide">
      <span class="quick-product__label">Quick view</span>
    </div><div class="grid__image-ratio grid__image-ratio--portrait">
      <img loading="lazy" class="lazyautosizes lazyloaded" data-widths="[360, 540, 720, 900, 1080]" data-aspectratio="0.7484375" data-sizes="auto" alt="Elevated Diamond Ring - Attrangi" data-srcset="//attrangi.in/cdn/shop/files/elevated-diamond-ring-attrangi-1_360x.jpg?v=1705733211 360w, //attrangi.in/cdn/shop/files/elevated-diamond-ring-attrangi-1_540x.jpg?v=1705733211 540w, //attrangi.in/cdn/shop/files/elevated-diamond-ring-attrangi-1_720x.jpg?v=1705733211 720w, //attrangi.in/cdn/shop/files/elevated-diamond-ring-attrangi-1_900x.jpg?v=1705733211 900w, //attrangi.in/cdn/shop/files/elevated-diamond-ring-attrangi-1_1080x.jpg?v=1705733211 1080w" sizes="322px" srcset="//attrangi.in/cdn/shop/files/elevated-diamond-ring-attrangi-1_360x.jpg?v=1705733211 360w, //attrangi.in/cdn/shop/files/elevated-diamond-ring-attrangi-1_540x.jpg?v=1705733211 540w, //attrangi.in/cdn/shop/files/elevated-diamond-ring-attrangi-1_720x.jpg?v=1705733211 720w, //attrangi.in/cdn/shop/files/elevated-diamond-ring-attrangi-1_900x.jpg?v=1705733211 900w, //attrangi.in/cdn/shop/files/elevated-diamond-ring-attrangi-1_1080x.jpg?v=1705733211 1080w">
    </div><div class="grid-product__secondary-image small--hide"><img loading="lazy" class="lazyautosizes lazyloaded" data-widths="[360, 540, 720, 1000]" data-aspectratio="0.7484375" data-sizes="auto" alt="Elevated Diamond Ring - Attrangi" data-srcset="//attrangi.in/cdn/shop/files/elevated-diamond-ring-attrangi-2_360x.jpg?v=1705733212 360w, //attrangi.in/cdn/shop/files/elevated-diamond-ring-attrangi-2_540x.jpg?v=1705733212 540w, //attrangi.in/cdn/shop/files/elevated-diamond-ring-attrangi-2_720x.jpg?v=1705733212 720w, //attrangi.in/cdn/shop/files/elevated-diamond-ring-attrangi-2_1000x.jpg?v=1705733212 1000w" sizes="324px" srcset="//attrangi.in/cdn/shop/files/elevated-diamond-ring-attrangi-2_360x.jpg?v=1705733212 360w, //attrangi.in/cdn/shop/files/elevated-diamond-ring-attrangi-2_540x.jpg?v=1705733212 540w, //attrangi.in/cdn/shop/files/elevated-diamond-ring-attrangi-2_720x.jpg?v=1705733212 720w, //attrangi.in/cdn/shop/files/elevated-diamond-ring-attrangi-2_1000x.jpg?v=1705733212 1000w">
    </div>
<div class="grid-product__color-image grid-product__color-image--40832862126249 small--hide">
              </div>
<div class="grid-product__color-image grid-product__color-image--40832862159017 small--hide">
              </div>
<div class="grid-product__color-image grid-product__color-image--40832862191785 small--hide">
              </div>











</div>

<div class="grid-product__meta">
  <div class="grid-product__title grid-product__title--body">Elevated Diamond Ring</div><div class="grid-product__price"><span class="visually-hidden">Regular price</span>
      <span class="grid-product__price--original">Rs. 1,650</span>
      <span class="visually-hidden">Sale price</span>Rs. 1,450
<span class="grid-product__price--savings">
          Save Rs. 200
        </span></div></div>
</a>
</div><div class="grid-product__colors grid-product__colors--7081022455977">
<a href="sale-1/products/elevated-diamond-ringec42.html?variant=40832862126249" class="color-swatch color-swatch--small color-swatch--rose-gold color-swatch--with-image" data-variant-id="40832862126249" data-variant-image="//attrangi.in/cdn/shop/files/elevated-diamond-ring-attrangi-1_400x.jpg?v=1705733211" style="background-image: url(../cdn/shop/t/40/assets/rose-gold_50x.png); background-color: gold;">
          <span class="visually-hidden">Rose Gold</span>
        </a>
<a href="sale-1/products/elevated-diamond-ring69c2.html?variant=40832862159017" class="color-swatch color-swatch--small color-swatch--gold color-swatch--with-image" data-variant-id="40832862159017" data-variant-image="//attrangi.in/cdn/shop/files/elevated-diamond-ring-attrangi-9_400x.jpg?v=1705733222" style="background-image: url(../cdn/shop/t/40/assets/gold_50x.html); background-color: gold;">
          <span class="visually-hidden">Gold</span>
        </a>
<a href="sale-1/products/elevated-diamond-ring2fe1.html?variant=40832862191785" class="color-swatch color-swatch--small color-swatch--silver color-swatch--with-image" data-variant-id="40832862191785" data-variant-image="//attrangi.in/cdn/shop/files/elevated-diamond-ring-attrangi-6_400x.jpg?v=1705733218" style="background-image: url(../cdn/shop/t/40/assets/silver_50x.html); background-color: silver;">
          <span class="visually-hidden">Silver</span>
        </a>











</div></div>
<div class="grid__item grid-product small--one-half medium-up--one-third grid-product__has-quick-shop aos-init aos-animate" data-aos="row-of-3" data-product-handle="nia-grey-pearl-drop-diamond-earrings" data-product-id="8067801710804">
<div class="grid-product__content"><div class="grid-product__tag grid-product__tag--sale">
    Sale
  </div><a href="sale-1/products/nia-grey-pearl-drop-diamond-earrings.html" class="grid-product__link">
<div class="grid-product__image-mask"><div class="quick-product__btn quick-product__btn--not-ready js-modal-open-quick-modal-8067801710804 small--hide">
      <span class="quick-product__label">Quick view</span>
    </div><div class="grid__image-ratio grid__image-ratio--portrait">
      <img loading="lazy" class="lazyautosizes lazyloaded" data-widths="[360, 540, 720, 900, 1080]" data-aspectratio="0.66625" data-sizes="auto" alt="Nia Grey Pearl Drop Diamond Earrings - Attrangi" data-srcset="//attrangi.in/cdn/shop/files/nia-grey-pearl-drop-diamond-earrings-attrangi_360x.jpg?v=1705735252 360w, //attrangi.in/cdn/shop/files/nia-grey-pearl-drop-diamond-earrings-attrangi_540x.jpg?v=1705735252 540w, //attrangi.in/cdn/shop/files/nia-grey-pearl-drop-diamond-earrings-attrangi_720x.jpg?v=1705735252 720w, //attrangi.in/cdn/shop/files/nia-grey-pearl-drop-diamond-earrings-attrangi_900x.jpg?v=1705735252 900w, //attrangi.in/cdn/shop/files/nia-grey-pearl-drop-diamond-earrings-attrangi_1080x.jpg?v=1705735252 1080w" sizes="322px" srcset="//attrangi.in/cdn/shop/files/nia-grey-pearl-drop-diamond-earrings-attrangi_360x.jpg?v=1705735252 360w, //attrangi.in/cdn/shop/files/nia-grey-pearl-drop-diamond-earrings-attrangi_540x.jpg?v=1705735252 540w, //attrangi.in/cdn/shop/files/nia-grey-pearl-drop-diamond-earrings-attrangi_720x.jpg?v=1705735252 720w, //attrangi.in/cdn/shop/files/nia-grey-pearl-drop-diamond-earrings-attrangi_900x.jpg?v=1705735252 900w, //attrangi.in/cdn/shop/files/nia-grey-pearl-drop-diamond-earrings-attrangi_1080x.jpg?v=1705735252 1080w">
    </div></div>

<div class="grid-product__meta">
  <div class="grid-product__title grid-product__title--body">Nia Grey Pearl Drop Diamond Earrings</div><div class="grid-product__price"><span class="visually-hidden">Regular price</span>
      <span class="grid-product__price--original">Rs. 1,750</span>
      <span class="visually-hidden">Sale price</span>Rs. 1,450
<span class="grid-product__price--savings">
          Save Rs. 300
        </span></div></div>
</a>
</div></div>
<div class="grid__item grid-product small--one-half medium-up--one-third grid-product__has-quick-shop aos-init aos-animate" data-aos="row-of-3" data-product-handle="fayola-victorian-jhaalar-polki-set-antique-gold-collection" data-product-id="7925973254356">
<div class="grid-product__content"><div class="grid-product__tag grid-product__tag--sale">
    Sale
  </div><a href="sale-1/products/fayola-victorian-jhaalar-polki-set-antique-gold-collection.html" class="grid-product__link">
<div class="grid-product__image-mask"><div class="quick-product__btn quick-product__btn--not-ready js-modal-open-quick-modal-7925973254356 small--hide">
      <span class="quick-product__label">Quick view</span>
    </div><div class="grid__image-ratio grid__image-ratio--portrait">
      <img loading="lazy" class="lazyautosizes lazyloaded" data-widths="[360, 540, 720, 900, 1080]" data-aspectratio="0.66625" data-sizes="auto" alt="Fayola Victorian Jhaalar Polki Set | Antique Gold Collection - Attrangi" data-srcset="//attrangi.in/cdn/shop/files/fayola-victorian-jhaalar-polki-set-or-antique-gold-collection-attrangi-1_360x.jpg?v=1705734581 360w, //attrangi.in/cdn/shop/files/fayola-victorian-jhaalar-polki-set-or-antique-gold-collection-attrangi-1_540x.jpg?v=1705734581 540w, //attrangi.in/cdn/shop/files/fayola-victorian-jhaalar-polki-set-or-antique-gold-collection-attrangi-1_720x.jpg?v=1705734581 720w, //attrangi.in/cdn/shop/files/fayola-victorian-jhaalar-polki-set-or-antique-gold-collection-attrangi-1_900x.jpg?v=1705734581 900w, //attrangi.in/cdn/shop/files/fayola-victorian-jhaalar-polki-set-or-antique-gold-collection-attrangi-1_1080x.jpg?v=1705734581 1080w" sizes="322px" srcset="//attrangi.in/cdn/shop/files/fayola-victorian-jhaalar-polki-set-or-antique-gold-collection-attrangi-1_360x.jpg?v=1705734581 360w, //attrangi.in/cdn/shop/files/fayola-victorian-jhaalar-polki-set-or-antique-gold-collection-attrangi-1_540x.jpg?v=1705734581 540w, //attrangi.in/cdn/shop/files/fayola-victorian-jhaalar-polki-set-or-antique-gold-collection-attrangi-1_720x.jpg?v=1705734581 720w, //attrangi.in/cdn/shop/files/fayola-victorian-jhaalar-polki-set-or-antique-gold-collection-attrangi-1_900x.jpg?v=1705734581 900w, //attrangi.in/cdn/shop/files/fayola-victorian-jhaalar-polki-set-or-antique-gold-collection-attrangi-1_1080x.jpg?v=1705734581 1080w">
    </div><div class="grid-product__secondary-image small--hide"><img loading="lazy" class="lazyautosizes lazyloaded" data-widths="[360, 540, 720, 1000]" data-aspectratio="0.66625" data-sizes="auto" alt="Fayola Victorian Jhaalar Polki Set | Antique Gold Collection - Attrangi" data-srcset="//attrangi.in/cdn/shop/files/fayola-victorian-jhaalar-polki-set-or-antique-gold-collection-attrangi-2_360x.jpg?v=1705734582 360w, //attrangi.in/cdn/shop/files/fayola-victorian-jhaalar-polki-set-or-antique-gold-collection-attrangi-2_540x.jpg?v=1705734582 540w, //attrangi.in/cdn/shop/files/fayola-victorian-jhaalar-polki-set-or-antique-gold-collection-attrangi-2_720x.jpg?v=1705734582 720w, //attrangi.in/cdn/shop/files/fayola-victorian-jhaalar-polki-set-or-antique-gold-collection-attrangi-2_1000x.jpg?v=1705734582 1000w" sizes="324px" srcset="//attrangi.in/cdn/shop/files/fayola-victorian-jhaalar-polki-set-or-antique-gold-collection-attrangi-2_360x.jpg?v=1705734582 360w, //attrangi.in/cdn/shop/files/fayola-victorian-jhaalar-polki-set-or-antique-gold-collection-attrangi-2_540x.jpg?v=1705734582 540w, //attrangi.in/cdn/shop/files/fayola-victorian-jhaalar-polki-set-or-antique-gold-collection-attrangi-2_720x.jpg?v=1705734582 720w, //attrangi.in/cdn/shop/files/fayola-victorian-jhaalar-polki-set-or-antique-gold-collection-attrangi-2_1000x.jpg?v=1705734582 1000w">
    </div>
<div class="grid-product__color-image grid-product__color-image--43811653484756 small--hide">
              </div>
<div class="grid-product__color-image grid-product__color-image--43811653517524 small--hide">
              </div>
<div class="grid-product__color-image grid-product__color-image--43855869214932 small--hide">
              </div></div>

<div class="grid-product__meta">
  <div class="grid-product__title grid-product__title--body">Fayola Victorian Jhaalar Polki Set | Antique Gold Collection</div><div class="grid-product__price"><span class="visually-hidden">Regular price</span>
      <span class="grid-product__price--original">Rs. 9,650</span>
      <span class="visually-hidden">Sale price</span>Rs. 8,600
<span class="grid-product__price--savings">
          Save Rs. 1,050
        </span></div></div>
</a>
</div><div class="grid-product__colors grid-product__colors--7925973254356">
<a href="sale-1/products/fayola-victorian-jhaalar-polki-set-antique-gold-collection84da.html?variant=43811653484756" class="color-swatch color-swatch--small color-swatch--purple color-swatch--with-image" data-variant-id="43811653484756" data-variant-image="//attrangi.in/cdn/shop/files/fayola-victorian-jhaalar-polki-set-or-antique-gold-collection-attrangi-1_400x.jpg?v=1705734581" style="background-image: url(../cdn/shop/t/40/assets/purple_50x.html); background-color: purple;">
          <span class="visually-hidden">Purple</span>
        </a>
<a href="sale-1/products/fayola-victorian-jhaalar-polki-set-antique-gold-collection7ef9.html?variant=43811653517524" class="color-swatch color-swatch--small color-swatch--pink color-swatch--with-image" data-variant-id="43811653517524" data-variant-image="//attrangi.in/cdn/shop/files/fayola-victorian-jhaalar-polki-set-or-antique-gold-collection-attrangi-3_400x.jpg?v=1705734584" style="background-image: url(../cdn/shop/t/40/assets/pink_50x.html); background-color: pink;">
          <span class="visually-hidden">Pink</span>
        </a>
<a href="sale-1/products/fayola-victorian-jhaalar-polki-set-antique-gold-collection4792.html?variant=43855869214932" class="color-swatch color-swatch--small color-swatch--green color-swatch--with-image" data-variant-id="43855869214932" data-variant-image="//attrangi.in/cdn/shop/files/fayola-victorian-jhaalar-polki-set-or-antique-gold-collection-attrangi-4_400x.jpg?v=1705734585" style="background-image: url(../cdn/shop/t/40/assets/green_50x.html); background-color: green;">
          <span class="visually-hidden">Green</span>
        </a></div></div>
<div class="grid__item grid-product small--one-half medium-up--one-third grid-product__has-quick-shop aos-init aos-animate" data-aos="row-of-3" data-product-handle="pear-shaped-flexible-bracelet" data-product-id="7733591769300">
<div class="grid-product__content"><div class="grid-product__tag grid-product__tag--sale">
    Sale
  </div><a href="sale-1/products/pear-shaped-flexible-bracelet.html" class="grid-product__link">
<div class="grid-product__image-mask"><div class="quick-product__btn quick-product__btn--not-ready js-modal-open-quick-modal-7733591769300 small--hide">
      <span class="quick-product__label">Quick view</span>
    </div><div class="grid__image-ratio grid__image-ratio--portrait">
      <img loading="lazy" class="lazyautosizes lazyloaded" data-widths="[360, 540, 720, 900, 1080]" data-aspectratio="0.75" data-sizes="auto" alt="Pear Shaped Flexible Bracelet - Attrangi" data-srcset="//attrangi.in/cdn/shop/files/pear-shaped-flexible-bracelet-attrangi-1_360x.jpg?v=1705733989 360w, //attrangi.in/cdn/shop/files/pear-shaped-flexible-bracelet-attrangi-1_540x.jpg?v=1705733989 540w, //attrangi.in/cdn/shop/files/pear-shaped-flexible-bracelet-attrangi-1_720x.jpg?v=1705733989 720w, //attrangi.in/cdn/shop/files/pear-shaped-flexible-bracelet-attrangi-1_900x.jpg?v=1705733989 900w, //attrangi.in/cdn/shop/files/pear-shaped-flexible-bracelet-attrangi-1_1080x.jpg?v=1705733989 1080w" sizes="322px" srcset="//attrangi.in/cdn/shop/files/pear-shaped-flexible-bracelet-attrangi-1_360x.jpg?v=1705733989 360w, //attrangi.in/cdn/shop/files/pear-shaped-flexible-bracelet-attrangi-1_540x.jpg?v=1705733989 540w, //attrangi.in/cdn/shop/files/pear-shaped-flexible-bracelet-attrangi-1_720x.jpg?v=1705733989 720w, //attrangi.in/cdn/shop/files/pear-shaped-flexible-bracelet-attrangi-1_900x.jpg?v=1705733989 900w, //attrangi.in/cdn/shop/files/pear-shaped-flexible-bracelet-attrangi-1_1080x.jpg?v=1705733989 1080w">
    </div><div class="grid-product__secondary-image small--hide"><img loading="lazy" class="lazyautosizes lazyloaded" data-widths="[360, 540, 720, 1000]" data-aspectratio="0.75" data-sizes="auto" alt="Pear Shaped Flexible Bracelet - Attrangi" data-srcset="//attrangi.in/cdn/shop/files/pear-shaped-flexible-bracelet-attrangi-2_360x.jpg?v=1705733990 360w, //attrangi.in/cdn/shop/files/pear-shaped-flexible-bracelet-attrangi-2_540x.jpg?v=1705733990 540w, //attrangi.in/cdn/shop/files/pear-shaped-flexible-bracelet-attrangi-2_720x.jpg?v=1705733990 720w, //attrangi.in/cdn/shop/files/pear-shaped-flexible-bracelet-attrangi-2_1000x.jpg?v=1705733990 1000w" sizes="324px" srcset="//attrangi.in/cdn/shop/files/pear-shaped-flexible-bracelet-attrangi-2_360x.jpg?v=1705733990 360w, //attrangi.in/cdn/shop/files/pear-shaped-flexible-bracelet-attrangi-2_540x.jpg?v=1705733990 540w, //attrangi.in/cdn/shop/files/pear-shaped-flexible-bracelet-attrangi-2_720x.jpg?v=1705733990 720w, //attrangi.in/cdn/shop/files/pear-shaped-flexible-bracelet-attrangi-2_1000x.jpg?v=1705733990 1000w">
    </div>
<div class="grid-product__color-image grid-product__color-image--43189212184788 small--hide">
              </div>
<div class="grid-product__color-image grid-product__color-image--43189212217556 small--hide">
              </div>
<div class="grid-product__color-image grid-product__color-image--43189212250324 small--hide">
              </div></div>

<div class="grid-product__meta">
  <div class="grid-product__title grid-product__title--body">Pear Shaped Flexible Bracelet</div><div class="grid-product__price"><span class="visually-hidden">Regular price</span>
      <span class="grid-product__price--original">Rs. 1,850</span>
      <span class="visually-hidden">Sale price</span>Rs. 1,550
<span class="grid-product__price--savings">
          Save Rs. 300
        </span></div></div>
</a>
</div><div class="grid-product__colors grid-product__colors--7733591769300">
<a href="sale-1/products/pear-shaped-flexible-bracelet965a.html?variant=43189212184788" class="color-swatch color-swatch--small color-swatch--silver color-swatch--with-image" data-variant-id="43189212184788" data-variant-image="//attrangi.in/cdn/shop/files/pear-shaped-flexible-bracelet-attrangi-1_400x.jpg?v=1705733989" style="background-image: url(../cdn/shop/t/40/assets/silver_50x.html); background-color: silver;">
          <span class="visually-hidden">Silver</span>
        </a>
<a href="sale-1/products/pear-shaped-flexible-bracelet677e.html?variant=43189212217556" class="color-swatch color-swatch--small color-swatch--gold color-swatch--with-image" data-variant-id="43189212217556" data-variant-image="//attrangi.in/cdn/shop/files/pear-shaped-flexible-bracelet-attrangi-3_400x.jpg?v=1705733992" style="background-image: url(../cdn/shop/t/40/assets/gold_50x.html); background-color: gold;">
          <span class="visually-hidden">Gold</span>
        </a>
<a href="sale-1/products/pear-shaped-flexible-bracelet0989.html?variant=43189212250324" class="color-swatch color-swatch--small color-swatch--rose-gold color-swatch--with-image" data-variant-id="43189212250324" data-variant-image="//attrangi.in/cdn/shop/files/pear-shaped-flexible-bracelet-attrangi-2_400x.jpg?v=1705733990" style="background-image: url(../cdn/shop/t/40/assets/rose-gold_50x.png); background-color: gold;">
          <span class="visually-hidden">Rose Gold</span>
        </a></div></div>
</div><div class="pagination">





  <span class="page current">1</span>




<span class="page">
  <a href="sale-14658.html?page=2">2</a>
</span>



<span class="page">
  <a href="sale-19ba9.html?page=3">3</a>
</span>




  <span class="page">…</span>




<span class="page">
  <a href="sale-1a7f1.html?page=14">14</a>
</span>




<span class="next">
<a href="sale-14658.html?page=2" title="Next">
  <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-chevron-right" viewBox="0 0 284.49 498.98"><path d="M35 498.98a35 35 0 0 1-24.75-59.75l189.74-189.74L10.25 59.75a35.002 35.002 0 0 1 49.5-49.5l214.49 214.49a35 35 0 0 1 0 49.5L59.75 488.73A34.89 34.89 0 0 1 35 498.98z"></path></svg>
  <span class="icon__fallback-text">Next</span>
</a>
</span>

</div>
<div id="QuickShopModal-8377954664660" class="modal modal--square modal--quick-shop" data-product-id="8377954664660">
<div class="modal__inner">
<div class="modal__centered">
<div class="modal__centered-content">
  <div id="QuickShopHolder-yellow-pear-shaped-stud">null</div>
</div>

<button type="button" class="modal__close js-modal-close text-link">
  <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close" viewBox="0 0 64 64"><path d="M19 17.61l27.12 27.13m0-27.12L19 44.74"></path></svg>
  <span class="icon__fallback-text">"Close (esc)"</span>
</button>
</div>
</div>
</div>
<div id="QuickShopModal-8374448029908" class="modal modal--square modal--quick-shop" data-product-id="8374448029908">
<div class="modal__inner">
<div class="modal__centered">
<div class="modal__centered-content">
  <div id="QuickShopHolder-daphne-diamond-necklace-with-pastel-beads-lala-land-collection">null</div>
</div>

<button type="button" class="modal__close js-modal-close text-link">
  <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close" viewBox="0 0 64 64"><path d="M19 17.61l27.12 27.13m0-27.12L19 44.74"></path></svg>
  <span class="icon__fallback-text">"Close (esc)"</span>
</button>
</div>
</div>
</div>
<div id="QuickShopModal-8369248010452" class="modal modal--square modal--quick-shop" data-product-id="8369248010452">
<div class="modal__inner">
<div class="modal__centered">
<div class="modal__centered-content">
  <div id="QuickShopHolder-small-hallie-crisscross-triangular-shaped-party-wear-earrings">null</div>
</div>

<button type="button" class="modal__close js-modal-close text-link">
  <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close" viewBox="0 0 64 64"><path d="M19 17.61l27.12 27.13m0-27.12L19 44.74"></path></svg>
  <span class="icon__fallback-text">"Close (esc)"</span>
</button>
</div>
</div>
</div>
<div id="QuickShopModal-8365799178452" class="modal modal--square modal--quick-shop" data-product-id="8365799178452">
<div class="modal__inner">
<div class="modal__centered">
<div class="modal__centered-content">
  <div id="QuickShopHolder-90-cents-solitaire-pendant-in-pear-shaped"></div>
</div>

<button type="button" class="modal__close js-modal-close text-link">
  <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close" viewBox="0 0 64 64"><path d="M19 17.61l27.12 27.13m0-27.12L19 44.74"></path></svg>
  <span class="icon__fallback-text">"Close (esc)"</span>
</button>
</div>
</div>
</div>
<div id="QuickShopModal-8344400756948" class="modal modal--square modal--quick-shop" data-product-id="8344400756948">
<div class="modal__inner">
<div class="modal__centered">
<div class="modal__centered-content">
  <div id="QuickShopHolder-grisha-polki-choker-set-with-firoza-drops"></div>
</div>

<button type="button" class="modal__close js-modal-close text-link">
  <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close" viewBox="0 0 64 64"><path d="M19 17.61l27.12 27.13m0-27.12L19 44.74"></path></svg>
  <span class="icon__fallback-text">"Close (esc)"</span>
</button>
</div>
</div>
</div>
<div id="QuickShopModal-8344233115860" class="modal modal--square modal--quick-shop" data-product-id="8344233115860">
<div class="modal__inner">
<div class="modal__centered">
<div class="modal__centered-content">
  <div id="QuickShopHolder-blue-dangler-in-rose-gold"></div>
</div>

<button type="button" class="modal__close js-modal-close text-link">
  <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close" viewBox="0 0 64 64"><path d="M19 17.61l27.12 27.13m0-27.12L19 44.74"></path></svg>
  <span class="icon__fallback-text">"Close (esc)"</span>
</button>
</div>
</div>
</div>
<div id="QuickShopModal-8344229347540" class="modal modal--square modal--quick-shop" data-product-id="8344229347540">
<div class="modal__inner">
<div class="modal__centered">
<div class="modal__centered-content">
  <div id="QuickShopHolder-emerald-dangler"></div>
</div>

<button type="button" class="modal__close js-modal-close text-link">
  <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close" viewBox="0 0 64 64"><path d="M19 17.61l27.12 27.13m0-27.12L19 44.74"></path></svg>
  <span class="icon__fallback-text">"Close (esc)"</span>
</button>
</div>
</div>
</div>
<div id="QuickShopModal-8344156930260" class="modal modal--square modal--quick-shop" data-product-id="8344156930260">
<div class="modal__inner">
<div class="modal__centered">
<div class="modal__centered-content">
  <div id="QuickShopHolder-reeta-polki-indian-choker-with-pearls"></div>
</div>

<button type="button" class="modal__close js-modal-close text-link">
  <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close" viewBox="0 0 64 64"><path d="M19 17.61l27.12 27.13m0-27.12L19 44.74"></path></svg>
  <span class="icon__fallback-text">"Close (esc)"</span>
</button>
</div>
</div>
</div>
<div id="QuickShopModal-8344151785684" class="modal modal--square modal--quick-shop" data-product-id="8344151785684">
<div class="modal__inner">
<div class="modal__centered">
<div class="modal__centered-content">
  <div id="QuickShopHolder-ruby-delight-diamond-set"></div>
</div>

<button type="button" class="modal__close js-modal-close text-link">
  <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close" viewBox="0 0 64 64"><path d="M19 17.61l27.12 27.13m0-27.12L19 44.74"></path></svg>
  <span class="icon__fallback-text">"Close (esc)"</span>
</button>
</div>
</div>
</div>
<div id="QuickShopModal-8333205569748" class="modal modal--square modal--quick-shop" data-product-id="8333205569748">
<div class="modal__inner">
<div class="modal__centered">
<div class="modal__centered-content">
  <div id="QuickShopHolder-mid-sized-emerald-earrings"></div>
</div>

<button type="button" class="modal__close js-modal-close text-link">
  <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close" viewBox="0 0 64 64"><path d="M19 17.61l27.12 27.13m0-27.12L19 44.74"></path></svg>
  <span class="icon__fallback-text">"Close (esc)"</span>
</button>
</div>
</div>
</div>
<div id="QuickShopModal-8332739838164" class="modal modal--square modal--quick-shop" data-product-id="8332739838164">
<div class="modal__inner">
<div class="modal__centered">
<div class="modal__centered-content">
  <div id="QuickShopHolder-pearl-hanging-drop"></div>
</div>

<button type="button" class="modal__close js-modal-close text-link">
  <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close" viewBox="0 0 64 64"><path d="M19 17.61l27.12 27.13m0-27.12L19 44.74"></path></svg>
  <span class="icon__fallback-text">"Close (esc)"</span>
</button>
</div>
</div>
</div>
<div id="QuickShopModal-8332622528724" class="modal modal--square modal--quick-shop" data-product-id="8332622528724">
<div class="modal__inner">
<div class="modal__centered">
<div class="modal__centered-content">
  <div id="QuickShopHolder-ruby-delight-choker-set"></div>
</div>

<button type="button" class="modal__close js-modal-close text-link">
  <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close" viewBox="0 0 64 64"><path d="M19 17.61l27.12 27.13m0-27.12L19 44.74"></path></svg>
  <span class="icon__fallback-text">"Close (esc)"</span>
</button>
</div>
</div>
</div>
<div id="QuickShopModal-8314686079188" class="modal modal--square modal--quick-shop" data-product-id="8314686079188">
<div class="modal__inner">
<div class="modal__centered">
<div class="modal__centered-content">
  <div id="QuickShopHolder-1-carat-double-line-engagement-ring"></div>
</div>

<button type="button" class="modal__close js-modal-close text-link">
  <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close" viewBox="0 0 64 64"><path d="M19 17.61l27.12 27.13m0-27.12L19 44.74"></path></svg>
  <span class="icon__fallback-text">"Close (esc)"</span>
</button>
</div>
</div>
</div>
<div id="QuickShopModal-8313255428308" class="modal modal--square modal--quick-shop" data-product-id="8313255428308">
<div class="modal__inner">
<div class="modal__centered">
<div class="modal__centered-content">
  <div id="QuickShopHolder-pear-pendant-with-halo"></div>
</div>

<button type="button" class="modal__close js-modal-close text-link">
  <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close" viewBox="0 0 64 64"><path d="M19 17.61l27.12 27.13m0-27.12L19 44.74"></path></svg>
  <span class="icon__fallback-text">"Close (esc)"</span>
</button>
</div>
</div>
</div>
<div id="QuickShopModal-8307025871060" class="modal modal--square modal--quick-shop" data-product-id="8307025871060">
<div class="modal__inner">
<div class="modal__centered">
<div class="modal__centered-content">
  <div id="QuickShopHolder-bobby-long-diamond-statement-earrings"></div>
</div>

<button type="button" class="modal__close js-modal-close text-link">
  <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close" viewBox="0 0 64 64"><path d="M19 17.61l27.12 27.13m0-27.12L19 44.74"></path></svg>
  <span class="icon__fallback-text">"Close (esc)"</span>
</button>
</div>
</div>
</div>
<div id="QuickShopModal-8234415227092" class="modal modal--square modal--quick-shop" data-product-id="8234415227092">
<div class="modal__inner">
<div class="modal__centered">
<div class="modal__centered-content">
  <div id="QuickShopHolder-fallon-honeybee-hive-party-wear-long-earrings">null</div>
</div>

<button type="button" class="modal__close js-modal-close text-link">
  <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close" viewBox="0 0 64 64"><path d="M19 17.61l27.12 27.13m0-27.12L19 44.74"></path></svg>
  <span class="icon__fallback-text">"Close (esc)"</span>
</button>
</div>
</div>
</div>
<div id="QuickShopModal-8229715837140" class="modal modal--square modal--quick-shop" data-product-id="8229715837140">
<div class="modal__inner">
<div class="modal__centered">
<div class="modal__centered-content">
  <div id="QuickShopHolder-oh-lara-diamond-earrings-long-coloured-stone-earrings"></div>
</div>

<button type="button" class="modal__close js-modal-close text-link">
  <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close" viewBox="0 0 64 64"><path d="M19 17.61l27.12 27.13m0-27.12L19 44.74"></path></svg>
  <span class="icon__fallback-text">"Close (esc)"</span>
</button>
</div>
</div>
</div>
<div id="QuickShopModal-8168531034324" class="modal modal--square modal--quick-shop" data-product-id="8168531034324">
<div class="modal__inner">
<div class="modal__centered">
<div class="modal__centered-content">
  <div id="QuickShopHolder-chaitali-necklace-with-mid-sized-jhumkis-sone-pe-suhaga-collection"></div>
</div>

<button type="button" class="modal__close js-modal-close text-link">
  <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close" viewBox="0 0 64 64"><path d="M19 17.61l27.12 27.13m0-27.12L19 44.74"></path></svg>
  <span class="icon__fallback-text">"Close (esc)"</span>
</button>
</div>
</div>
</div>
<div id="QuickShopModal-8168525529300" class="modal modal--square modal--quick-shop" data-product-id="8168525529300">
<div class="modal__inner">
<div class="modal__centered">
<div class="modal__centered-content">
  <div id="QuickShopHolder-kusum-long-necklace-sone-pe-suhaga-collection"></div>
</div>

<button type="button" class="modal__close js-modal-close text-link">
  <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close" viewBox="0 0 64 64"><path d="M19 17.61l27.12 27.13m0-27.12L19 44.74"></path></svg>
  <span class="icon__fallback-text">"Close (esc)"</span>
</button>
</div>
</div>
</div>
<div id="QuickShopModal-8156505637076" class="modal modal--square modal--quick-shop" data-product-id="8156505637076">
<div class="modal__inner">
<div class="modal__centered">
<div class="modal__centered-content">
  <div id="QuickShopHolder-rasrava-gold-double-layered-jhumka-sone-pe-suhaga-collection"></div>
</div>

<button type="button" class="modal__close js-modal-close text-link">
  <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close" viewBox="0 0 64 64"><path d="M19 17.61l27.12 27.13m0-27.12L19 44.74"></path></svg>
  <span class="icon__fallback-text">"Close (esc)"</span>
</button>
</div>
</div>
</div>
<div id="QuickShopModal-7081022455977" class="modal modal--square modal--quick-shop" data-product-id="7081022455977">
<div class="modal__inner">
<div class="modal__centered">
<div class="modal__centered-content">
  <div id="QuickShopHolder-elevated-diamond-ring"></div>
</div>

<button type="button" class="modal__close js-modal-close text-link">
  <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close" viewBox="0 0 64 64"><path d="M19 17.61l27.12 27.13m0-27.12L19 44.74"></path></svg>
  <span class="icon__fallback-text">"Close (esc)"</span>
</button>
</div>
</div>
</div>
<div id="QuickShopModal-8067801710804" class="modal modal--square modal--quick-shop" data-product-id="8067801710804">
<div class="modal__inner">
<div class="modal__centered">
<div class="modal__centered-content">
  <div id="QuickShopHolder-nia-grey-pearl-drop-diamond-earrings"></div>
</div>

<button type="button" class="modal__close js-modal-close text-link">
  <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close" viewBox="0 0 64 64"><path d="M19 17.61l27.12 27.13m0-27.12L19 44.74"></path></svg>
  <span class="icon__fallback-text">"Close (esc)"</span>
</button>
</div>
</div>
</div>
<div id="QuickShopModal-7925973254356" class="modal modal--square modal--quick-shop" data-product-id="7925973254356">
<div class="modal__inner">
<div class="modal__centered">
<div class="modal__centered-content">
  <div id="QuickShopHolder-fayola-victorian-jhaalar-polki-set-antique-gold-collection"></div>
</div>

<button type="button" class="modal__close js-modal-close text-link">
  <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close" viewBox="0 0 64 64"><path d="M19 17.61l27.12 27.13m0-27.12L19 44.74"></path></svg>
  <span class="icon__fallback-text">"Close (esc)"</span>
</button>
</div>
</div>
</div>
<div id="QuickShopModal-7733591769300" class="modal modal--square modal--quick-shop" data-product-id="7733591769300">
<div class="modal__inner">
<div class="modal__centered">
<div class="modal__centered-content">
  <div id="QuickShopHolder-pear-shaped-flexible-bracelet"></div>
</div>

<button type="button" class="modal__close js-modal-close text-link">
  <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close" viewBox="0 0 64 64"><path d="M19 17.61l27.12 27.13m0-27.12L19 44.74"></path></svg>
  <span class="icon__fallback-text">"Close (esc)"</span>
</button>
</div>
</div>
</div>
</div>
</div>
    </div>
  </div>
</div>
</div>
</div>
</div>

<script type="application/ld+json">
{
"@context": "http://schema.org",
"@type": "CollectionPage",



"image": {
"@type": "ImageObject",
"height": 628,
"url": "https:\/\/attrangi.in\/cdn\/shop\/files\/att_logo_new_1200x.png?v=1621072841",
"width": 1200
},

"name": "Exclusive Sale"
}
</script>

  </main>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ShopKart24\resources\views/frontend/jewelry.blade.php ENDPATH**/ ?>
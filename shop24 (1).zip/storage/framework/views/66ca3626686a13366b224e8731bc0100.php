

<?php $__env->startSection('main-container'); ?>

<style> .card-text {
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
            text-overflow: ellipsis;
            height: 4.5em; /* (line-height) * (number of lines you want to show) */
        }
        
        .image-container {
            position: relative;
        }
        .add-to-cart-btn {
            position: absolute;
            bottom: 10px;
            left: 50%;
            transform: translateX(-50%);
            display: none;
        }
        .image-container:hover .add-to-cart-btn {
                display: block;
                background: black;
                color: white;
                padding-right: 20px;
                padding-left: 46px;
                padding-top: 9px;
                padding-bottom: 9px;
                border-radius: 11px;
                width: 200px;
                }
        .image-container img {
            display: block;
            width: 100%;
            height: auto;
        }
       </style>
  
    </div>
    <main class="main-content" id="MainContent">

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
        <!-- BEGIN content_for_index -->
        <div id="shopify-section-1524769873765" class="shopify-section index-section--hero">
            <div data-section-id="1524769873765" data-section-type="slideshow-section">
              <div class="slideshow-wrapper">
                <div class="">
                  <div id="Slideshow-1524769873765" class="hero hero--450px hero--1524769873765 hero--mobile--250px"
                    data-mobile-natural="false" data-autoplay="true" data-speed="6000" data-arrows="true"
                    data-slide-count="3">
                    <div class="slideshow__slide slideshow__slide--image_zUzy6c" data-index="0" data-id="image_zUzy6c">
                      <style data-shopify>
                        .slideshow__slide--image_zUzy6c .hero__title {
                          font-size: 36.0px;
                        }
  
                        @media only screen and (min-width: 769px) {
                          .slideshow__slide--image_zUzy6c .hero__title {
                            font-size: 72px;
                          }
                        }
  
                        .slideshow__slide--image_zUzy6c .btn {
                          background: #f9dbe3 !important;
                          border: none;
                          color: #000 !important;
  
                        }
                      </style>
                      <div class="hero__image-wrapper"><img loading="eager"
                          class="hero__image hero__image--image_zUzy6c lazyloaded   small--hide"
                          src="cdn/shop/files/80_9_1349x724a.png?v=1710494063" alt=""
                          style="object-position: center center"><img loading="eager"
                          class="hero__image hero__image--image_zUzy6c lazyloaded  medium-up--hide"
                          src="cdn/shop/files/80_1080_x_600_px_10_1349x724a.png?v=1710494063"
                          data-src="cdn/shop/files/80_1080_x_600_px_10_%7bwidth%7dx724a.html?v=1710494063"
                          data-aspectratio="1.542857142857143" data-sizes="auto" alt=""
                          style="object-position: center center"><noscript>
                          <img loading="eager" class="hero__image hero__image--image_zUzy6c"
                            src="cdn/shop/files/80_9_1400x724a.png?v=1710494063" alt="">
                        </noscript></div><a href="collections/sone-pe-suhaga-collection.html" class="hero__slide-link"
                        aria-hidden="true"></a>
                      <div class="hero__text-wrap">
                        <div class="page-width">
                          <div class="hero__text-content vertical-bottom horizontal-right">
                            <div class="hero__text-shadow">
                              <div class="hero__subtitle">
                                <div class="animation-cropper">
                                  <div class="animation-contents">
                                    Sone Pe Suhaga Collection
                                  </div>
                                </div>
                              </div>
                              <div class="hero__link"><a href="collections/sone-pe-suhaga-collection.html" class="btn">
                                  Explore
                                </a></div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="slideshow__slide slideshow__slide--1524769873765-1" data-index="1"
                      data-id="1524769873765-1">
                      <style data-shopify>
                        .slideshow__slide--1524769873765-1 .hero__title {
                          font-size: 49.0px;
                        }
  
                        @media only screen and (min-width: 769px) {
                          .slideshow__slide--1524769873765-1 .hero__title {
                            font-size: 98px;
                          }
                        }
  
                        .slideshow__slide--1524769873765-1 .btn {
                          background: #f9dbe3 !important;
                          border: none;
                          color: #000 !important;
  
                        }
                      </style>
                      <div class="hero__image-wrapper"><img loading="lazy"
                          class="hero__image hero__image--1524769873765-1 lazyloaded   small--hide"
                          src="cdn/shop/files/3d54e71b-3461-47f2-8c35-02b2d02a3499_1349x70fe.jpg?v=1709898873" alt=""
                          style="object-position: 80% 0"><img loading="lazy"
                          class="hero__image hero__image--1524769873765-1 lazyloaded  medium-up--hide"
                          src="cdn/shop/files/3d54e71b-3461-47f2-8c35-02b2d02a3499_1349x70fe.jpg?v=1709898873"
                          data-src="cdn/shop/files/3d54e71b-3461-47f2-8c35-02b2d02a3499_%7bwidth%7dx70fe.html?v=1709898873"
                          data-aspectratio="2.380952380952381" data-sizes="auto" alt=""
                          style="object-position: 80% 0"><noscript>
                          <img loading="lazy" class="hero__image hero__image--1524769873765-1"
                            src="cdn/shop/files/3d54e71b-3461-47f2-8c35-02b2d02a3499_1400x70fe.jpg?v=1709898873" alt="">
                        </noscript></div>
                      <div class="hero__text-wrap">
                        <div class="page-width">
                          <div class="hero__text-content vertical-bottom horizontal-right">
                            <div class="hero__text-shadow">
                              <div class="hero__subtitle">
                                <div class="animation-cropper">
                                  <div class="animation-contents">
                                    Elegant, Timeless, Regal
                                  </div>
                                </div>
                              </div>
                              <div class="hero__link"><a href="collections/rajwada-1.html" class="btn">
                                  Explore
                                </a></div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="slideshow__slide slideshow__slide--056fac08-6c02-4e3a-9c77-8279878c2e8c" data-index="2"
                      data-id="056fac08-6c02-4e3a-9c77-8279878c2e8c">
                      <style data-shopify>
                        .slideshow__slide--056fac08-6c02-4e3a-9c77-8279878c2e8c .hero__title {
                          font-size: 36.0px;
                        }
  
                        @media only screen and (min-width: 769px) {
                          .slideshow__slide--056fac08-6c02-4e3a-9c77-8279878c2e8c .hero__title {
                            font-size: 72px;
                          }
                        }
  
                        .slideshow__slide--056fac08-6c02-4e3a-9c77-8279878c2e8c .btn {
                          background: #f9dbe3 !important;
                          border: none;
                          color: #000 !important;
  
                        }
                      </style>
                      <div class="hero__image-wrapper"><img loading="lazy"
                          class="hero__image hero__image--056fac08-6c02-4e3a-9c77-8279878c2e8c lazyloaded   small--hide"
                          src="cdn/shop/files/DSC05096_1349x0725.jpg?v=1699427899" alt=""
                          style="object-position: center center"><img loading="lazy"
                          class="hero__image hero__image--056fac08-6c02-4e3a-9c77-8279878c2e8c lazyloaded  medium-up--hide"
                          src="cdn/shop/files/DSC05096_1349x0725.jpg?v=1699427899"
                          data-src="cdn/shop/files/DSC05096_%7bwidth%7dx0725.html?v=1699427899"
                          data-aspectratio="1.4684287812041117" data-sizes="auto" alt=""
                          style="object-position: center center"><noscript>
                          <img loading="lazy" class="hero__image hero__image--056fac08-6c02-4e3a-9c77-8279878c2e8c"
                            src="cdn/shop/files/DSC05096_1400x0725.jpg?v=1699427899" alt="">
                        </noscript></div><a href="collections/almaaz-1.html" class="hero__slide-link"
                        aria-hidden="true"></a>
                      <div class="hero__text-wrap">
                        <div class="page-width">
                          <div class="hero__text-content vertical-bottom horizontal-right">
                            <div class="hero__text-shadow">
                              <div class="hero__subtitle">
                                <div class="animation-cropper">
                                  <div class="animation-contents">
                                    Diamond Galore
                                  </div>
                                </div>
                              </div>
                              <div class="hero__link"><a href="collections/almaaz-1.html" class="btn">
                                  Explore
                                </a></div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
  
  
          </div>
        <div id="shopify-section-1620111193906b860b" class="shopify-section index-section">
            <div id="shopify-section-1620111193906b860b" class="shopify-section index-section">
                <div class="page-width">
                  <div class="section-header">
                    <h2 class="section-header__title">Explore Our Range Of Jewellery</h2>
                  </div>
                  <div class="grid grid--uniform">
                    <div class="grid__item small--one-half medium-up--one-third">
                      <a href="<?php echo e(route('category.show', 9)); ?>" class="collection-item collection-item--below"
                        data-aos="row-of-3">
<div class="collection-image collection-image--square image-wrap"><img loading="lazy" class="lazyload"
                            src="/assets/dashboard/img/bangles.jfif"
                            data-src="cdn/shop/files/WhatsAppImage2024-05-15at7.09.52PM_1_%7bwidth%7dxc258.html?v=1715863076"
                            data-aspectratio="0.75" data-widths="[360, 540, 720, 900, 1080]" data-sizes="auto" alt=""
                            style="object-position: center center;">
                        </div>
                        <span
                          class="collection-item__title collection-item__title--below collection-item__title--heading collection-item__title--bottom-center">
                          <span>
                            Bracelet / Bangles
                          </span>
                        </span>
      
                      </a>
                    </div>
                    <div class="grid__item small--one-half medium-up--one-third">
                      <a href="<?php echo e(route('category.show', 2)); ?>" class="collection-item collection-item--below"
                        data-aos="row-of-3">
                        <div class="collection-image collection-image--square image-wrap"><img loading="lazy" class="lazyload"
                            src="#"
                            data-src="cdn/shop/files/WhatsAppImage2024-05-17at11.54.39AM_%7bwidth%7dx2110.html?v=1715943262"
                            data-aspectratio="0.75" data-widths="[360, 540, 720, 900, 1080]" data-sizes="auto" alt=""
                            style="object-position: center center;">
                        </div><span
                          class="collection-item__title collection-item__title--below collection-item__title--heading collection-item__title--bottom-center">
                          <span>
                            Earrings
                          </span>
                        </span>
      
                      </a>
                    </div>
                    <div class="grid__item small--one-half medium-up--one-third">
                      <a href="<?php echo e(route('category.show', 8)); ?>" class="collection-item collection-item--below"
                        data-aos="row-of-3">
                        <div class="collection-image collection-image--square image-wrap"><img loading="lazy" class="lazyload"
                            src="#"
                            data-src="cdn/shop/files/WhatsAppImage2024-05-17at11.57.19AM_%7bwidth%7dx90d3.html?v=1715943374"
                            data-aspectratio="0.75" data-widths="[360, 540, 720, 900, 1080]" data-sizes="auto" alt=""
                            style="object-position: center center;">
                        </div><span
                          class="collection-item__title collection-item__title--below collection-item__title--heading collection-item__title--bottom-center">
                          <span>
                            Jewellery Sets
                          </span>
                        </span>
                      </a>
                    </div>
                </div>
            </div>
        </div>
        <div id="shopify-section-ea45e163-2e28-413e-99a6-cf8285108703" class="shopify-section">
            <div data-section-id="ea45e163-2e28-413e-99a6-cf8285108703" data-section-type="promo-grid">
               
                <div class="promo-grid">
                    <div class="flex-grid flex-grid--gutters flex-grid--ea45e163-2e28-413e-99a6-cf8285108703">
                       
                        <div
                            class="flex-grid__item flex-grid__item--100 flex-grid__item--ea45e163-2e28-413e-99a6-cf8285108703-advanced-1 type-advanced">
                            <div class="promo-grid__container vertical-bottom horizontal-center">
                                <a href="" class="promo-grid__slide-link" aria-hidden="true"
                                    aria-label="BESTSELLERS"></a>
                                <div class="promo-grid__bg">
                                    <img loading="lazy"
                                        class="image-fit promo-grid__bg-image promo-grid__bg-image--ea45e163-2e28-413e-99a6-cf8285108703-advanced-1 lazyload"
                                        src="cdn/shop/files/Untitled_design_2_300x6754.png?v=1699104026"
                                        data-src="//attrangi.in/cdn/shop/files/Untitled_design_2_{width}x.png?v=1699104026"
                                        data-aspectratio="2.7" data-sizes="auto" alt="">
                                    <noscript>
                                        <img loading="lazy"
                                            class="image-fit promo-grid__bg-image promo-grid__bg-image--ea45e163-2e28-413e-99a6-cf8285108703-advanced-1 lazyloaded"
                                            src="cdn/shop/files/Untitled_design_2_1800x6754.png?v=1699104026"
                                            alt="">
                                    </noscript>
                                </div>
                                <div class="promo-grid__content">
                                    <div class="promo-grid__text"><a href="" class="btn">
                                            BESTSELLERS
                                        </a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div>
        <div id="shopify-section-1525295772132" class="shopify-section index-section">
            <div id="CollectionSection-1525295772132" data-section-id="1525295772132"
                data-section-type="collection-template">
                <div class="page-width">
                    <div class="section-header">
                        <h2 class="section-header__title">
                            RECENTLY ADDED
                        </h2>
                    </div>
                </div>
            </div>
            
                <div class="row">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="col col-md-3 mt-3">
           <div class="card" style="height:428px;">
                     <div class="image-container">
                    <img src="<?php echo e(asset('image/' . $product->firstImage)); ?>" class="card-img-top img-fluid" alt="<?php echo e($product->productName); ?>" style="height:200px!important;">
                    <form action="<?php echo e(route('cart.add')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="product_id" value="<?php echo e($product->productId); ?>">
                        
                         <button type="submit"  <a href="#" class="add-to-cart-btn "><span class="fa fa-shopping-cart px-1"></span>Add To Cart</a></button>


                       
                    </form>
                </div>
                   <div class="card-body">
            <h5 class="card-title"><a href="<?php echo e(route('product.view', $product->productId)); ?>"><?php echo e($product->productName); ?></a></h5>
                        <p class="card-text"style="margin-bottom:2px; color:black!important;"><?php echo e($product->productDescription); ?></p>
                        <p class="card-text "style="margin-bottom:2px; height:38px; color:black!important;">₹<?php echo e($product->productPrice); ?></p>
                       <a href="<?php echo e(route('product.view', $product->productId)); ?>" class="btn btn-danger" style="background: #ec688d;border: 2px solid #ec688d; color: black;
                         width: 200px;">Shop Now</a>

                       <!--<div class="row">-->
                       <!--    <div class="col col-md-6"><a href="#" class="btn btn-primary">Cart</a></div>-->
                       <!--    <div class="col col-md-6"><box-icon name='cart' type='solid'  ></box-icon></div>-->
                       <!--</div>-->

                        
                         
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<div class="d-flex justify-content-center mt-4">
    <a href="<?php echo e(url('/jewelry')); ?>" class="btn " style="background:#ec688d; color:black;">View More</a>
</div>

            
            
            <div id="QuickShopModal-8394419699924" class="modal modal--square modal--quick-shop"
                data-product-id="8394419699924">
                <div class="modal__inner">
                    <div class="modal__centered">
                        <div class="modal__centered-content">
                            <div id="QuickShopHolder-nandita-single-line-moissanite-set-rose-gold-polish"></div>
                        </div>

                        <button type="button" class="modal__close js-modal-close text-link">
                            <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close"
                                viewBox="0 0 64 64">
                                <path d="M19 17.61l27.12 27.13m0-27.12L19 44.74" />
                            </svg>
                            <span class="icon__fallback-text">"Close (esc)"</span>
                        </button>
                    </div>
                </div>
            </div>
            <div id="QuickShopModal-8394414719188" class="modal modal--square modal--quick-shop"
                data-product-id="8394414719188">
                <div class="modal__inner">
                    <div class="modal__centered">
                        <div class="modal__centered-content">
                            <div id="QuickShopHolder-hatts-on-pearl-drop-diamond-studs"></div>
                        </div>

                        <button type="button" class="modal__close js-modal-close text-link">
                            <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close"
                                viewBox="0 0 64 64">
                                <path d="M19 17.61l27.12 27.13m0-27.12L19 44.74" />
                            </svg>
                            <span class="icon__fallback-text">"Close (esc)"</span>
                        </button>
                    </div>
                </div>
            </div>
            <div id="QuickShopModal-8393237725396" class="modal modal--square modal--quick-shop"
                data-product-id="8393237725396">
                <div class="modal__inner">
                    <div class="modal__centered">
                        <div class="modal__centered-content">
                            <div id="QuickShopHolder-devanna-polki-pearl-hathpan"></div>
                        </div>

                        <button type="button" class="modal__close js-modal-close text-link">
                            <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close"
                                viewBox="0 0 64 64">
                                <path d="M19 17.61l27.12 27.13m0-27.12L19 44.74" />
                            </svg>
                            <span class="icon__fallback-text">"Close (esc)"</span>
                        </button>
                    </div>
                </div>
            </div>
            <div id="QuickShopModal-8393213313236" class="modal modal--square modal--quick-shop"
                data-product-id="8393213313236">
                <div class="modal__inner">
                    <div class="modal__centered">
                        <div class="modal__centered-content">
                            <div id="QuickShopHolder-sadhana-indian-polki-kada-bangle-victorian"></div>
                        </div>

                        <button type="button" class="modal__close js-modal-close text-link">
                            <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close"
                                viewBox="0 0 64 64">
                                <path d="M19 17.61l27.12 27.13m0-27.12L19 44.74" />
                            </svg>
                            <span class="icon__fallback-text">"Close (esc)"</span>
                        </button>
                    </div>
                </div>
            </div>
            <div id="QuickShopModal-8393159737556" class="modal modal--square modal--quick-shop"
                data-product-id="8393159737556">
                <div class="modal__inner">
                    <div class="modal__centered">
                        <div class="modal__centered-content">
                            <div id="QuickShopHolder-manisha-long-indian-polki-set-with-earrings"></div>
                        </div>

                        <button type="button" class="modal__close js-modal-close text-link">
                            <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close"
                                viewBox="0 0 64 64">
                                <path d="M19 17.61l27.12 27.13m0-27.12L19 44.74" />
                            </svg>
                            <span class="icon__fallback-text">"Close (esc)"</span>
                        </button>
                    </div>
                </div>
            </div>
            <div id="QuickShopModal-8393102885076" class="modal modal--square modal--quick-shop"
                data-product-id="8393102885076">
                <div class="modal__inner">
                    <div class="modal__centered">
                        <div class="modal__centered-content">
                            <div id="QuickShopHolder-shubha-indian-polki-ring"></div>
                        </div>

                        <button type="button" class="modal__close js-modal-close text-link">
                            <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close"
                                viewBox="0 0 64 64">
                                <path d="M19 17.61l27.12 27.13m0-27.12L19 44.74" />
                            </svg>
                            <span class="icon__fallback-text">"Close (esc)"</span>
                        </button>
                    </div>
                </div>
            </div>
            <div id="QuickShopModal-8388339859668" class="modal modal--square modal--quick-shop"
                data-product-id="8388339859668">
                <div class="modal__inner">
                    <div class="modal__centered">
                        <div class="modal__centered-content">
                            <div id="QuickShopHolder-vasanti-moissanite-gajra-bracelet"></div>
                        </div>

                        <button type="button" class="modal__close js-modal-close text-link">
                            <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close"
                                viewBox="0 0 64 64">
                                <path d="M19 17.61l27.12 27.13m0-27.12L19 44.74" />
                            </svg>
                            <span class="icon__fallback-text">"Close (esc)"</span>
                        </button>
                    </div>
                </div>
            </div>
            <div id="QuickShopModal-8388338385108" class="modal modal--square modal--quick-shop"
                data-product-id="8388338385108">
                <div class="modal__inner">
                    <div class="modal__centered">
                        <div class="modal__centered-content">
                            <div id="QuickShopHolder-five-layer-long-emerald-beaded-long-mala"></div>
                        </div>

                        <button type="button" class="modal__close js-modal-close text-link">
                            <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-close"
                                viewBox="0 0 64 64">
                                <path d="M19 17.61l27.12 27.13m0-27.12L19 44.74" />
                            </svg>
                            <span class="icon__fallback-text">"Close (esc)"</span>
                        </button>
                    </div>
                </div>
            </div>

        
        </div>
        <div id="shopify-section-1525912530555" class="shopify-section">
            <div data-section-id="1525912530555" data-section-type="promo-grid">
                <div class="page-width">
                  
                    <div class="promo-grid">
                        <div class="flex-grid flex-grid--gutters flex-grid--1525912530555">
                            
                            <div
                                class="flex-grid__item flex-grid__item--50 flex-grid__item--cb71359c-a133-4843-ad4c-d8d5d4222763 type-advanced">
                                <div
                                    class="promo-grid__container promo-grid__container--framed vertical-bottom horizontal-center">
                                    <a href="collections/earrings-diamond-studs.html" class="promo-grid__slide-link"
                                        aria-hidden="true" aria-label="Diamond Studs"></a>
                                    <div class="promo-grid__bg">
                                        <img loading="lazy"
                                            class="image-fit promo-grid__bg-image promo-grid__bg-image--cb71359c-a133-4843-ad4c-d8d5d4222763 lazyload"
                                            src="cdn/shop/files/IMG_7196_300xfb41.jpg?v=1694967670"
                                            data-src="//attrangi.in/cdn/shop/files/IMG_7196_{width}x.jpg?v=1694967670"
                                            data-aspectratio="1.3685446009389672" data-sizes="auto" alt="">
                                        <noscript>
                                            <img loading="lazy"
                                                class="image-fit promo-grid__bg-image promo-grid__bg-image--cb71359c-a133-4843-ad4c-d8d5d4222763 lazyloaded"
                                                src="cdn/shop/files/IMG_7196_1800xfb41.jpg?v=1694967670" alt="">
                                        </noscript>
                                    </div>
                                    <div class="promo-grid__content promo-grid__content--framed">
                                        <div class="promo-grid__text"><a href="collections/earrings-diamond-studs.html"
                                                class="btn btn--inverse">
                                                Diamond Studs
                                            </a></div>
                                    </div>
                                </div>
                            </div>
                          
                            <div
                                class="flex-grid__item flex-grid__item--33 flex-grid__item--1525912530555-1 type-advanced">
                                <div
                                    class="promo-grid__container promo-grid__container--framed vertical-bottom horizontal-center">
                                    <a href="collections/earrings-indian-studs.html" class="promo-grid__slide-link"
                                        aria-hidden="true" aria-label="Indian Studs"></a>
                                    <div class="promo-grid__bg">
                                    <img loading="lazy"
                                            class="image-fit promo-grid__bg-image promo-grid__bg-image--1525912530555-1 lazyload"
                                            src="cdn/shop/files/IMG_5694_41701f1a-94eb-4a2f-8be0-48ca783e4ea1_300x6dab.jpg?v=1696919865"
                                            data-src="//attrangi.in/cdn/shop/files/IMG_5694_41701f1a-94eb-4a2f-8be0-48ca783e4ea1_{width}x.jpg?v=1696919865"
                                            data-aspectratio="0.8804597701149425" data-sizes="auto" alt="">
                                        <noscript>
                                            <img loading="lazy"
                                                class="image-fit promo-grid__bg-image promo-grid__bg-image--1525912530555-1 lazyloaded"
                                                src="cdn/shop/files/IMG_5694_41701f1a-94eb-4a2f-8be0-48ca783e4ea1_1800x6dab.jpg?v=1696919865"
                                                alt="">
                                        </noscript>
                                    </div>
                                    <div class="promo-grid__content promo-grid__content--framed">
                                        <div class="promo-grid__text"><a href="collections/earrings-indian-studs.html"
                                                class="btn btn--inverse">
                                                Indian Studs
                                            </a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div>
        <!--<div id="shopify-section-1499789718857" class="shopify-section index-section">-->
        <!--    <div class="page-width">-->
        <!--        <div class="section-header">-->
        <!--            <h2 class="section-header__title">Shop By Collection</h2>-->
        <!--        </div>-->
        <!--        <div class="grid grid--uniform">-->
        <!--            <div class="grid__item small--one-half medium-up--one-quarter">-->
        <!--                <a href="collections/almaaz-1.html" class="collection-item collection-item--below"-->
        <!--                    data-aos="row-of-4">-->
        <!--                    <div class="collection-image collection-image--square image-wrap"><img loading="lazy"-->
        <!--                            class="lazyload" src="#"-->
        <!--                            data-src="//attrangi.in/cdn/shop/files/WhatsAppImage2024-05-17at11.54.39AM_{width}x.jpg?v=1715943262"-->
        <!--                            data-aspectratio="0.75" data-widths="[360, 540, 720, 900, 1080]" data-sizes="auto"-->
        <!--                            alt="" style="object-position: center center;">-->
        <!--                    </div><span-->
        <!--                        class="collection-item__title collection-item__title--below collection-item__title--heading collection-item__title--bottom-center">-->
        <!--                        <span>-->
        <!--                            Almaaz-->
        <!--                        </span>-->
        <!--                    </span>-->

        <!--                </a>-->
        <!--            </div>-->
        <!--            <div class="grid__item small--one-half medium-up--one-quarter">-->
        <!--                <a href="collections/jadau-1.html" class="collection-item collection-item--below"-->
        <!--                    data-aos="row-of-4">-->
        <!--                    <div class="collection-image collection-image--square image-wrap"><img loading="lazy"-->
        <!--                            class="lazyload" src="#"-->
        <!--                            data-src="cdn/shop/files/WhatsAppImage2024-05-12at12.55.11PM_1_%7bwidth%7dx4234.html?v=1715604193"-->
        <!--                            data-aspectratio="0.665625" data-widths="[360, 540, 720, 900, 1080]"-->
        <!--                            data-sizes="auto" alt="" style="object-position: center center;">-->
        <!--                    </div><span-->
        <!--                        class="collection-item__title collection-item__title--below collection-item__title--heading collection-item__title--bottom-center">-->
        <!--                        <span>-->
        <!--                            Jadau-->
        <!--                        </span>-->
        <!--                    </span>-->

        <!--                </a>-->
        <!--            </div>-->
        <!--            <div class="grid__item small--one-half medium-up--one-quarter">-->
        <!--                <a href="collections/rajwada-1.html" class="collection-item collection-item--below"-->
        <!--                    data-aos="row-of-4">-->
        <!--                    <div class="collection-image collection-image--square image-wrap"><img loading="lazy"-->
        <!--                            class="lazyload" src="#"-->
        <!--                            data-src="cdn/shop/files/WhatsAppImage2024-05-17at11.57.19AM_%7bwidth%7dx90d3.html?v=1715943374"-->
        <!--                            data-aspectratio="0.75" data-widths="[360, 540, 720, 900, 1080]" data-sizes="auto"-->
        <!--                            alt="" style="object-position: center center;">-->
        <!--                    </div><span-->
        <!--                        class="collection-item__title collection-item__title--below collection-item__title--heading collection-item__title--bottom-center">-->
        <!--                        <span>-->
        <!--                            Rajwada-->
        <!--                        </span>-->
        <!--                    </span>-->

        <!--                </a>-->
        <!--            </div>-->
        <!--            <div class="grid__item small--one-half medium-up--one-quarter">-->
        <!--                <a href="collections/lala-land.html" class="collection-item collection-item--below"-->
        <!--                    data-aos="row-of-4">-->
        <!--                    <div class="collection-image collection-image--square image-wrap"><img loading="lazy"-->
        <!--                            class="lazyload" src="#"-->
        <!--                            data-src="cdn/shop/files/marina-diamond-necklace-set-with-beads-or-lala-land-collection-attrangi-1_%7bwidth%7dx6109.html?v=1714933167"-->
        <!--                            data-aspectratio="0.733125" data-widths="[360, 540, 720, 900, 1080]"-->
        <!--                            data-sizes="auto"-->
        <!--                            alt="Marina Diamond Necklace Set With Beads | LaLa Land Collection - Attrangi"-->
        <!--                            style="object-position: center center;">-->
        <!--                    </div><span-->
        <!--                        class="collection-item__title collection-item__title--below collection-item__title--heading collection-item__title--bottom-center">-->
        <!--                        <span>-->
        <!--                            Lala Land-->
        <!--                        </span>-->
        <!--                    </span>-->

        <!--                </a>-->
        <!--            </div>-->
        <!--        </div>-->
        <!--    </div>-->
        <!--</div>-->
        <div id="shopify-section-1661622546ec4192af" class="shopify-section">
    
            <div id="insta-feed"></div>
          </div><!-- END content_for_index -->
        
        </main>
        <div id="shopify-section-footer-promotions" class="shopify-section index-section--footer">
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u877593591/domains/webreakhost.com/public_html/shopkart/resources/views/frontend/Index.blade.php ENDPATH**/ ?>
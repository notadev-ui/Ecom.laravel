

<?php $__env->startSection('main-container'); ?>
<script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <style>
        .card-text {
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
            text-overflow: ellipsis;
            height: 4.5em; /* (line-height) * (number of lines you want to show) */
        }
        
        .image-container {
            position: relative;
        }
        .add-to-cart-btn {
            position: absolute;
            bottom: 10px;
            left: 50%;
            transform: translateX(-50%);
            display: none;
        }
        .image-container:hover .add-to-cart-btn {
                display: block;
                background: black;
                color: white;
                padding-right: 20px;
                padding-left: 46px;
                padding-top: 9px;
                padding-bottom: 9px;
                border-radius: 11px;
                width: 200px;
                }
        .image-container img {
            display: block;
            width: 100%;
            height: auto;
        }
        
    </style>
<header class="site-navbar" role="banner">
<div class="container">
    <div class="row align-items-center">
        
        <div class="col-5 col-md-9 d-none d-xl-block">
                 <nav class="site-navigation position-relative text-right" role="navigation">
                        <ul class="site-menu js-clone-nav mr-auto d-none d-lg-block">
                        <!--<li class="has-children">-->
                        <!--<a href="about.html"><span>Dropdown</span></a>-->
                        <!--<ul class="dropdown arrow-top">-->
                        <!--<li><a href="#">Menu One</a></li>-->
                        <!--<li><a href="#">Menu Two</a></li>-->
                        <!--<li><a href="#">Menu Three</a></li>-->
                        <!--<li class="has-children">-->
                        <!--<a href="#">Dropdown</a>-->
                        <!--<ul class="dropdown">-->
                        <!--<li><a href="#">Menu One</a></li>-->
                        <!--<li><a href="#">Menu Two</a></li>-->
                        <!--<li><a href="#">Menu Three</a></li>-->
                        <!--<li><a href="#">Menu Four</a></li>-->
                        <!--</ul>-->
                        <!--</li>-->
                        <!--</ul>-->
                        <!--</li>-->
                        <li><a href="<?php echo e(route('category.show', 2)); ?>"><span>Earrings</span></a></li>
                        <li><a href="<?php echo e(route('category.show', 8)); ?>"><span>Necklaces</span></a></li>
                        <li><a href="<?php echo e(route('category.show', 9)); ?>"><span>Bracelets</span></a></li>
                        <li><a href="<?php echo e(route('category.show', 10)); ?>"><span>Anklets</span></a></li>
                        <li><a href="<?php echo e(route('category.show', 11)); ?>"><span>Rings</span></a></li>

                        </ul>
                  </nav>
        </div>
        <div class="d-inline-block d-xl-none ml-md-0 mr-auto py-3" style="position: relative; top: 3px;"><a href="#" class="site-menu-toggle js-menu-toggle text-white"><span class="icon-menu h3"></span></a></div>
    </div>
</div>

</header>



<main class="main-content" id="MainContent">
    <div id="shopify-section-collection-header" class="shopify-section"><div class="page-width page-content page-content--top">
<header class="section-header section-header--flush">
<h1 class="section-header__title">
    Exclusive Sale
  </h1>
</header>
</div>
<div id="CollectionHeaderSection" data-section-id="collection-header" data-section-type="collection-header">
</div>
<style> #shopify-section-collection-header h1 {color: #000;} #shopify-section-collection-header h1 {text-transform: uppercase;} </style></div>

<div id="CollectionAjaxResult" class="collection-content">
<div id="CollectionAjaxContent">
<div class="page-width">


<div class="container">
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="row">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="col col-md-3 mt-3">
           <div class="card" style="height:428px;">
                    <!--<div class="image-container">-->
                    <!--        <img src="<?php echo e(asset('image/' . $product->firstImage)); ?>" class="card-img-top img-fluid" alt="<?php echo e($product->productName); ?>"style="height:200px!important;" >-->
                            <!--<a href="#" class="btn btn-primary add-to-cart-btn">Add to Cart</a>-->
                    <!--      <a href="#" class="add-to-cart-btn "><span class="fa fa-shopping-cart px-1"></span>Add To Cart</a>-->

                    <!--</div>-->
                    
                     <div class="image-container">
                    <img src="<?php echo e(asset('image/' . $product->firstImage)); ?>" class="card-img-top img-fluid" alt="<?php echo e($product->productName); ?>" style="height:200px!important;">
                    <form action="<?php echo e(route('cart.add')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="product_id" value="<?php echo e($product->productId); ?>">
                        
                         <button type="submit"  <a href="#" class="add-to-cart-btn "><span class="fa fa-shopping-cart px-1"></span>Add To Cart</a></button>


                       
                    </form>
                </div>
                   <div class="card-body">
            <h5 class="card-title"><a href="<?php echo e(route('product.view', $product->productId)); ?>"><?php echo e($product->productName); ?></a></h5>
                        <p class="card-text"style="margin-bottom:2px; color:black!important;"><?php echo e($product->productDescription); ?></p>
                        <p class="card-text "style="margin-bottom:2px; height:38px; color:black!important;">₹<?php echo e($product->productPrice); ?></p>
                       <a href="<?php echo e(route('product.view', $product->productId)); ?>" class="btn btn-danger" style="background: #ec688d;border: 2px solid #ec688d; color: black;
                         width: 200px;">Shop Now</a>

                       <!--<div class="row">-->
                       <!--    <div class="col col-md-6"><a href="#" class="btn btn-primary">Cart</a></div>-->
                       <!--    <div class="col col-md-6"><box-icon name='cart' type='solid'  ></box-icon></div>-->
                       <!--</div>-->

                        
                         
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>


</div>
</div>
</div>

<script type="application/ld+json">
{
"@context": "http://schema.org",
"@type": "CollectionPage",



"image": {
"@type": "ImageObject",
"height": 628,
"url": "https:\/\/attrangi.in\/cdn\/shop\/files\/att_logo_new_1200x.png?v=1621072841",
"width": 1200
},

"name": "Exclusive Sale"
}
</script>

  </main>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u877593591/domains/webreakhost.com/public_html/shopkart/resources/views/frontend/jewelry.blade.php ENDPATH**/ ?>


<?php $__env->startSection('main-container'); ?>


<style>
.aa-prod-view-size a{
    border: 1px solid #ddd;
    display: inline-block;
    font-size: 14px;
    color:black;
    letter-spacing: 0.5px;
    margin-bottom: 5px;
    margin-right: 8px;
    padding: 5px 10px;
    transition: all 0.5s ease 0s;
}

.box {
    background: #f5f5f5;
    display: inline-flex;
    padding: 0;
    width:80px;
    border: 1px solid var(--tb-border-color);
}
.buycartbtn{
    background: #ec688d;
    border-radius: 5px;
    padding: 10px;
    width: 150px;
}

</style>

<div class="container">
<!--    <div class="card mt-4">-->

<!--        <div class="card-body">-->
<!--<h2 class="card-title fw-600" style="color:black; font-weight: 600;"><?php echo e(strtoupper($product->productName)); ?></h2>-->
<!--            <p class="card-text" style="color:black;"><?php echo e($product->productDescription); ?></p>-->
<!--            <p class="card-text" style="color:black;">Price: ₹<?php echo e($product->productPrice); ?></p>-->
            
            <!-- Add more product details here as needed -->
<!--        </div>-->
<!--    </div>-->
    
        <div class="row mt-5 mb-3">
              <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
               <div class="col col-md-5 col-lg-5 col-xl-5 col-12">
                 <img src="<?php echo e(asset('image/' . $product->firstImage)); ?>" class="card-img-top img-fluid " alt="<?php echo e($product->productName); ?>">
               </div>
                           
               <div class="col col-md-7 col-lg-7 col-xl-7 col-12">
                   
                    <h2 class="card-title fw-600" style="color: #ec688d;
                        font-weight: 600;"><?php echo e(strtoupper($product->productName)); ?></h2>
                                <p class="card-text" style="color:black; font-size: x-large;">Price: ₹<?php echo e($product->productPrice); ?></p>
                    
                                       <p class="card-text" style="color:black;"><?php echo e($product->productDescription); ?></p>
                                        <h4 class="mt-5">Size</h4>
                                                <div class="aa-prod-view-size">
                                                  <a href="#">S</a>
                                                  <a href="#">M</a>
                                                  <a href="#">L</a>
                                                  <a href="#">XL</a>
                                                </div>
                                                

	      
            		<div class="quantity" class="min-width:128px;">
                     	    
                     	    <div class="row mt-5">
                     	       
                                <form action="<?php echo e(route('cart.add')); ?>" method="POST">
                                     <?php echo csrf_field(); ?>
                                        <input type="hidden" name="product_id" value="<?php echo e($product->productId); ?>">
        
                             	        <div class="col col-md-6 "><button type="submit" name="add-to-cart" value="7822" class="buycartbtn">Add to cart</button></div>
                     	        
                     	        </form>
                     	        <div class="col col-md-6 "><button class="buycartbtn">Buy Now</button><input type="hidden" value="0" name="hara_buy_now"></div>
                     	    </div>
                     	    
<!--<div class="row">-->
<!--    <div class="col col-md-6 "><button type="submit" name="add-to-cart" value="7822" class="buycartbtn">Add to cart</button></div>-->
<!--    <div class="col col-md-6 "><button class="buycartbtn">Buy Now</button><input type="hidden" value="0" name="hara_buy_now"></button></div>-->
<!--</div>-->
            	        
                    		        	           
                    <div class="hara-custom-fields d-none"><input type="hidden" name="hara-enable-addtocart-ajax" value="0"><input type="hidden" name="data-product_id" value="7822"><input type="hidden" name="data-type" value="simple"></div>
        </div>
        
        <hr>
    </div>
</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u877593591/domains/webreakhost.com/public_html/shop24/resources/views/frontend/view_product.blade.php ENDPATH**/ ?>
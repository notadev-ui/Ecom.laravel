
<?php $__env->startSection('title', 'product'); ?>

<?php $__env->startSection('content'); ?>


    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

        <form action="<?php echo e(route('admin.updateProduct')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
          <div class="d-flex flex-wrap justify-content-between align-items-center mb-3">

        <div class="d-flex flex-column justify-content-center">
            <h4 class="mb-1 mt-3">Update Product</h4>
        </div>
        <div class="d-flex align-content-center flex-wrap gap-3">
            <a id="cancelButton" class="btn btn-label-danger" href="">Cancel</a>
            <button type="submit" class="btn btn-primary">Save</button>
        </div>
    </div>
  <div class="row">

        <div class="col-12 col-lg-12">
            <!-- case details -->
            <div class="card mb-4">
                <div class="card-header">

                    
                </div>
                <div class="card-body">
                    <div class="row mb-3">

                        <div class="col">
                           <label for="categoryId">Category</label>
                    <select name="categoryId" id="categoryId" class="form-control">
                    <option value="<?php echo e($productData->categoryId); ?>"><?php echo e($productData->categoryName); ?></option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->categoryId); ?>"><?php echo e($category->categoryName); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                        </div>

                        <div class="col">
                            <!--    <label for="subCategoryId">Sub Category</label>-->
                <!--    <select name="subCategoryId" id="subCategoryId" class="form-control">-->
                        <!-- Options will be dynamically populated using JavaScript -->
                <!--    </select>-->
                            <div class="invalid-feedback"></div>
                            <div class="valid-feedback"></div>
                        </div>

                    </div>

                 
                    <div class="row mb-3">
                        <!--<div class="col">-->
                           <!--<label for="subcategoryName">Product Id</label>-->
                    <input type="hidden" class="form-control" id="productId" name="productId" maxlength="5000" value="<?php echo e($productData->productId); ?>">

                        <!--    <div class="invalid-feedback"></div>-->
                        <!--    <div class="valid-feedback"></div>-->
                        <!--</div>-->

                        <div class="col">
                     <label for="productName">Product Name</label>
                    <input type="text" class="form-control" id="productName" name="productName" maxlength="5000" value="<?php echo e($productData->productName); ?>">
                        </div>
                        <div class="col">
                            <label for="subcategoryName">Product Price</label>
                    <input type="text" class="form-control" id="productPrice" name="productPrice" maxlength="5000" value="<?php echo e($productData->productPrice); ?>">
                            <div class="invalid-feedback"></div>
                            <div class="valid-feedback"></div>
                        </div>

                    </div>
                    <div class="row mb-3">
                        <div class="col">
                            <label for="subcategoryName">Product Sale Price</label>
                    <input type="text" class="form-control" id="productSalePrice" name="productSalePrice" maxlength="5000" value="<?php echo e($productData->productSalePrice); ?>">
                            <div class="invalid-feedback"></div>
                            <div class="valid-feedback"></div>
                        </div>

                        <div class="col">
                             <label for="subcategoryName">Product Description</label>
                    <input type="text" class="form-control" id="productDescription" name="productDescription" maxlength="5000" value="<?php echo e($productData->productDescription); ?>">
                        </div>

                    </div>
                    <div class="row mb-3">
                        <div class="col">
                          <label for="subcategoryName">Product Type</label>
                    <select name="productType" id="productType" class="product_type form-control">
                        <option value="latest">latest</option>
                        <option value="Popular">Popular</option>
                        <option value="Trending">Trending</option>
                    </select>
                            <div class="invalid-feedback"></div>
                            <div class="valid-feedback"></div>
                        </div>

                        <div class="col">
                           <label for="subcategoryName">Product Rating</label>
                    <input type="text" class="form-control" id="productRating" name="productRating" maxlength="5000" value="<?php echo e($productData->productRating); ?>">
                            <div class="invalid-feedback"></div>
                            <div class="valid-feedback"></div>
                        </div>

                    </div>
                    <div class="row mb-3">
                        <div class="col">
                             <label for="existingImages">Existing Images</label>
                    <?php if(!empty($productData->image)): ?>
                        <?php $__currentLoopData = explode('|', $productData->image); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="existing-image">
                                <img src="https://zumpon.com/public/image/<?php echo e($image); ?>" alt="" width="200">
                                <input type="checkbox" name="deleteImages[]" value="<?php echo e($image); ?>"> Delete
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        No images found.
                    <?php endif; ?>
                        
                            <div class="invalid-feedback"></div>
                            <div class="valid-feedback"></div>
                        </div>
                        <div class="col">
                            <label for="newImages">New Images (if any)</label>
                        <input type="file" class="form-control form-control-file validate not-empty" placeholder="" 
                          id="image" name="image[]"  multiple>
                        
                            <div class="invalid-feedback"></div>
                            <div class="valid-feedback"></div>
                        </div>

                    <!--    <div class="col">-->
                    <!--       <label for="subcategoryName">Product Rating</label>-->
                    <!--<input type="text" class="form-control" id="productRating" name="productRating" maxlength="5000">-->
                    <!--        <div class="invalid-feedback"></div>-->
                    <!--        <div class="valid-feedback"></div>-->
                    <!--    </div>-->

                    </div>
                   



                </div>
            </div>

        </div>


    </div>


         
        </form>


<script>
$(document).ready(function() {
    $('.category').select2();
});
$(document).ready(function() {
    $('.product_type').select2();
});
</script>



    <?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u877593591/domains/webreakhost.com/public_html/shopkart/resources/views/frontend/admin/updateProduct.blade.php ENDPATH**/ ?>


<?php $__env->startSection('main-container'); ?>
<style>
 .card-text {
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
            text-overflow: ellipsis;
            height: 4.5em; /* (line-height) * (number of lines you want to show) */
        }
        
        .image-container {
            position: relative;
        }
        .add-to-cart-btn {
            position: absolute;
            bottom: 10px;
            left: 50%;
            transform: translateX(-50%);
            display: none;
        }
        .image-container:hover .add-to-cart-btn {
                display: block;
                background: black;
                color: white;
                padding-right: 20px;
                padding-left: 46px;
                padding-top: 9px;
                padding-bottom: 9px;
                border-radius: 11px;
                width: 200px;
                }
                
</style>

  <div class="container">
        <div class="row mb-5">
            <div class="col col-md-5">
                <img src="https://caketheme.com/html/mojuri/media/banner/banner-1-3.jpg" alt="Your Image">
            </div>
            <div class="col col-md-7">
                <h1>Welcome to Shopkart24</h1>
                <p>Hello everyone i am ..... director of Shopkart24. I am a youtuber turned into entrepreneur, i need travelling as much as food. Shopkart24 is like a dream or we can say idea which came in my mind during my B.tech days. I was dreaming about shopkart24 where i can provide the various items in best affordable prices without compromising the quality</p>
                <p>Initially i started my journey with instagram and then  switch it to website for the convenience of the customer. Here anyone can easily track their order and also easily able to get the all products with proper details. I learnt so many things as a seller by using so many ecommerce websites and soon will add reliable and effective sellers over here with keep that negative points in mind which sellers are facing on other websites. My moto is to make policies by keeping in mind both sellers and customers.</p>
                <p><b>....</b><br>Director</p>
            </div>
        </div>
        
        <hr>
        <div class="row mt-5">
            <div class="col col-md-6">
            <h1 class="text-center">Our Mission</h1>
                <p class="text-center">Shopkart24 is not only customer oriented platform i want this to be Seller oriented also. So my mission is to make a platform like Shopkart24 where both Seller & Customer will be happy. Currently we don’t have any seller but in future you will get one stop beauty solution over here.</p>
                            </div>
            <div class="col col-md-6">
                <h1 class="text-center">Our Goal</h1>
                <p class="text-center">To make Shopkart24 best multi vendor platform within next 2 years.</p>
                
            </div>
        </div>
    </div>
<div id="CollectionAjaxResult" class="collection-content">
<div id="CollectionAjaxContent">
<div class="page-width">


<div class="container">
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="row">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="col col-md-3 mt-3">
           <div class="card" style="height:428px;">
                    <!--<div class="image-container">-->
                    <!--        <img src="<?php echo e(asset('image/' . $product->firstImage)); ?>" class="card-img-top img-fluid" alt="<?php echo e($product->productName); ?>"style="height:200px!important;" >-->
                            <!--<a href="#" class="btn btn-primary add-to-cart-btn">Add to Cart</a>-->
                    <!--      <a href="#" class="add-to-cart-btn "><span class="fa fa-shopping-cart px-1"></span>Add To Cart</a>-->

                    <!--</div>-->
                    
                     <div class="image-container">
                    <img src="<?php echo e(asset('image/' . $product->firstImage)); ?>" class="card-img-top img-fluid" alt="<?php echo e($product->productName); ?>" style="height:200px!important;">
                        <form action="<?php echo e(route('cart.add')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="product_id" value="<?php echo e($product->productId); ?>">
                            
                             <button type="submit"  <a href="#" class="add-to-cart-btn "><span class="fa fa-shopping-cart px-1"></span>Add To Cart</a></button>
                               
                           
                        </form>
                       

                </div>
                   <div class="card-body">
            <h5 class="card-title"><a href="<?php echo e(route('product.view', $product->productId)); ?>"><?php echo e($product->productName); ?></a></h5>
                        <p class="card-text"style="margin-bottom:2px; color:black!important;"><?php echo e($product->productDescription); ?></p>
                        <p class="card-text "style="margin-bottom:2px; height:38px; color:black!important;">₹<?php echo e($product->productPrice); ?></p>
                       <a href="<?php echo e(route('product.view', $product->productId)); ?>" class="btn btn-danger" style="background: #ec688d;border: 2px solid #ec688d; color: black;
                         width: 200px;">Shop Now</a>

                       <!--<div class="row">-->
                       <!--    <div class="col col-md-6"><a href="#" class="btn btn-primary">Cart</a></div>-->
                       <!--    <div class="col col-md-6"><box-icon name='cart' type='solid'  ></box-icon></div>-->
                       <!--</div>-->

                        
                         
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>


</div>
</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u877593591/domains/webreakhost.com/public_html/shop24/resources/views/frontend/about.blade.php ENDPATH**/ ?>
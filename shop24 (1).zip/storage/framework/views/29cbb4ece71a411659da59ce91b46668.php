
<?php $__env->startSection('title', 'dashboard'); ?>

<?php $__env->startSection('content'); ?>


    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>


    <div class="card">
        <div class="card-datatable table-responsive">
            <div id="DataTables_Table_0_wrapper" class="dataTables_wrapper dt-bootstrap5 no-footer">
                <div class="card-header d-flex rounded-0 flex-wrap py-md-0">
                    <div class="me-5 ms-n2 pe-5">
                        <div id="DataTables_Table_0_filter" class="dataTables_filter">
                            <form action="" method="GET">
                                <input type="text" name="search" value="" placeholder="Search cases..." class="form-control">
                                <button type="submit" class="btn btn-primary">Search</button>
                                <a href="" class="ms-2">
                                    <button class="btn btn-danger" type="button">Reset</button>
                                </a>
                            
                            </form>
                            
                        </div>
                    </div>

                    <a href="<?php echo e(route('admin.product')); ?>" class="dt-button add-new btn btn-primary" tabindex="0"
                        aria-controls="DataTables_Table_0" type="button"><span><i
                                class="bx bx-plus me-0 me-sm-1"></i><span class="d-none d-sm-inline-block">Add
                                Product</span></span>
                    </a>
                </div>

                <table class="datatables-products table border-top dataTable no-footer dtr-column collapsed"
                    id="DataTables_Table_0" aria-describedby="DataTables_Table_0_info" style="width: 954px;">

                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Product Name</th>
                            <th>Image</th>
                            <th>Update</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
  <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($data->productId); ?></td>
                            <td><?php echo e($data->productName); ?></td>
<td><img src="<?php echo e(asset('image/' . $data->firstImage)); ?>" alt="" width="200"></td>

                            <td><a href="<?php echo e(route('admin.deleteProduct', ['id' => $data->productId])); ?>" class="btn btn-danger btn-sm">Delete</a></td>
                            <td><a href="<?php echo e(route('admin.updateShowProduct', ['id' => $data->productId])); ?>" class="btn btn-primary btn-sm">Update</a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    
                </table>



            </div>
        </div>
    </div>



    <?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u877593591/domains/webreakhost.com/public_html/shopkart/resources/views/frontend/admin/showproduct.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title', 'dashboard'); ?>
<?php $__env->startSection('content'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u877593591/domains/webreakhost.com/public_html/shopkart/resources/views/frontend/admin/dashboard.blade.php ENDPATH**/ ?>
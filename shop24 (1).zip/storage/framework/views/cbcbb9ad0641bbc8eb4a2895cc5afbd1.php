<!doctype html>
<html class="no-js" lang="en" dir="ltr">

<!-- Mirrored from Shopkart.in/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 22 May 2024 04:58:05 GMT -->
<!-- Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css
" />
<link rel="stylesheet" href="<?php echo e(url('frontend/css/style.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(url('frontend/css/theme.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(url('frontend/css/searchtab.css')); ?>" />




<!-- Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link
    href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
    rel="stylesheet" />

<link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/vendor/fonts/boxicons.css')); ?>" />

<!-- Core CSS -->
<link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/vendor/css/core.css')); ?>" class="template-customizer-core-css" />
<link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/vendor/css/theme-default.css')); ?>" class="template-customizer-theme-css" />
<link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/demo.css')); ?>" />

<!-- Vendors CSS -->
<link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/vendor/libs/perfect-scrollbar/perfect-scrollbar.css')); ?>" />

<!-- Page CSS -->
<!-- Page -->
<link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/vendor/css/pages/page-auth.css')); ?>" />

<!-- Helpers -->
<script src="<?php echo e(asset('assets/dashboard/vendor/js/helpers.js')); ?>"></script>
<!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
<!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
<script src="<?php echo e(asset('assets/dashboard/js/config.js')); ?>"></script>


<head>


    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="theme-color" content="#ec688d">
    <link rel="canonical" href="index.html">
    <link rel="preconnect" href="https://cdn.shopify.com/">
    <link rel="preconnect" href="https://fonts.shopifycdn.com/">
    <link rel="dns-prefetch" href="https://productreviews.shopifycdn.com/">
    <link rel="dns-prefetch" href="https://ajax.googleapis.com/">
    <link rel="dns-prefetch" href="https://maps.googleapis.com/">
    <link rel="dns-prefetch" href="https://maps.gstatic.com/">
    <meta name="google-site-verification" content="ZDN-LFhiMczRy3nmyvfM9qcER_umlNz8qpjdrQqYZi8">
    <meta name="facebook-domain-verification" content="jzog229us1x6pnbz75cdnyv39skfg0">
    <link rel="shortcut icon" href="cdn/shop/files/Shopkart_logo_32x322e44.png?v=1626358876" type="image/png">
    <title>ShopKart24

    </title>
   
    <meta name="twitter:description"
        content="Shopkart - Exquisite designs crafted with precision. Our imitation jewellery brand brings affordable elegance to every occasion. Shine with style!">
   

    <link href="cdn/shop/t/40/assets/theme78b0.css?v=139269663027275441241714929435" rel="stylesheet" type="text/css"
        media="all" />

    <script>
        document.documentElement.className = document.documentElement.className.replace('no-js', 'js');

        window.theme = window.theme || {};
        theme.routes = {
            home: "/",
            cart: "/cart.js",
            cartPage: "/cart",
            cartAdd: "/cart/add.js",
            cartChange: "/cart/change.js"
        };
        theme.strings = {
            soldOut: "Sold Out",
            unavailable: "Unavailable",
            stockLabel: "Only [count] in stock!",
            willNotShipUntil: "Will not ship until [date]",
            willBeInStockAfter: "Will be in stock after [date]",
            waitingForStock: "Inventory on the way",
            savePrice: "Save [saved_amount]",
            cartEmpty: "Your cart is currently empty.",
            cartTermsConfirmation: "You must agree with the terms and conditions of sales to check out",
            searchCollections: "Collections:",
            searchPages: "Pages:",
            searchArticles: "Articles:"
        };
        theme.settings = {
            dynamicVariantsEnable: true,
            dynamicVariantType: "button",
            cartType: "drawer",
            isCustomerTemplate: false,
            moneyFormat: "Rs. ",
            saveType: "dollar",
            recentlyViewedEnabled: false,
            productImageSize: "portrait",
            productImageCover: true,
            predictiveSearch: true,
            predictiveSearchType: "product",
            inventoryThreshold: 20,
            quickView: true,
            themeName: 'Impulse',
            themeVersion: "4.1.2"
        };
    </script>

   
</head>

<body class="template-index" data-center-text="true" data-button_style="round" data-type_header_capitalize="false"
    data-type_headers_align_text="true" data-type_product_capitalize="false" data-swatch_style="round">
    <a class="in-page-link visually-hidden skip-link" href="#MainContent">Skip to content</a>

    <div id="PageContainer" class="page-container">
        <div class="transition-body">
            <div id="shopify-section-header" class="shopify-section">

                <div id="NavDrawer" class="drawer drawer--left">
                    <div class="drawer__contents">
                        <div class="drawer__fixed-header">
                            <div class="drawer__header appear-animation appear-delay-1">
                                <div class="h2 drawer__title"></div>
                                <div class="drawer__close">
                                    <button type="button" class="drawer__close-button js-drawer-close">
                                        <svg aria-hidden="true" focusable="false" role="presentation"
                                            class="icon icon-close" viewBox="0 0 64 64">
                                            <path d="M19 17.61l27.12 27.13m0-27.12L19 44.74" />
                                        </svg>
                                        <span class="icon__fallback-text">Close menu</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="drawer__scrollable">
                            <ul class="mobile-nav" role="navigation" aria-label="Primary">
                                <li class="mobile-nav__item appear-animation appear-delay-2"><a
                                        href="<?php echo e(url('/')); ?>"
                                        class="mobile-nav__link mobile-nav__link--top-level">Home</a></li>

                                        <li class="mobile-nav__item appear-animation appear-delay-10"><a
                                          href="<?php echo e(url('/about')); ?>"
                                          class="mobile-nav__link mobile-nav__link--top-level">About Us</a></li>
                             
                                <li class="mobile-nav__item appear-animation appear-delay-5">
                                    <div class="mobile-nav__has-sublist"><button type="button"
                                            aria-controls="Linklist-4"
                                            class="mobile-nav__link--button mobile-nav__link--top-level collapsible-trigger collapsible--auto-height">
                                            <span class="mobile-nav__faux-link">
                                                Shop Jewellery
                                            </span>
                                            <div class="mobile-nav__toggle">
                                                <span class="faux-button"><span
                                                        class="collapsible-trigger__icon collapsible-trigger__icon--open"
                                                        role="presentation">
                                                        <svg aria-hidden="true" focusable="false" role="presentation"
                                                            class="icon icon--wide icon-chevron-down"
                                                            viewBox="0 0 28 16">
                                                            <path d="M1.57 1.59l12.76 12.77L27.1 1.59" stroke-width="2"
                                                                stroke="#000" fill="none" fill-rule="evenodd" />
                                                        </svg>
                                                    </span>
                                                </span>
                                            </div>
                                        </button></div>
                                    <div id="Linklist-4"
                                        class="mobile-nav__sublist collapsible-content collapsible-content--all">
                                        <div class="collapsible-content__inner">
                                            <ul class="mobile-nav__sublist">
                                                <li class="mobile-nav__item">
                                                    <div class="mobile-nav__child-item"><a
                                                            href="collections/ginni-gift-box.html"
                                                            class="mobile-nav__link"
                                                            id="Sublabel-collections-ginni-gift-box1">
                                                            Ginni / Gift Box
                                                        </a></div>
                                                </li>
                                                <li class="mobile-nav__item">
                                                    <div class="mobile-nav__child-item"><a
                                                            href="collections/earrings-1.html"
                                                            class="mobile-nav__link"
                                                            id="Sublabel-collections-earrings-12">
                                                            Earrings
                                                        </a><button type="button"
                                                            aria-controls="Sublinklist-4-collections-earrings-12"
                                                            aria-labelledby="Sublabel-collections-earrings-12"
                                                            class="collapsible-trigger"><span
                                                                class="collapsible-trigger__icon collapsible-trigger__icon--circle collapsible-trigger__icon--open"
                                                                role="presentation">
                                                                <svg aria-hidden="true" focusable="false"
                                                                    role="presentation"
                                                                    class="icon icon--wide icon-chevron-down"
                                                                    viewBox="0 0 28 16">
                                                                    <path d="M1.57 1.59l12.76 12.77L27.1 1.59"
                                                                        stroke-width="2" stroke="#000"
                                                                        fill="none" fill-rule="evenodd" />
                                                                </svg>
                                                            </span>
                                                        </button></div>
                                                    <div id="Sublinklist-4-collections-earrings-12"
                                                        aria-labelledby="Sublabel-collections-earrings-12"
                                                        class="mobile-nav__sublist collapsible-content collapsible-content--all">
                                                        <div class="collapsible-content__inner">
                                                            <ul class="mobile-nav__grandchildlist">
                                                                <li class="mobile-nav__item">
                                                                    <a href="collections/earrings-diamond.html"
                                                                        class="mobile-nav__link">
                                                                        Diamond
                                                                    </a>
                                                                </li>
                                                                <li class="mobile-nav__item">
                                                                    <a href="collections/earrings-indian.html"
                                                                        class="mobile-nav__link">
                                                                        Indian
                                                                    </a>
                                                                </li>
                                                                <li class="mobile-nav__item">
                                                                    <a href="collections/earrings-tribal.html"
                                                                        class="mobile-nav__link">
                                                                        Tribal
                                                                    </a>
                                                                </li>
                                                                <li class="mobile-nav__item">
                                                                    <a href="collections/earrings-party-wear.html"
                                                                        class="mobile-nav__link">
                                                                        Western & Party Wear
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="mobile-nav__item">
                                                    <div class="mobile-nav__child-item"><a
                                                            href="collections/jewellery-sets-1.html"
                                                            class="mobile-nav__link"
                                                            id="Sublabel-collections-jewellery-sets-13">
                                                            Jewellery Sets
                                                        </a><button type="button"
                                                            aria-controls="Sublinklist-4-collections-jewellery-sets-13"
                                                            aria-labelledby="Sublabel-collections-jewellery-sets-13"
                                                            class="collapsible-trigger"><span
                                                                class="collapsible-trigger__icon collapsible-trigger__icon--circle collapsible-trigger__icon--open"
                                                                role="presentation">
                                                                <svg aria-hidden="true" focusable="false"
                                                                    role="presentation"
                                                                    class="icon icon--wide icon-chevron-down"
                                                                    viewBox="0 0 28 16">
                                                                    <path d="M1.57 1.59l12.76 12.77L27.1 1.59"
                                                                        stroke-width="2" stroke="#000"
                                                                        fill="none" fill-rule="evenodd" />
                                                                </svg>
                                                            </span>
                                                        </button></div>
                                                    <div id="Sublinklist-4-collections-jewellery-sets-13"
                                                        aria-labelledby="Sublabel-collections-jewellery-sets-13"
                                                        class="mobile-nav__sublist collapsible-content collapsible-content--all">
                                                        <div class="collapsible-content__inner">
                                                            <ul class="mobile-nav__grandchildlist">
                                                                <li class="mobile-nav__item">
                                                                    <a href="collections/jewellery-sets-diamond.html"
                                                                        class="mobile-nav__link">
                                                                        Diamond
                                                                    </a>
                                                                </li>
                                                                <li class="mobile-nav__item">
                                                                    <a href="collections/jewellery-sets-indian.html"
                                                                        class="mobile-nav__link">
                                                                        Indian
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="mobile-nav__item">
                                                    <div class="mobile-nav__child-item"><a
                                                            href="collections/bracelet-bangles-1.html"
                                                            class="mobile-nav__link"
                                                            id="Sublabel-collections-bracelet-bangles-14">
                                                            Bracelet/Bangles
                                                        </a><button type="button"
                                                            aria-controls="Sublinklist-4-collections-bracelet-bangles-14"
                                                            aria-labelledby="Sublabel-collections-bracelet-bangles-14"
                                                            class="collapsible-trigger"><span
                                                                class="collapsible-trigger__icon collapsible-trigger__icon--circle collapsible-trigger__icon--open"
                                                                role="presentation">
                                                                <svg aria-hidden="true" focusable="false"
                                                                    role="presentation"
                                                                    class="icon icon--wide icon-chevron-down"
                                                                    viewBox="0 0 28 16">
                                                                    <path d="M1.57 1.59l12.76 12.77L27.1 1.59"
                                                                        stroke-width="2" stroke="#000"
                                                                        fill="none" fill-rule="evenodd" />
                                                                </svg>
                                                            </span>
                                                        </button></div>
                                                    <div id="Sublinklist-4-collections-bracelet-bangles-14"
                                                        aria-labelledby="Sublabel-collections-bracelet-bangles-14"
                                                        class="mobile-nav__sublist collapsible-content collapsible-content--all">
                                                        <div class="collapsible-content__inner">
                                                            <ul class="mobile-nav__grandchildlist">
                                                                <li class="mobile-nav__item">
                                                                    <a href="collections/bracelet-bangles-diamond.html"
                                                                        class="mobile-nav__link">
                                                                        Diamond
                                                                    </a>
                                                                </li>
                                                                <li class="mobile-nav__item">
                                                                    <a href="collections/bracelet-bangles-indian.html"
                                                                        class="mobile-nav__link">
                                                                        Indian
                                                                    </a>
                                                                </li>
                                                                <li class="mobile-nav__item">
                                                                    <a href="collections/bracelet-bangles-contemporary.html"
                                                                        class="mobile-nav__link">
                                                                        Contemporary
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="mobile-nav__item">
                                                    <div class="mobile-nav__child-item"><a
                                                            href="collections/rings-1.html" class="mobile-nav__link"
                                                            id="Sublabel-collections-rings-15">
                                                            Rings
                                                        </a><button type="button"
                                                            aria-controls="Sublinklist-4-collections-rings-15"
                                                            aria-labelledby="Sublabel-collections-rings-15"
                                                            class="collapsible-trigger"><span
                                                                class="collapsible-trigger__icon collapsible-trigger__icon--circle collapsible-trigger__icon--open"
                                                                role="presentation">
                                                                <svg aria-hidden="true" focusable="false"
                                                                    role="presentation"
                                                                    class="icon icon--wide icon-chevron-down"
                                                                    viewBox="0 0 28 16">
                                                                    <path d="M1.57 1.59l12.76 12.77L27.1 1.59"
                                                                        stroke-width="2" stroke="#000"
                                                                        fill="none" fill-rule="evenodd" />
                                                                </svg>
                                                            </span>
                                                        </button></div>
                                                    <div id="Sublinklist-4-collections-rings-15"
                                                        aria-labelledby="Sublabel-collections-rings-15"
                                                        class="mobile-nav__sublist collapsible-content collapsible-content--all">
                                                        <div class="collapsible-content__inner">
                                                            <ul class="mobile-nav__grandchildlist">
                                                                <li class="mobile-nav__item">
                                                                    <a href="collections/rings-diamond.html"
                                                                        class="mobile-nav__link">
                                                                        Diamond
                                                                    </a>
                                                                </li>
                                                                <li class="mobile-nav__item">
                                                                    <a href="collections/rings-indian.html"
                                                                        class="mobile-nav__link">
                                                                        Indian
                                                                    </a>
                                                                </li>
                                                                <li class="mobile-nav__item">
                                                                    <a href="collections/rings-contemporary.html"
                                                                        class="mobile-nav__link">
                                                                        Contemporary
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="mobile-nav__item">
                                                    <div class="mobile-nav__child-item"><a
                                                            href="collections/headgears.html" class="mobile-nav__link"
                                                            id="Sublabel-collections-headgears6">
                                                            Headgear
                                                        </a><button type="button"
                                                            aria-controls="Sublinklist-4-collections-headgears6"
                                                            aria-labelledby="Sublabel-collections-headgears6"
                                                            class="collapsible-trigger"><span
                                                                class="collapsible-trigger__icon collapsible-trigger__icon--circle collapsible-trigger__icon--open"
                                                                role="presentation">
                                                                <svg aria-hidden="true" focusable="false"
                                                                    role="presentation"
                                                                    class="icon icon--wide icon-chevron-down"
                                                                    viewBox="0 0 28 16">
                                                                    <path d="M1.57 1.59l12.76 12.77L27.1 1.59"
                                                                        stroke-width="2" stroke="#000"
                                                                        fill="none" fill-rule="evenodd" />
                                                                </svg>
                                                            </span>
                                                        </button></div>
                                                    <div id="Sublinklist-4-collections-headgears6"
                                                        aria-labelledby="Sublabel-collections-headgears6"
                                                        class="mobile-nav__sublist collapsible-content collapsible-content--all">
                                                        <div class="collapsible-content__inner">
                                                            <ul class="mobile-nav__grandchildlist">
                                                                <li class="mobile-nav__item">
                                                                    <a href="collections/headgears-indian.html"
                                                                        class="mobile-nav__link">
                                                                        Indian
                                                                    </a>
                                                                </li>
                                                                <li class="mobile-nav__item">
                                                                    <a href="collections/headgears-diamond.html"
                                                                        class="mobile-nav__link">
                                                                        Diamond
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="mobile-nav__item">
                                                    <div class="mobile-nav__child-item"><a
                                                            href="collections/necklace-mangalsutra.html"
                                                            class="mobile-nav__link"
                                                            id="Sublabel-collections-necklace-mangalsutra7">
                                                            Mangalsutra
                                                        </a><button type="button"
                                                            aria-controls="Sublinklist-4-collections-necklace-mangalsutra7"
                                                            aria-labelledby="Sublabel-collections-necklace-mangalsutra7"
                                                            class="collapsible-trigger"><span
                                                                class="collapsible-trigger__icon collapsible-trigger__icon--circle collapsible-trigger__icon--open"
                                                                role="presentation">
                                                                <svg aria-hidden="true" focusable="false"
                                                                    role="presentation"
                                                                    class="icon icon--wide icon-chevron-down"
                                                                    viewBox="0 0 28 16">
                                                                    <path d="M1.57 1.59l12.76 12.77L27.1 1.59"
                                                                        stroke-width="2" stroke="#000"
                                                                        fill="none" fill-rule="evenodd" />
                                                                </svg>
                                                            </span>
                                                        </button></div>
                                                    <div id="Sublinklist-4-collections-necklace-mangalsutra7"
                                                        aria-labelledby="Sublabel-collections-necklace-mangalsutra7"
                                                        class="mobile-nav__sublist collapsible-content collapsible-content--all">
                                                        <div class="collapsible-content__inner">
                                                            <ul class="mobile-nav__grandchildlist">
                                                                <li class="mobile-nav__item">
                                                                    <a href="collections/necklace-mangalsutra-bracelets.html"
                                                                        class="mobile-nav__link">
                                                                        Bracelets
                                                                    </a>
                                                                </li>
                                                                <li class="mobile-nav__item">
                                                                    <a href="collections/mangalsutra-necklaces.html"
                                                                        class="mobile-nav__link">
                                                                        Necklaces
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="mobile-nav__item">
                                                    <div class="mobile-nav__child-item"><a
                                                            href="collections/necklace-1.html"
                                                            class="mobile-nav__link"
                                                            id="Sublabel-collections-necklace-18">
                                                            Necklace
                                                        </a><button type="button"
                                                            aria-controls="Sublinklist-4-collections-necklace-18"
                                                            aria-labelledby="Sublabel-collections-necklace-18"
                                                            class="collapsible-trigger"><span
                                                                class="collapsible-trigger__icon collapsible-trigger__icon--circle collapsible-trigger__icon--open"
                                                                role="presentation">
                                                                <svg aria-hidden="true" focusable="false"
                                                                    role="presentation"
                                                                    class="icon icon--wide icon-chevron-down"
                                                                    viewBox="0 0 28 16">
                                                                    <path d="M1.57 1.59l12.76 12.77L27.1 1.59"
                                                                        stroke-width="2" stroke="#000"
                                                                        fill="none" fill-rule="evenodd" />
                                                                </svg>
                                                            </span>
                                                        </button></div>
                                                    <div id="Sublinklist-4-collections-necklace-18"
                                                        aria-labelledby="Sublabel-collections-necklace-18"
                                                        class="mobile-nav__sublist collapsible-content collapsible-content--all">
                                                        <div class="collapsible-content__inner">
                                                            <ul class="mobile-nav__grandchildlist">
                                                                <li class="mobile-nav__item">
                                                                    <a href="collections/necklace-diamond.html"
                                                                        class="mobile-nav__link">
                                                                        Diamond
                                                                    </a>
                                                                </li>
                                                                <li class="mobile-nav__item">
                                                                    <a href="collections/necklace-indian.html"
                                                                        class="mobile-nav__link">
                                                                        Indian
                                                                    </a>
                                                                </li>
                                                                <li class="mobile-nav__item">
                                                                    <a href="collections/necklace-contemporary.html"
                                                                        class="mobile-nav__link">
                                                                        Contemporary
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="mobile-nav__item">
                                                    <div class="mobile-nav__child-item"><a
                                                            href="collections/nose-rings-1.html"
                                                            class="mobile-nav__link"
                                                            id="Sublabel-collections-nose-rings-19">
                                                            Nose Rings
                                                        </a><button type="button"
                                                            aria-controls="Sublinklist-4-collections-nose-rings-19"
                                                            aria-labelledby="Sublabel-collections-nose-rings-19"
                                                            class="collapsible-trigger"><span
                                                                class="collapsible-trigger__icon collapsible-trigger__icon--circle collapsible-trigger__icon--open"
                                                                role="presentation">
                                                                <svg aria-hidden="true" focusable="false"
                                                                    role="presentation"
                                                                    class="icon icon--wide icon-chevron-down"
                                                                    viewBox="0 0 28 16">
                                                                    <path d="M1.57 1.59l12.76 12.77L27.1 1.59"
                                                                        stroke-width="2" stroke="#000"
                                                                        fill="none" fill-rule="evenodd" />
                                                                </svg>
                                                            </span>
                                                        </button></div>
                                                    <div id="Sublinklist-4-collections-nose-rings-19"
                                                        aria-labelledby="Sublabel-collections-nose-rings-19"
                                                        class="mobile-nav__sublist collapsible-content collapsible-content--all">
                                                        <div class="collapsible-content__inner">
                                                            <ul class="mobile-nav__grandchildlist">
                                                                <li class="mobile-nav__item">
                                                                    <a href="collections/nose-rings-indian.html"
                                                                        class="mobile-nav__link">
                                                                        Indian
                                                                    </a>
                                                                </li>
                                                                <li class="mobile-nav__item">
                                                                    <a href="collections/nose-rings-diamond.html"
                                                                        class="mobile-nav__link">
                                                                        Diamond
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="mobile-nav__item">
                                                    <div class="mobile-nav__child-item"><a
                                                            href="collections/pendant-sets-1.html"
                                                            class="mobile-nav__link"
                                                            id="Sublabel-collections-pendant-sets-110">
                                                            Pendant Sets
                                                        </a><button type="button"
                                                            aria-controls="Sublinklist-4-collections-pendant-sets-110"
                                                            aria-labelledby="Sublabel-collections-pendant-sets-110"
                                                            class="collapsible-trigger"><span
                                                                class="collapsible-trigger__icon collapsible-trigger__icon--circle collapsible-trigger__icon--open"
                                                                role="presentation">
                                                                <svg aria-hidden="true" focusable="false"
                                                                    role="presentation"
                                                                    class="icon icon--wide icon-chevron-down"
                                                                    viewBox="0 0 28 16">
                                                                    <path d="M1.57 1.59l12.76 12.77L27.1 1.59"
                                                                        stroke-width="2" stroke="#000"
                                                                        fill="none" fill-rule="evenodd" />
                                                                </svg>
                                                            </span>
                                                        </button></div>
                                                    <div id="Sublinklist-4-collections-pendant-sets-110"
                                                        aria-labelledby="Sublabel-collections-pendant-sets-110"
                                                        class="mobile-nav__sublist collapsible-content collapsible-content--all">
                                                        <div class="collapsible-content__inner">
                                                            <ul class="mobile-nav__grandchildlist">
                                                                <li class="mobile-nav__item">
                                                                    <a href="collections/pendent-sets-diamond.html"
                                                                        class="mobile-nav__link">
                                                                        Diamond
                                                                    </a>
                                                                </li>
                                                                <li class="mobile-nav__item">
                                                                    <a href="collections/pendent-sets-indian.html"
                                                                        class="mobile-nav__link">
                                                                        Indian
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="mobile-nav__item">
                                                    <div class="mobile-nav__child-item"><a
                                                            href="collections/earchains.html" class="mobile-nav__link"
                                                            id="Sublabel-collections-earchains11">
                                                            EarChains
                                                        </a></div>
                                                </li>
                                                <li class="mobile-nav__item">
                                                    <div class="mobile-nav__child-item"><a
                                                            href="collections/hand-harness-1.html"
                                                            class="mobile-nav__link"
                                                            id="Sublabel-collections-hand-harness-112">
                                                            Hand Harness
                                                        </a></div>
                                                </li>
                                                <li class="mobile-nav__item">
                                                    <div class="mobile-nav__child-item"><a
                                                            href="collections/semi-precious.html"
                                                            class="mobile-nav__link"
                                                            id="Sublabel-collections-semi-precious13">
                                                            Semi Precious
                                                        </a></div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </li>
                                <li class="mobile-nav__item appear-animation appear-delay-6">
                                    <div class="mobile-nav__has-sublist"><button type="button"
                                            aria-controls="Linklist-5"
                                            class="mobile-nav__link--button mobile-nav__link--top-level collapsible-trigger collapsible--auto-height">
                                            <span class="mobile-nav__faux-link">
                                                Collections
                                            </span>
                                            <div class="mobile-nav__toggle">
                                                <span class="faux-button"><span
                                                        class="collapsible-trigger__icon collapsible-trigger__icon--open"
                                                        role="presentation">
                                                        <svg aria-hidden="true" focusable="false" role="presentation"
                                                            class="icon icon--wide icon-chevron-down"
                                                            viewBox="0 0 28 16">
                                                            <path d="M1.57 1.59l12.76 12.77L27.1 1.59" stroke-width="2"
                                                                stroke="#000" fill="none" fill-rule="evenodd" />
                                                        </svg>
                                                    </span>
                                                </span>
                                            </div>
                                        </button></div>
                                    <div id="Linklist-5"
                                        class="mobile-nav__sublist collapsible-content collapsible-content--all">
                                        <div class="collapsible-content__inner">
                                            <ul class="mobile-nav__sublist">
                                                <li class="mobile-nav__item">
                                                    <div class="mobile-nav__child-item"><a
                                                            href="collections/almaaz-1.html" class="mobile-nav__link"
                                                            id="Sublabel-collections-almaaz-11">
                                                            Almaaz
                                                        </a></div>
                                                </li>
                                                <li class="mobile-nav__item">
                                                    <div class="mobile-nav__child-item"><a
                                                            href="collections/jadau-1.html" class="mobile-nav__link"
                                                            id="Sublabel-collections-jadau-12">
                                                            Jadau
                                                        </a></div>
                                                </li>
                                                <li class="mobile-nav__item">
                                                    <div class="mobile-nav__child-item"><a
                                                            href="collections/metallic-dust-1.html"
                                                            class="mobile-nav__link"
                                                            id="Sublabel-collections-metallic-dust-13">
                                                            Metallic Dust
                                                        </a></div>
                                                </li>
                                                <li class="mobile-nav__item">
                                                    <div class="mobile-nav__child-item"><a
                                                            href="collections/rajwada-1.html" class="mobile-nav__link"
                                                            id="Sublabel-collections-rajwada-14">
                                                            Rajwada
                                                        </a></div>
                                                </li>
                                                <li class="mobile-nav__item">
                                                    <div class="mobile-nav__child-item"><a
                                                            href="collections/banjaran.html" class="mobile-nav__link"
                                                            id="Sublabel-collections-banjaran5">
                                                            Banjaran
                                                        </a></div>
                                                </li>
                                                <li class="mobile-nav__item">
                                                    <div class="mobile-nav__child-item"><a
                                                            href="collections/lala-land.html" class="mobile-nav__link"
                                                            id="Sublabel-collections-lala-land6">
                                                            La La Land
                                                        </a></div>
                                                </li>
                                                <li class="mobile-nav__item">
                                                    <div class="mobile-nav__child-item"><a
                                                            href="collections/piece-of-art.html"
                                                            class="mobile-nav__link"
                                                            id="Sublabel-collections-piece-of-art7">
                                                            Piece Of Art
                                                        </a></div>
                                                </li>
                                                <li class="mobile-nav__item">
                                                    <div class="mobile-nav__child-item"><a
                                                            href="collections/victorian-polish-antique-gold.html"
                                                            class="mobile-nav__link"
                                                            id="Sublabel-collections-victorian-polish-antique-gold8">
                                                            Victorian Polish / Antique Gold
                                                        </a></div>
                                                </li>
                                                <li class="mobile-nav__item">
                                                    <div class="mobile-nav__child-item"><a
                                                            href="collections/rangnasheen-collection.html"
                                                            class="mobile-nav__link"
                                                            id="Sublabel-collections-rangnasheen-collection9">
                                                            Rangnasheen Collection
                                                        </a></div>
                                                </li>
                                                <li class="mobile-nav__item">
                                                    <div class="mobile-nav__child-item"><a
                                                            href="collections/sone-pe-suhaga-collection.html"
                                                            class="mobile-nav__link"
                                                            id="Sublabel-collections-sone-pe-suhaga-collection10">
                                                            Sone Pe Suhaga Collection
                                                        </a></div>
                                                </li>
                                                <li class="mobile-nav__item">
                                                    <div class="mobile-nav__child-item"><a
                                                            href="collections/gemzee-collection.html"
                                                            class="mobile-nav__link"
                                                            id="Sublabel-collections-gemzee-collection11">
                                                            GemZee Collection
                                                        </a></div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </li>
                                <li class="mobile-nav__item appear-animation appear-delay-7">
                                    <div class="mobile-nav__has-sublist"><a href="collections/sale-1.html"
                                            class="mobile-nav__link mobile-nav__link--top-level"
                                            id="Label-collections-sale-16">
                                            Exclusive Sale
                                        </a>
                                        <div class="mobile-nav__toggle">
                                            <button type="button" aria-controls="Linklist-collections-sale-16"
                                                aria-labelledby="Label-collections-sale-16"
                                                class="collapsible-trigger collapsible--auto-height"><span
                                                    class="collapsible-trigger__icon collapsible-trigger__icon--open"
                                                    role="presentation">
                                                    <svg aria-hidden="true" focusable="false" role="presentation"
                                                        class="icon icon--wide icon-chevron-down" viewBox="0 0 28 16">
                                                        <path d="M1.57 1.59l12.76 12.77L27.1 1.59" stroke-width="2"
                                                            stroke="#000" fill="none" fill-rule="evenodd" />
                                                    </svg>
                                                </span>
                                            </button>
                                        </div>
                                    </div>
                                    <div id="Linklist-collections-sale-16"
                                        class="mobile-nav__sublist collapsible-content collapsible-content--all">
                                        <div class="collapsible-content__inner">
                                            <ul class="mobile-nav__sublist">
                                                <li class="mobile-nav__item">
                                                    <div class="mobile-nav__child-item"><a
                                                            href="collections/sale-earrings.html"
                                                            class="mobile-nav__link"
                                                            id="Sublabel-collections-sale-earrings1">
                                                            Earring
                                                        </a><button type="button"
                                                            aria-controls="Sublinklist-collections-sale-16-collections-sale-earrings1"
                                                            aria-labelledby="Sublabel-collections-sale-earrings1"
                                                            class="collapsible-trigger"><span
                                                                class="collapsible-trigger__icon collapsible-trigger__icon--circle collapsible-trigger__icon--open"
                                                                role="presentation">
                                                                <svg aria-hidden="true" focusable="false"
                                                                    role="presentation"
                                                                    class="icon icon--wide icon-chevron-down"
                                                                    viewBox="0 0 28 16">
                                                                    <path d="M1.57 1.59l12.76 12.77L27.1 1.59"
                                                                        stroke-width="2" stroke="#000"
                                                                        fill="none" fill-rule="evenodd" />
                                                                </svg>
                                                            </span>
                                                        </button></div>
                                                    <div id="Sublinklist-collections-sale-16-collections-sale-earrings1"
                                                        aria-labelledby="Sublabel-collections-sale-earrings1"
                                                        class="mobile-nav__sublist collapsible-content collapsible-content--all">
                                                        <div class="collapsible-content__inner">
                                                            <ul class="mobile-nav__grandchildlist">
                                                                <li class="mobile-nav__item">
                                                                    <a href="collections/sale-earring-diamond.html"
                                                                        class="mobile-nav__link">
                                                                        Diamond
                                                                    </a>
                                                                </li>
                                                                <li class="mobile-nav__item">
                                                                    <a href="collections/sale-earring-indian.html"
                                                                        class="mobile-nav__link">
                                                                        Indian
                                                                    </a>
                                                                </li>
                                                                <li class="mobile-nav__item">
                                                                    <a href="collections/sale-earring-western.html"
                                                                        class="mobile-nav__link">
                                                                        Western
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="mobile-nav__item">
                                                    <div class="mobile-nav__child-item"><a
                                                            href="collections/sale-jewellery-set.html"
                                                            class="mobile-nav__link"
                                                            id="Sublabel-collections-sale-jewellery-set2">
                                                            Jewellery Set / Necklace
                                                        </a><button type="button"
                                                            aria-controls="Sublinklist-collections-sale-16-collections-sale-jewellery-set2"
                                                            aria-labelledby="Sublabel-collections-sale-jewellery-set2"
                                                            class="collapsible-trigger"><span
                                                                class="collapsible-trigger__icon collapsible-trigger__icon--circle collapsible-trigger__icon--open"
                                                                role="presentation">
                                                                <svg aria-hidden="true" focusable="false"
                                                                    role="presentation"
                                                                    class="icon icon--wide icon-chevron-down"
                                                                    viewBox="0 0 28 16">
                                                                    <path d="M1.57 1.59l12.76 12.77L27.1 1.59"
                                                                        stroke-width="2" stroke="#000"
                                                                        fill="none" fill-rule="evenodd" />
                                                                </svg>
                                                            </span>
                                                        </button></div>
                                                    <div id="Sublinklist-collections-sale-16-collections-sale-jewellery-set2"
                                                        aria-labelledby="Sublabel-collections-sale-jewellery-set2"
                                                        class="mobile-nav__sublist collapsible-content collapsible-content--all">
                                                        <div class="collapsible-content__inner">
                                                            <ul class="mobile-nav__grandchildlist">
                                                                <li class="mobile-nav__item">
                                                                    <a href="collections/sale-sets-diamond.html"
                                                                        class="mobile-nav__link">
                                                                        Diamond
                                                                    </a>
                                                                </li>
                                                                <li class="mobile-nav__item">
                                                                    <a href="collections/sale-sets-indian.html"
                                                                        class="mobile-nav__link">
                                                                        Indian
                                                                    </a>
                                                                </li>
                                                                <li class="mobile-nav__item">
                                                                    <a href="collections/sale-sets-western.html"
                                                                        class="mobile-nav__link">
                                                                        Western
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="mobile-nav__item">
                                                    <div class="mobile-nav__child-item"><a
                                                            href="collections/sale-rings.html"
                                                            class="mobile-nav__link"
                                                            id="Sublabel-collections-sale-rings3">
                                                            Ring
                                                        </a><button type="button"
                                                            aria-controls="Sublinklist-collections-sale-16-collections-sale-rings3"
                                                            aria-labelledby="Sublabel-collections-sale-rings3"
                                                            class="collapsible-trigger"><span
                                                                class="collapsible-trigger__icon collapsible-trigger__icon--circle collapsible-trigger__icon--open"
                                                                role="presentation">
                                                                <svg aria-hidden="true" focusable="false"
                                                                    role="presentation"
                                                                    class="icon icon--wide icon-chevron-down"
                                                                    viewBox="0 0 28 16">
                                                                    <path d="M1.57 1.59l12.76 12.77L27.1 1.59"
                                                                        stroke-width="2" stroke="#000"
                                                                        fill="none" fill-rule="evenodd" />
                                                                </svg>
                                                            </span>
                                                        </button></div>
                                                    <div id="Sublinklist-collections-sale-16-collections-sale-rings3"
                                                        aria-labelledby="Sublabel-collections-sale-rings3"
                                                        class="mobile-nav__sublist collapsible-content collapsible-content--all">
                                                        <div class="collapsible-content__inner">
                                                            <ul class="mobile-nav__grandchildlist">
                                                                <li class="mobile-nav__item">
                                                                    <a href="collections/sale-ring-diamond.html"
                                                                        class="mobile-nav__link">
                                                                        Diamond
                                                                    </a>
                                                                </li>
                                                                <li class="mobile-nav__item">
                                                                    <a href="collections/sale-ring-indian.html"
                                                                        class="mobile-nav__link">
                                                                        Indian
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="mobile-nav__item">
                                                    <div class="mobile-nav__child-item"><a
                                                            href="collections/sale-bracelet.html"
                                                            class="mobile-nav__link"
                                                            id="Sublabel-collections-sale-bracelet4">
                                                            Bracelets
                                                        </a><button type="button"
                                                            aria-controls="Sublinklist-collections-sale-16-collections-sale-bracelet4"
                                                            aria-labelledby="Sublabel-collections-sale-bracelet4"
                                                            class="collapsible-trigger"><span
                                                                class="collapsible-trigger__icon collapsible-trigger__icon--circle collapsible-trigger__icon--open"
                                                                role="presentation">
                                                                <svg aria-hidden="true" focusable="false"
                                                                    role="presentation"
                                                                    class="icon icon--wide icon-chevron-down"
                                                                    viewBox="0 0 28 16">
                                                                    <path d="M1.57 1.59l12.76 12.77L27.1 1.59"
                                                                        stroke-width="2" stroke="#000"
                                                                        fill="none" fill-rule="evenodd" />
                                                                </svg>
                                                            </span>
                                                        </button></div>
                                                    <div id="Sublinklist-collections-sale-16-collections-sale-bracelet4"
                                                        aria-labelledby="Sublabel-collections-sale-bracelet4"
                                                        class="mobile-nav__sublist collapsible-content collapsible-content--all">
                                                        <div class="collapsible-content__inner">
                                                            <ul class="mobile-nav__grandchildlist">
                                                                <li class="mobile-nav__item">
                                                                    <a href="collections/sale-bracelets-diamond.html"
                                                                        class="mobile-nav__link">
                                                                        Diamond
                                                                    </a>
                                                                </li>
                                                                <li class="mobile-nav__item">
                                                                    <a href="collections/sale-bracelets-indian.html"
                                                                        class="mobile-nav__link">
                                                                        Indian
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="mobile-nav__item">
                                                    <div class="mobile-nav__child-item"><a
                                                            href="collections/sale-headgear.html"
                                                            class="mobile-nav__link"
                                                            id="Sublabel-collections-sale-headgear5">
                                                            Headgear
                                                        </a></div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </li>
                                <li class="mobile-nav__item appear-animation appear-delay-8">
                                    <div class="mobile-nav__has-sublist"><button type="button"
                                            aria-controls="Linklist-7"
                                            class="mobile-nav__link--button mobile-nav__link--top-level collapsible-trigger collapsible--auto-height">
                                            <span class="mobile-nav__faux-link">
                                                Spotted
                                            </span>
                                            <div class="mobile-nav__toggle">
                                                <span class="faux-button"><span
                                                        class="collapsible-trigger__icon collapsible-trigger__icon--open"
                                                        role="presentation">
                                                        <svg aria-hidden="true" focusable="false" role="presentation"
                                                            class="icon icon--wide icon-chevron-down"
                                                            viewBox="0 0 28 16">
                                                            <path d="M1.57 1.59l12.76 12.77L27.1 1.59" stroke-width="2"
                                                                stroke="#000" fill="none" fill-rule="evenodd" />
                                                        </svg>
                                                    </span>
                                                </span>
                                            </div>
                                        </button></div>
                                    <div id="Linklist-7"
                                        class="mobile-nav__sublist collapsible-content collapsible-content--all">
                                        <div class="collapsible-content__inner">
                                            <ul class="mobile-nav__sublist">
                                                <li class="mobile-nav__item">
                                                    <div class="mobile-nav__child-item"><a href="pages/press.html"
                                                            class="mobile-nav__link" id="Sublabel-pages-press1">
                                                            Press
                                                        </a></div>
                                                </li>
                                                <li class="mobile-nav__item">
                                                    <div class="mobile-nav__child-item"><a href="pages/tribe.html"
                                                            class="mobile-nav__link" id="Sublabel-pages-tribe2">
                                                            Shopkart Tribe
                                                        </a></div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </li>
                                <li class="mobile-nav__item appear-animation appear-delay-9"><a
                                        href="products/Shopkart-gift-card.html"
                                        class="mobile-nav__link mobile-nav__link--top-level">Gift Card</a></li>
                                
                                <li class="mobile-nav__item mobile-nav__item--secondary">
                                    <div class="grid">
                                        <div class="grid__item one-half appear-animation appear-delay-11">
                                            <a href="account/login4236.html" class="mobile-nav__link">Log in
                                            </a>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                            <ul class="mobile-nav__social appear-animation appear-delay-12">
                                <li class="mobile-nav__social-item">
                                    <a target="_blank" rel="noopener"
                                        href="https://www.instagram.com/Shopkart_designs/"
                                        title="Shopkart on Instagram">
                                        <svg aria-hidden="true" focusable="false" role="presentation"
                                            class="icon icon-instagram" viewBox="0 0 32 32">
                                            <path fill="#444"
                                                d="M16 3.094c4.206 0 4.7.019 6.363.094 1.538.069 2.369.325 2.925.544.738.287 1.262.625 1.813 1.175s.894 1.075 1.175 1.813c.212.556.475 1.387.544 2.925.075 1.662.094 2.156.094 6.363s-.019 4.7-.094 6.363c-.069 1.538-.325 2.369-.544 2.925-.288.738-.625 1.262-1.175 1.813s-1.075.894-1.813 1.175c-.556.212-1.387.475-2.925.544-1.663.075-2.156.094-6.363.094s-4.7-.019-6.363-.094c-1.537-.069-2.369-.325-2.925-.544-.737-.288-1.263-.625-1.813-1.175s-.894-1.075-1.175-1.813c-.212-.556-.475-1.387-.544-2.925-.075-1.663-.094-2.156-.094-6.363s.019-4.7.094-6.363c.069-1.537.325-2.369.544-2.925.287-.737.625-1.263 1.175-1.813s1.075-.894 1.813-1.175c.556-.212 1.388-.475 2.925-.544 1.662-.081 2.156-.094 6.363-.094zm0-2.838c-4.275 0-4.813.019-6.494.094-1.675.075-2.819.344-3.819.731-1.037.4-1.913.944-2.788 1.819S1.486 4.656 1.08 5.688c-.387 1-.656 2.144-.731 3.825-.075 1.675-.094 2.213-.094 6.488s.019 4.813.094 6.494c.075 1.675.344 2.819.731 3.825.4 1.038.944 1.913 1.819 2.788s1.756 1.413 2.788 1.819c1 .387 2.144.656 3.825.731s2.213.094 6.494.094 4.813-.019 6.494-.094c1.675-.075 2.819-.344 3.825-.731 1.038-.4 1.913-.944 2.788-1.819s1.413-1.756 1.819-2.788c.387-1 .656-2.144.731-3.825s.094-2.212.094-6.494-.019-4.813-.094-6.494c-.075-1.675-.344-2.819-.731-3.825-.4-1.038-.944-1.913-1.819-2.788s-1.756-1.413-2.788-1.819c-1-.387-2.144-.656-3.825-.731C20.812.275 20.275.256 16 .256z" />
                                            <path fill="#444"
                                                d="M16 7.912a8.088 8.088 0 0 0 0 16.175c4.463 0 8.087-3.625 8.087-8.088s-3.625-8.088-8.088-8.088zm0 13.338a5.25 5.25 0 1 1 0-10.5 5.25 5.25 0 1 1 0 10.5zM26.294 7.594a1.887 1.887 0 1 1-3.774.002 1.887 1.887 0 0 1 3.774-.003z" />
                                        </svg>
                                        <span class="icon__fallback-text">Instagram</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div id="CartDrawer" class="drawer drawer--right">
                    <form id="CartDrawerForm" action="https://Shopkart.in/cart" method="post" novalidate
                        class="drawer__contents">
                        <div class="drawer__fixed-header">
                            <div class="drawer__header appear-animation appear-delay-1">
                                <div class="h2 drawer__title">Cart</div>
                                <div class="drawer__close">
                                    <button type="button" class="drawer__close-button js-drawer-close">
                                        <svg aria-hidden="true" focusable="false" role="presentation"
                                            class="icon icon-close" viewBox="0 0 64 64">
                                            <path d="M19 17.61l27.12 27.13m0-27.12L19 44.74" />
                                        </svg>
                                        <span class="icon__fallback-text">Close cart</span>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div class="drawer__inner">
                            <div class="drawer__scrollable">
                                <div data-products class="appear-animation appear-delay-2"></div>


                                <div class="appear-animation appear-delay-3">
                                    <label for="CartNoteDrawer">Order note</label>
                                    <textarea name="note" class="input-full cart-notes" id="CartNoteDrawer"></textarea>
                                </div>

                            </div>

                            <div class="drawer__footer appear-animation appear-delay-4">
                                <div data-discounts>

                                </div>

                                <div class="cart__item-sub cart__item-row">
                                    <div class="ajaxcart__subtotal">Subtotal</div>
                                    <div data-subtotal>Rs. 0</div>
                                </div>

                                <div class="cart__item-row text-center">
                                    <small>
                                        All Taxes Included. <br />
                                    </small>
                                </div>



                                <div class="cart__checkout-wrapper">
                                    <button type="submit" name="checkout" data-terms-required="false"
                                        class="btn cart__checkout">
                                        Check out
                                    </button>



                                </div>
                            </div>
                        </div>

                        <div class="drawer__cart-empty appear-animation appear-delay-2">
                            <div class="drawer__scrollable">
                                Your cart is currently empty.
                            </div>
                        </div>
                    </form>
                </div>


                <div data-section-id="header" data-section-type="header">
                    <div class="toolbar small--hide">
                        <div class="page-width">
                            <div class="toolbar__content"></div>

                        </div>
                    </div>
                    <div class="header-sticky-wrapper">
                        <div id="HeaderWrapper" class="header-wrapper">
                            <header id="SiteHeader" class="site-header" data-sticky="false" data-overlay="false">
                                <div class="page-width">
                                    <div class="header-layout header-layout--center" data-logo-align="center">
                                        <div class="header-item header-item--left header-item--navigation">
                                            <div class="site-nav medium-up--hide">
                                                <button type="button"
                                                    class="site-nav__link site-nav__link--icon js-drawer-open-nav"
                                                    aria-controls="NavDrawer">
                                                    <svg aria-hidden="true" focusable="false" role="presentation"
                                                        class="icon icon-hamburger" viewBox="0 0 64 64">
                                                        <path d="M7 15h51M7 32h43M7 49h51" />
                                                    </svg>
                                                    <span class="icon__fallback-text">Site navigation</span>
                                                </button>
                                            </div>
                                        </div>
                                        <div class="header-item header-item--logo">

                                            <h1 class="site-header__logo" itemscope
                                                itemtype="http://schema.org/Organization">
                                                <span class="visually-hidden">ShopKart24</span>
                                                <a href="<?php echo e(url('/')); ?>" itemprop="url"
                                                    class="site-header__logo-link">
                                                    <img loading="lazy" class="small--hide"
                                                        src="<?php echo e(url('frontend/img/Logo.png')); ?>" alt="ShopKart24"
                                                        itemprop="logo">
                                                    <img loading="lazy" class="medium-up--hide"
                                                        src="<?php echo e(url('frontend/img/Logo.png')); ?>" alt="ShopKart24">
                                                </a>
                                            </h1>

                                        </div>
                                        <div class="header-item header-item--icons">


                                            <div class="st-search-bar st-hidden-sm">
                                                <input type="text" name="q" placeholder="Search..."
                                                    value="" autocapitalize="off" autocomplete="off"
                                                    autocorrect="off">
                                                <span class="input-close-btn" style="display: none;"></span>




                                                <div id="trending-autocomplete" v-cloak v-show="showTrendingSearch"
                                                    class="st-trending-box" v-cloak>
                                                    <div class="st-container-trend"
                                                        v-show="isTrendingVisible && trending_results.length>0"
                                                        style="display: block;">
                                                        <div id="st-before-search">
                                                            <div class="st-trending-header">
                                                                <svg viewBox="0 0 500 500" width="18"
                                                                    height="18" fill="#f94" data-v-26850a1a=""
                                                                    class="st-icon">
                                                                    <svg xmlns="http://www.w3.org/2000/svg"
                                                                        height="500" viewBox="0 0 48 48"
                                                                        width="500" data-v-26850a1a="">
                                                                        <path
                                                                            d="M32 12l4.59 4.59-9.76 9.75-8-8-14.83 14.83 2.83 2.83 12-12 8 8 12.58-12.59 4.59 4.59v-12z"
                                                                            data-v-26850a1a=""></path>
                                                                        <path d="M0 0h48v48h-48z" fill="none"
                                                                            data-v-26850a1a=""></path>
                                                                    </svg>
                                                                </svg>
                                                                <span class="st-heading-text"><span
                                                                        class="recent-icon hidden-desktop"></span>Trending
                                                                    Searches</span>
                                                            </div>
                                                            <ul class="st-trending-list">
                                                                <li class="st-trending-label"
                                                                    v-for="item in trending_results"
                                                                    :key="item"
                                                                    v-show="item.showInSuggestion"
                                                                    @click.stop="actionOnTrendingClick(item)">
                                                                    <svg viewBox="0 0 500 500" width="18"
                                                                        height="18" fill="#f94"
                                                                        data-v-26850a1a="" class="st-icon">
                                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                                            height="500" viewBox="0 0 48 48"
                                                                            width="500" data-v-26850a1a="">
                                                                            <path
                                                                                d="M32 12l4.59 4.59-9.76 9.75-8-8-14.83 14.83 2.83 2.83 12-12 8 8 12.58-12.59 4.59 4.59v-12z"
                                                                                data-v-26850a1a=""></path>
                                                                            <path d="M0 0h48v48h-48z" fill="none"
                                                                                data-v-26850a1a=""></path>
                                                                        </svg>
                                                                    </svg>

                                                                </li>
                                                            </ul>
                                                            <div class="st-autocomplete-footer"></div>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                            <div class="site-nav">
                                                <div class="site-nav__icons"><a
                                                        class="site-nav__link site-nav__link--icon small--hide"
                                                        href="<?php echo e(url('/signin')); ?>">
                                                        <svg aria-hidden="true" focusable="false" role="presentation"
                                                            class="icon icon-user" viewBox="0 0 64 64">
                                                            <path
                                                                d="M35 39.84v-2.53c3.3-1.91 6-6.66 6-11.41 0-7.63 0-13.82-9-13.82s-9 6.19-9 13.82c0 4.75 2.7 9.51 6 11.41v2.53c-10.18.85-18 6-18 12.16h42c0-6.19-7.82-11.31-18-12.16z" />
                                                        </svg>
                                                        <span class="icon__fallback-text">Log in
                                                        </span>
                                                    </a>
                                                    <a href="<?php echo e(url('/cart')); ?>"
                                                        class="site-nav__link site-nav__link--icon js-drawer-open-cart"
                                                        aria-controls="CartDrawer" data-icon="cart">
                                                        <span class="cart-link"><svg aria-hidden="true"
                                                                focusable="false" role="presentation"
                                                                class="icon icon-cart" viewBox="0 0 64 64">
                                                                <path fill="none"
                                                                    d="M14 17.44h46.79l-7.94 25.61H20.96l-9.65-35.1H3" />
                                                                <circle cx="27" cy="53" r="2" />
                                                                <circle cx="47" cy="53" r="2" />
                                                            </svg><span class="icon__fallback-text">Cart</span>
                                                            <span id="CartBubble" class="cart-link__bubble"></span>
                                                        </span>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="text-center">
                                        <ul class="site-nav site-navigation small--hide" role="navigation"
                                            aria-label="Primary">
                                            <li class="site-nav__item site-nav__expanded-item">

                                                <a href="<?php echo e(url('/')); ?>"
                                                    class="site-nav__link site-nav__link--underline">
                                                    Home
                                                </a>
                                            </li>
                                            <li class="site-nav__item site-nav__expanded-item">

                                                <a href="<?php echo e(('/about')); ?>"
                                                    class="site-nav__link site-nav__link--underline">
                                                    About Us
                                                </a>
                                            </li>
                                         
                                            <li class="site-nav__item site-nav__expanded-item site-nav--has-dropdown site-nav--is-megamenu"
                                                aria-haspopup="true">

                                                <a href="<?php echo e(url('/jewelry')); ?>"
                                                    class="site-nav__link site-nav__link--underline site-nav__link--has-dropdown">
                                                    Shop Jewellery
                                                </a>
                                                <!--<div class="site-nav__dropdown megamenu text-left">-->
                                                <!--    <div class="page-width">-->
                                                <!--        <div class="grid grid--center">-->
                                                <!--            <div-->
                                                <!--                class="grid__item medium-up--one-fifth appear-animation appear-delay-1">-->
                                                <!--                <div class="h5">-->
                                                <!--                    <a href="collections/ginni-gift-box.html"-->
                                                <!--                        class="site-nav__dropdown-link site-nav__dropdown-link--top-level">Ginni-->
                                                <!--                        / Gift-->
                                                <!--                        Box</a>-->
                                                <!--                </div>-->
                                                <!--            </div>-->
                                                <!--            <div-->
                                                <!--                class="grid__item medium-up--one-fifth appear-animation appear-delay-2">-->
                                                <!--                <div class="h5">-->
                                                <!--                    <a href="collections/earrings-1.html"-->
                                                <!--                        class="site-nav__dropdown-link site-nav__dropdown-link--top-level">Earrings</a>-->
                                                <!--                </div>-->
                                                <!--                <div>-->
                                                <!--                    <a href="collections/earrings-diamond.html"-->
                                                <!--                        class="site-nav__dropdown-link">-->
                                                <!--                        Diamond-->
                                                <!--                    </a>-->
                                                <!--                </div>-->
                                                <!--                <div>-->
                                                <!--                    <a href="collections/earrings-indian.html"-->
                                                <!--                        class="site-nav__dropdown-link">-->
                                                <!--                        Indian-->
                                                <!--                    </a>-->
                                                <!--                </div>-->
                                                <!--                <div>-->
                                                <!--                    <a href="collections/earrings-tribal.html"-->
                                                <!--                        class="site-nav__dropdown-link">-->
                                                <!--                        Tribal-->
                                                <!--                    </a>-->
                                                <!--                </div>-->
                                                <!--                <div>-->
                                                <!--                    <a href="collections/earrings-party-wear.html"-->
                                                <!--                        class="site-nav__dropdown-link">-->
                                                <!--                        Western & Party Wear-->
                                                <!--                    </a>-->
                                                <!--                </div>-->
                                                <!--            </div>-->
                                                <!--            <div-->
                                                <!--                class="grid__item medium-up--one-fifth appear-animation appear-delay-3">-->
                                                <!--                <div class="h5">-->
                                                <!--                    <a href="collections/jewellery-sets-1.html"-->
                                                <!--                        class="site-nav__dropdown-link site-nav__dropdown-link--top-level">Jewellery-->
                                                <!--                        Sets</a>-->
                                                <!--                </div>-->
                                                <!--                <div>-->
                                                <!--                    <a href="collections/jewellery-sets-diamond.html"-->
                                                <!--                        class="site-nav__dropdown-link">-->
                                                <!--                        Diamond-->
                                                <!--                    </a>-->
                                                <!--                </div>-->
                                                <!--                <div>-->
                                                <!--                    <a href="collections/jewellery-sets-indian.html"-->
                                                <!--                        class="site-nav__dropdown-link">-->
                                                <!--                        Indian-->
                                                <!--                    </a>-->
                                                <!--                </div>-->
                                                <!--            </div>-->
                                                <!--            <div-->
                                                <!--                class="grid__item medium-up--one-fifth appear-animation appear-delay-4">-->
                                                <!--                <div class="h5">-->
                                                <!--                    <a href="collections/bracelet-bangles-1.html"-->
                                                <!--                        class="site-nav__dropdown-link site-nav__dropdown-link--top-level">Bracelet/Bangles</a>-->
                                                <!--                </div>-->
                                                <!--                <div>-->
                                                <!--                    <a href="collections/bracelet-bangles-diamond.html"-->
                                                <!--                        class="site-nav__dropdown-link">-->
                                                <!--                        Diamond-->
                                                <!--                    </a>-->
                                                <!--                </div>-->
                                                <!--                <div>-->
                                                <!--                    <a href="collections/bracelet-bangles-indian.html"-->
                                                <!--                        class="site-nav__dropdown-link">-->
                                                <!--                        Indian-->
                                                <!--                    </a>-->
                                                <!--                </div>-->
                                                <!--                <div>-->
                                                <!--                    <a href="collections/bracelet-bangles-contemporary.html"-->
                                                <!--                        class="site-nav__dropdown-link">-->
                                                <!--                        Contemporary-->
                                                <!--                    </a>-->
                                                <!--                </div>-->
                                                <!--            </div>-->
                                                <!--            <div-->
                                                <!--                class="grid__item medium-up--one-fifth appear-animation appear-delay-5">-->
                                                <!--                <div class="h5">-->
                                                <!--                    <a href="collections/rings-1.html"-->
                                                <!--                        class="site-nav__dropdown-link site-nav__dropdown-link--top-level">Rings</a>-->
                                                <!--                </div>-->
                                                <!--                <div>-->
                                                <!--                    <a href="collections/rings-diamond.html"-->
                                                <!--                        class="site-nav__dropdown-link">-->
                                                <!--                        Diamond-->
                                                <!--                    </a>-->
                                                <!--                </div>-->
                                                <!--                <div>-->
                                                <!--                    <a href="collections/rings-indian.html"-->
                                                <!--                        class="site-nav__dropdown-link">-->
                                                <!--                        Indian-->
                                                <!--                    </a>-->
                                                <!--                </div>-->
                                                <!--                <div>-->
                                                <!--                    <a href="collections/rings-contemporary.html"-->
                                                <!--                        class="site-nav__dropdown-link">-->
                                                <!--                        Contemporary-->
                                                <!--                    </a>-->
                                                <!--                </div>-->
                                                <!--            </div>-->
                                                <!--            <div-->
                                                <!--                class="grid__item medium-up--one-fifth appear-animation appear-delay-6">-->
                                                <!--                <div class="h5">-->
                                                <!--                    <a href="collections/headgears.html"-->
                                                <!--                        class="site-nav__dropdown-link site-nav__dropdown-link--top-level">Headgear</a>-->
                                                <!--                </div>-->
                                                <!--                <div>-->
                                                <!--                    <a href="collections/headgears-indian.html"-->
                                                <!--                        class="site-nav__dropdown-link">-->
                                                <!--                        Indian-->
                                                <!--                    </a>-->
                                                <!--                </div>-->
                                                <!--                <div>-->
                                                <!--                    <a href="collections/headgears-diamond.html"-->
                                                <!--                        class="site-nav__dropdown-link">-->
                                                <!--                        Diamond-->
                                                <!--                    </a>-->
                                                <!--                </div>-->
                                                <!--            </div>-->
                                                <!--            <div-->
                                                <!--                class="grid__item medium-up--one-fifth appear-animation appear-delay-7">-->
                                                <!--                <div class="h5">-->
                                                <!--                    <a href="collections/necklace-mangalsutra.html"-->
                                                <!--                        class="site-nav__dropdown-link site-nav__dropdown-link--top-level">Mangalsutra</a>-->
                                                <!--                </div>-->
                                                <!--                <div>-->
                                                <!--                    <a href="collections/necklace-mangalsutra-bracelets.html"-->
                                                <!--                        class="site-nav__dropdown-link">-->
                                                <!--                        Bracelets-->
                                                <!--                    </a>-->
                                                <!--                </div>-->
                                                <!--                <div>-->
                                                <!--                    <a href="collections/mangalsutra-necklaces.html"-->
                                                <!--                        class="site-nav__dropdown-link">-->
                                                <!--                        Necklaces-->
                                                <!--                    </a>-->
                                                <!--                </div>-->
                                                <!--            </div>-->
                                                <!--            <div-->
                                                <!--                class="grid__item medium-up--one-fifth appear-animation appear-delay-8">-->
                                                <!--                <div class="h5">-->
                                                <!--                    <a href="collections/necklace-1.html"-->
                                                <!--                        class="site-nav__dropdown-link site-nav__dropdown-link--top-level">Necklace</a>-->
                                                <!--                </div>-->
                                                <!--                <div>-->
                                                <!--                    <a href="collections/necklace-diamond.html"-->
                                                <!--                        class="site-nav__dropdown-link">-->
                                                <!--                        Diamond-->
                                                <!--                    </a>-->
                                                <!--                </div>-->
                                                <!--                <div>-->
                                                <!--                    <a href="collections/necklace-indian.html"-->
                                                <!--                        class="site-nav__dropdown-link">-->
                                                <!--                        Indian-->
                                                <!--                    </a>-->
                                                <!--                </div>-->
                                                <!--                <div>-->
                                                <!--                    <a href="collections/necklace-contemporary.html"-->
                                                <!--                        class="site-nav__dropdown-link">-->
                                                <!--                        Contemporary-->
                                                <!--                    </a>-->
                                                <!--                </div>-->
                                                <!--            </div>-->
                                                <!--            <div-->
                                                <!--                class="grid__item medium-up--one-fifth appear-animation appear-delay-9">-->
                                                <!--                <div class="h5">-->
                                                <!--                    <a href="collections/nose-rings-1.html"-->
                                                <!--                        class="site-nav__dropdown-link site-nav__dropdown-link--top-level">Nose-->
                                                <!--                        Rings</a>-->
                                                <!--                </div>-->
                                                <!--                <div>-->
                                                <!--                    <a href="collections/nose-rings-indian.html"-->
                                                <!--                        class="site-nav__dropdown-link">-->
                                                <!--                        Indian-->
                                                <!--                    </a>-->
                                                <!--                </div>-->
                                                <!--                <div>-->
                                                <!--                    <a href="collections/nose-rings-diamond.html"-->
                                                <!--                        class="site-nav__dropdown-link">-->
                                                <!--                        Diamond-->
                                                <!--                    </a>-->
                                                <!--                </div>-->
                                                <!--            </div>-->
                                                <!--            <div-->
                                                <!--                class="grid__item medium-up--one-fifth appear-animation appear-delay-10">-->
                                                <!--                <div class="h5">-->
                                                <!--                    <a href="collections/pendant-sets-1.html"-->
                                                <!--                        class="site-nav__dropdown-link site-nav__dropdown-link--top-level">Pendant-->
                                                <!--                        Sets</a>-->
                                                <!--                </div>-->
                                                <!--                <div>-->
                                                <!--                    <a href="collections/pendent-sets-diamond.html"-->
                                                <!--                        class="site-nav__dropdown-link">-->
                                                <!--                        Diamond-->
                                                <!--                    </a>-->
                                                <!--                </div>-->
                                                <!--                <div>-->
                                                <!--                    <a href="collections/pendent-sets-indian.html"-->
                                                <!--                        class="site-nav__dropdown-link">-->
                                                <!--                        Indian-->
                                                <!--                    </a>-->
                                                <!--                </div>-->
                                                <!--            </div>-->
                                                <!--            <div-->
                                                <!--                class="grid__item medium-up--one-fifth appear-animation appear-delay-11">-->
                                                <!--                <div class="h5">-->
                                                <!--                    <a href="collections/earchains.html"-->
                                                <!--                        class="site-nav__dropdown-link site-nav__dropdown-link--top-level">EarChains</a>-->
                                                <!--                </div>-->
                                                <!--                <div class="h5">-->
                                                <!--                    <a href="collections/hand-harness-1.html"-->
                                                <!--                        class="site-nav__dropdown-link site-nav__dropdown-link--top-level">Hand-->
                                                <!--                        Harness</a>-->
                                                <!--                </div>-->
                                                <!--                <div class="h5">-->
                                                <!--                    <a href="collections/semi-precious.html"-->
                                                <!--                        class="site-nav__dropdown-link site-nav__dropdown-link--top-level">Semi-->
                                                <!--                        Precious</a>-->
                                                <!--                </div>-->
                                                <!--            </div>-->
                                                <!--        </div>-->
                                                <!--    </div>-->
                                                <!--</div>-->
                                            </li>
                                            <li class="site-nav__item site-nav__expanded-item site-nav--has-dropdown"
                                                aria-haspopup="true">

                                                <a href="<?php echo e(url('/blog')); ?>"
                                                    class="site-nav__link site-nav__link--underline site-nav__link--has-dropdown">
                                                    Blogs
                                                </a>
                                                
                                            </li>
                                            
                                            <li class="site-nav__item site-nav__expanded-item site-nav--has-dropdown"
                                                aria-haspopup="true">

                                                <a href="<?php echo e(url('/contact')); ?>"
                                                    class="site-nav__link site-nav__link--underline site-nav__link--has-dropdown">
                                                    Contact Us
                                                </a>
                                            </li>
                                       
                                     
                                        </ul>
                                    </div>
                                </div>
                                <div class="site-header__search-container">
                                    <div class="site-header__search">
                                        <div class="page-width">
                                            <form action="https://Shopkart.in/search" method="get"
                                                role="search" id="HeaderSearchForm"
                                                class="site-header__search-form">
                                                <input type="hidden" name="type" value="product">
                                                <button type="submit"
                                                    class="text-link site-header__search-btn site-header__search-btn--submit">
                                                    <svg aria-hidden="true" focusable="false" role="presentation"
                                                        class="icon icon-search" viewBox="0 0 64 64">
                                                        <path
                                                            d="M47.16 28.58A18.58 18.58 0 1 1 28.58 10a18.58 18.58 0 0 1 18.58 18.58zM54 54L41.94 42" />
                                                    </svg>
                                                    <span class="icon__fallback-text">Search</span>
                                                </button>
                                                <input type="search" name="q" value=""
                                                    placeholder="Search our store" class="site-header__search-input"
                                                    aria-label="Search our store">
                                            </form>
                                            <button type="button" id="SearchClose"
                                                class="js-search-header-close text-link site-header__search-btn">
                                                <svg aria-hidden="true" focusable="false" role="presentation"
                                                    class="icon icon-close" viewBox="0 0 64 64">
                                                    <path d="M19 17.61l27.12 27.13m0-27.12L19 44.74" />
                                                </svg>
                                                <span class="icon__fallback-text">"Close (esc)"</span>
                                            </button>
                                        </div>
                                    </div>
                                    <div id="PredictiveWrapper" class="predictive-results hide"
                                        data-image-size="square">
                                        <div class="page-width">
                                            <div id="PredictiveResults" class="predictive-result__layout"></div>
                                            <div class="text-center predictive-results__footer">
                                                <button type="button" class="btn btn--small"
                                                    data-predictive-search-button>
                                                    <small>
                                                        View more
                                                    </small>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </header>
                        </div>
                    </div>

                    <div class="st-search-bar hidden-desktop">
                        <input type="text" name="q" placeholder="Search..." value=""
                            autocapitalize="off" autocomplete="off" autocorrect="off">
                        <span class="input-close-btn" style="display: none;"></span>




                        <div id="trending-autocomplete" v-cloak v-show="showTrendingSearch"
                            class="st-trending-box" v-cloak>
                            <div class="st-container-trend" v-show="isTrendingVisible && trending_results.length>0"
                                style="display: block;">
                                <div id="st-before-search">
                                    <div class="st-trending-header">
                                        <svg viewBox="0 0 500 500" width="18" height="18" fill="#f94"
                                            data-v-26850a1a="" class="st-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" height="500"
                                                viewBox="0 0 48 48" width="500" data-v-26850a1a="">
                                                <path
                                                    d="M32 12l4.59 4.59-9.76 9.75-8-8-14.83 14.83 2.83 2.83 12-12 8 8 12.58-12.59 4.59 4.59v-12z"
                                                    data-v-26850a1a=""></path>
                                                <path d="M0 0h48v48h-48z" fill="none" data-v-26850a1a=""></path>
                                            </svg>
                                        </svg>
                                        <span class="st-heading-text"><span
                                                class="recent-icon hidden-desktop"></span>Trending
                                            Searches</span>
                                    </div>
                                    <ul class="st-trending-list">
                                        <li class="st-trending-label" v-for="item in trending_results"
                                            :key="item" v-show="item.showInSuggestion"
                                            @click.stop="actionOnTrendingClick(item)">
                                            <svg viewBox="0 0 500 500" width="18" height="18"
                                                fill="#f94" data-v-26850a1a="" class="st-icon">
                                                <svg xmlns="http://www.w3.org/2000/svg" height="500"
                                                    viewBox="0 0 48 48" width="500" data-v-26850a1a="">
                                                    <path
                                                        d="M32 12l4.59 4.59-9.76 9.75-8-8-14.83 14.83 2.83 2.83 12-12 8 8 12.58-12.59 4.59 4.59v-12z"
                                                        data-v-26850a1a=""></path>
                                                    <path d="M0 0h48v48h-48z" fill="none" data-v-26850a1a="">
                                                    </path>
                                                </svg>
                                            </svg>

                                        </li>
                                    </ul>
                                    <div class="st-autocomplete-footer"></div>
                                </div>
                            </div>
                        </div>

                    </div>



                    <div class="announcement-bar">
                        <div class="page-width">
                            <div class="slideshow-wrapper">
                                <button type="button" class="visually-hidden slideshow__pause" data-id="header"
                                    aria-live="polite">
                                    <span class="slideshow__pause-stop">
                                        <svg aria-hidden="true" focusable="false" role="presentation"
                                            class="icon icon-pause" viewBox="0 0 10 13">
                                            <g fill="#000" fill-rule="evenodd">
                                                <path d="M0 0h3v13H0zM7 0h3v13H7z" />
                                            </g>
                                        </svg>
                                        <span class="icon__fallback-text">Pause slideshow</span>
                                    </span>
                                    <span class="slideshow__pause-play">
                                        <svg aria-hidden="true" focusable="false" role="presentation"
                                            class="icon icon-play" viewBox="18.24 17.35 24.52 28.3">
                                            <path fill="#323232" d="M22.1 19.151v25.5l20.4-13.489-20.4-12.011z" />
                                        </svg>
                                        <span class="icon__fallback-text">Play slideshow</span>
                                    </span>
                                </button>

                                <div id="AnnouncementSlider" class="announcement-slider" data-compact="true"
                                    data-block-count="3">
                                    <div id="AnnouncementSlide-1524770292306" class="announcement-slider__slide"
                                        data-index="0"><span class="announcement-text">We ship worldwide</span>
                                    </div>
                                    <div id="AnnouncementSlide-1524770296206" class="announcement-slider__slide"
                                        data-index="1"><span class="announcement-text">Free Shipping for prepaid
                                            orders</span></div>
                                    <div id="AnnouncementSlide-bbd40ada-6bda-4119-96e1-5be93ee73fba"
                                        class="announcement-slider__slide" data-index="2"><span
                                            class="announcement-text">Exclusive Sale Live Now</span></div>
                                </div>
                            </div>
                        </div>
                    </div>
<?php /**PATH /home/u877593591/domains/webreakhost.com/public_html/shopkart/resources/views/frontend/layouts/header.blade.php ENDPATH**/ ?>
<?php

namespace App\Http\Controllers\Frontend;
use Illuminate\Support\Facades\DB;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Wishlist;
class JewelryController extends Controller
{
    public function index(){
        $user_id = auth()->user() ? auth()->user()->id : null;
        
        $products = DB::table('product')->get();
        $wishlistItems = $user_id ? Wishlist::where('user_id', $user_id)->pluck('product_id')->toArray() : [];

        // Process each product
        $products->each(function ($product) use ($wishlistItems) {
            // Get the first image
            $images = explode('|', $product->image);
            $product->firstImage = $images[0] ?? ''; // Get the first image, or an empty string if there are no images
    
            // Check if the product is in the user's wishlist
            $product->inWishlist = in_array($product->productId, $wishlistItems);
        });
        return view('frontend.jewelry', compact('products'));

        
    }
    
    
    
    
    
    public function earings(){
        
        return view('frontend.jewelry');
    }
    
     public function showByCategory($id)
    {
        // Fetch products based on the category ID
        $products = Product::where('categoryId', $id)->get();
        $products->each(function ($product) {
            $images = explode('|', $product->image);
            $product->firstImage = $images[0] ?? ''; // Get the first image, or an empty string if there are no images
        });
        // Pass products to the view
        return view('frontend.jewelry', compact('products'));
    }
    
   public function show($productId)
{
    try {
        $product = Product::where('productId', $productId)->firstOrFail();
        
        $images = explode('|', $product->image);
        $product->firstImage = $images[0] ?? ''; // Get the first image, or an empty string if there are no images
        
        return view('frontend.view_product', compact('product'));
    } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
        // Product not found, handle the error (e.g., redirect to a 404 page)
        abort(404);
    }
}


}

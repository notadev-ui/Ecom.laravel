<?php

namespace App\Http\Controllers\Frontend;
use App\Models\Product; // Import the Blog model
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth; // Make sure this line is present
use App\Models\Cart; // Ensure this line is present
use App\Models\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CartController extends Controller
{
    
// public function index()
// {
//     // Check if there is any cart data in the session
//     $cart = Session::get('cart', []);
//     // dd($cart);
//     if (Auth::check()) {
//         $userId = Auth::id();

//         // Retrieve cart details from the database
//         $cartItems = Cart::where('user_id', $userId)->get();

//         // Merge the database cart items with existing session cart data
//         foreach ($cartItems as $item) {
//             if (!isset($cart[$item->product_id])) {
//                 $product = Product::find($item->product_id);
//                 if ($product) {
//                     $cart[$item->product_id] = [
//                         'quantity' => $item->quantity,
//                         'product_id' => $item->product_id,
//                         'user_id' => $item->user_id,
//                         'name' => $product->productName,
//                         'price' => $product->productPrice,
//                         'image' => $product->image ?? '', // Ensure image is set or default to empty string
//                     ];
//                 }
//             }
//         }
        
//         // Update the session with the merged cart data
//         Session::put('cart', $cart);
//     }

//     return view('frontend.cart', compact('cart'));
// }
    
public function index()
{
    // Check if there is any cart data in the session
    $cart = Session::get('cart', []);
    
    if (Auth::check()) {
        $userId = Auth::id();

        // Retrieve cart details from the database
        $cartItems = Cart::where('user_id', $userId)->get();

        // Merge the database cart items with existing session cart data
        foreach ($cartItems as $item) {
            $product = Product::find($item->product_id);
            if ($product) {
                $cart[$item->product_id] = [
                    'id' => $item->id, // Include the cart item ID here
                    'quantity' => $item->quantity,
                    'product_id' => $item->product_id,
                    'user_id' => $item->user_id,
                    'name' => $product->productName,
                    'price' => $product->productPrice,
                    'image' => $product->image ?? '', // Ensure image is set or default to empty string
                ];
            }
        }

        // Update the session with the merged cart data
        Session::put('cart', $cart);
    }

    return view('frontend.cart', compact('cart'));
}



    
    
// public function add(Request $request)
// {
//     $productId = $request->input('product_id');
//         $product = Product::where('productId', $productId)->first();

//         if (!$product) {
//             return redirect()->back()->with('error', 'Product not found.');
//         }

//         $cart = Session::get('cart', []);

//         // Add product to cart
//         $cart[$productId] = [
//             'id' => $product->productId,
//             'name' => $product->productName,
//             'price' => $product->productPrice,
//             'quantity' => 1, // You can add functionality to update quantity
//             'image' => $product->image
//         ];

//         Session::put('cart', $cart);

//         return redirect()->route('cart.index')->with('success', 'Product added to cart.');
//     }

    
    // public function add(Request $request)
    // {
    //     if (Auth::check()) {
    //         $userId = Auth::id();
    //         $productId = $request->input('product_id');

    //         // Add to cart logic
    //         $cart = new Cart();
    //         $cart->user_id = $userId;
    //         $cart->product_id = $productId;
    //         $cart->quantity = 1; // Default quantity
    //         $cart->save();

    //         return redirect()->back()->with('success', 'Product added to cart successfully!');
    //     } else {

    //         return redirect()->route('user.login')->with('error', 'Please login to add products to the cart.');
    //     }
    // }
    
// public function add(Request $request)
// {
//     $productId = $request->input('product_id');

//     // Retrieve product details from the database
//     $product = Product::find($productId);

//     if (!$product) {
//         return redirect()->back()->with('error', 'Product not found!');
//     }

//     if (Auth::check()) {
//         $userId = Auth::id();

//         // Add to cart logic
//         $cartItem = Cart::where('user_id', $userId)->where('product_id', $productId)->first();

//         if ($cartItem) {
//             $cartItem->quantity += 1;
//             $cartItem->save();
//         } else {
//             $cartItem = new Cart();
//             $cartItem->user_id = $userId;
//             $cartItem->product_id = $productId;
//             $cartItem->quantity = 1; // Default quantity
//             $cartItem->save();
//         }

//         return redirect()->back()->with('success', 'Product added to cart successfully!');
//     } else {
//         // If user is not logged in, store the cart data in the session
//         $cart = Session::get('cart', []);
//         if (isset($cart[$productId])) {
//             $cart[$productId]['quantity'] += 1; // Increment quantity if product already exists in cart
//         } else {
//             $cart[$productId] = [
//                 'product_id' => $productId,
//                 'quantity' => 1,
//                 'name' => $product->productName,
//                 'price' => $product->productPrice,
//                 'image' => $product->image ?? '', // Ensure image is set or default to empty string
//             ];
//         }
//         Session::put('cart', $cart);

//         return redirect()->back()->with('success', 'Product added to cart successfully!');
//     }
// }
    
 public function add(Request $request)
{
    $productId = $request->input('product_id');
    $product = Product::find($productId);

    if (!$product) {
        return redirect()->back()->with('error', 'Product not found!');
    }

    if (Auth::check()) {
        $userId = Auth::id();
        $cartItem = Cart::where('user_id', $userId)->where('product_id', $productId)->first();

        if ($cartItem) {
            $cartItem->quantity += 1;
            $cartItem->save();
        } else {
            $cartItem = new Cart();
            $cartItem->user_id = $userId;
            $cartItem->product_id = $productId;
            $cartItem->quantity = 1;
            $cartItem->save();
        }

        return redirect()->back()->with('success', 'Product added to cart successfully!');
    } else {
        $cart = Session::get('cart', []);
        if (isset($cart[$productId])) {
            $cart[$productId]['quantity'] += 1;
        } else {
            $cart[$productId] = [
                'id' => uniqid(), // Generate a unique ID for the session cart item
                'product_id' => $productId,
                'quantity' => 1,
                'name' => $product->productName,
                'price' => $product->productPrice,
                'image' => $product->image ?? '',
            ];
        }
        Session::put('cart', $cart);

        return redirect()->back()->with('success', 'Product added to cart successfully!');
    }
}


public function update(Request $request, $productId)
{
    $action = $request->input('action');

    if (Auth::check()) {
        $cartItem = Cart::where('product_id', $productId)->where('user_id', Auth::id())->first();

        if ($cartItem) {
            if ($action === 'increase') {
                $cartItem->quantity++;
            } elseif ($action === 'decrease' && $cartItem->quantity > 1) {
                $cartItem->quantity--;
            }

            $cartItem->save();
        }

        $cart = Session::get('cart', []);
        if (isset($cart[$productId])) {
            $cart[$productId]['quantity'] = $cartItem->quantity;
            Session::put('cart', $cart);
        }
    } else {
        $cart = Session::get('cart', []);
        if (isset($cart[$productId])) {
            if ($action === 'increase') {
                $cart[$productId]['quantity']++;
            } elseif ($action === 'decrease' && $cart[$productId]['quantity'] > 1) {
                $cart[$productId]['quantity']--;
            }
            Session::put('cart', $cart);
        }
    }

    return redirect()->route('cart.index')->with('success', 'Cart updated successfully');
}



public function destroy($productId)
{
    if (Auth::check()) {
        $user = Auth::user();
        $user->carts()->where('product_id', $productId)->delete();
    } else {
        $cart = Session::get('cart', []);
        if (isset($cart[$productId])) {
            unset($cart[$productId]);
            Session::put('cart', $cart);
        }
    }

    // Fetch the updated cart data
    $cart = Auth::check() ? Auth::user()->carts()->get() : Session::get('cart', []);

    return redirect()->route('cart.index')->with(['success' => 'Product removed from cart', 'cart' => $cart]);
}


}

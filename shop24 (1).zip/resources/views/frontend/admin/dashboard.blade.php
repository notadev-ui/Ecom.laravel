@extends('frontend.layouts.dashboard')
@section('title', 'dashboard')

@section('content')



@endsection
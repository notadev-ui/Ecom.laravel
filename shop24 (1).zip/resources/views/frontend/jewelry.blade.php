@extends('frontend.layouts.main')

@section('main-container')
<script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <style>
        .card-text {
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
            text-overflow: ellipsis;
            height: 4.5em; /* (line-height) * (number of lines you want to show) */
        }
        
        .image-container {
            position: relative;
        }
        .add-to-cart-btn {
            position: absolute;
            bottom: 10px;
            left: 50%;
            transform: translateX(-50%);
            display: none;
        }
        .image-container:hover .add-to-cart-btn {
                display: block;
                background: black;
                color: white;
                padding-right: 20px;
                padding-left: 46px;
                padding-top: 9px;
                padding-bottom: 9px;
                border-radius: 11px;
                width: 200px;
                }
                
               
.wishlist-btn {
    position: absolute;
    top: 10px;
    right: 10px;
    display: none;
    background: black;
    color: white;
    padding: 9px 10px;
    border-radius: 11px;
} 
     .image-container:hover .wishlist-btn {
    display: block;
}         
.wishlist-btn.clicked {
    background: white;
    color: red;
}
        .image-container img {
            display: block;
            width: 100%;
            height: auto;
        }
        
        
        
/* Media query for screens smaller than 768px (typical tablets and phones) */
@media (max-width: 767px) {
    .card-body {
        text-align: center; /* Center align the content */
    }
    .card-body .btn {
        display: block; /* Ensure the button takes full width */
        margin: 0 auto; /* Center the button horizontally */
    }
}

@media (max-width: 991px) {
    .site-navigation ul {
        display: block;
        text-align: center; /* Center align the menu items */
        padding: 0;
    }
    .site-navigation li {
        display: inline-block; /* Display the menu items inline */
        margin-left: 15px; /* Add some space between menu items */
    }
}

        
    </style>
<header class="site-navbar" role="banner">
    <div class="container">
        <div class="row align-items-center" style="flex-direction: row-reverse;">
            <div class="col">
                <nav class="site-navigation position-relative text-right" role="navigation">
                    <ul class="site-menu js-clone-nav mr-auto  d-lg-block">
                        <li><a href="{{ route('category.show', 2) }}"><span>Earrings</span></a></li>
                        <li><a href="{{ route('category.show', 8) }}"><span>Necklaces</span></a></li>
                        <li><a href="{{ route('category.show', 9) }}"><span>Bracelets</span></a></li>
                        <li><a href="{{ route('category.show', 10) }}"><span>Anklets</span></a></li>
                        <li><a href="{{ route('category.show', 11) }}"><span>Rings</span></a></li>
                    </ul>
                </nav>
            </div>
            <div class="d-inline-block ml-md-0 mr-auto py-3" style="position: relative; top: 3px;">
                <a href="#" class="site-menu-toggle js-menu-toggle text-white"><span class="icon-menu h3"></span></a>
            </div>
        </div>
    </div>
</header>



<main class="main-content" id="MainContent">
    <div id="shopify-section-collection-header" class="shopify-section"><div class="page-width page-content page-content--top">
<header class="section-header section-header--flush">
<h1 class="section-header__title">
    Exclusive Sale
  </h1>
</header>
</div>
<div id="CollectionHeaderSection" data-section-id="collection-header" data-section-type="collection-header">
</div>
<style>   #shopify-section-collection-header h1 {text-transform: uppercase;} </style></div>

<div id="CollectionAjaxResult" class="collection-content">
<div id="CollectionAjaxContent">
<div class="page-width">


<div class="container">
    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif
    <div class="row">
                    @foreach($products as $product)

        <div class="col col-md-3 mt-3">
           <div class="card" style="height:428px;">
                    <!--<div class="image-container">-->
                    <!--        <img src="{{ asset('image/' . $product->firstImage) }}" class="card-img-top img-fluid" alt="{{ $product->productName }}"style="height:200px!important;" >-->
                            <!--<a href="#" class="btn btn-primary add-to-cart-btn">Add to Cart</a>-->
                    <!--      <a href="#" class="add-to-cart-btn "><span class="fa fa-shopping-cart px-1"></span>Add To Cart</a>-->

                    <!--</div>-->
                    
                     <div class="image-container">
                    <img src="{{ asset('image/' . $product->firstImage) }}" class="card-img-top img-fluid" alt="{{ $product->productName }}" style="height:200px!important;">
                        <form action="{{ route('cart.add') }}" method="POST">
                            @csrf
                            <input type="hidden" name="product_id" value="{{ $product->productId }}">
                            
                             <button type="submit"  <a href="#" class="add-to-cart-btn "><span class="fa fa-shopping-cart px-1"></span>Add To Cart</a></button>
                               
                           
                        </form>
                        <form action="{{ route('wishlist.add') }}" method="POST">
                            @csrf
                            <input type="hidden" name="product_id" value="{{ $product->productId }}" >
                            @if ($product->inWishlist)
                            <button type="submit" class="wishlist-btn clicked" >
                                <span class="fa fa-heart px-1"></span>
                            </button>
                            @else
                            <button type="submit" class="wishlist-btn" >
                                <span class="fa fa-heart px-1"></span>
                            </button>
                            @endif
                      </form>


                </div>
                   <div class="card-body">
            <h5 class="card-title"><a href="{{ route('product.view', $product->productId) }}">{{ $product->productName }}</a></h5>
                        <p class="card-text"style="margin-bottom:2px; color:black!important;">{{ $product->productDescription}}</p>
                        <p class="card-text "style="margin-bottom:2px; height:38px; color:black!important;">₹{{ $product->productPrice}}</p>
                       <a href="{{ route('product.view', $product->productId) }}" class="btn btn-danger" style="background: #ec688d;border: 2px solid #ec688d; color: black;
                         width: 200px;">Shop Now</a>

                       <!--<div class="row">-->
                       <!--    <div class="col col-md-6"><a href="#" class="btn btn-primary">Cart</a></div>-->
                       <!--    <div class="col col-md-6"><box-icon name='cart' type='solid'  ></box-icon></div>-->
                       <!--</div>-->

                        
                         
                </div>
            </div>
        </div>
        @endforeach
    </div>
</div>


</div>
</div>
</div>

<script >

document.addEventListener("DOMContentLoaded", function() {
    const wishlistButtons = document.querySelectorAll(".wishlist-btn");

    // Add event listeners to all wishlist buttons
    wishlistButtons.forEach((button, index) => {
        button.addEventListener("click", function() {
            if (button.classList.contains("clicked")) {
                alert('Product is already in wishlist');
            } else {
                button.classList.add("clicked");
            }
        });
    });

});


</script>

  </main>



@endsection